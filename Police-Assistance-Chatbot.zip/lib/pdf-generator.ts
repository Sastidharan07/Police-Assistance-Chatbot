import { jsPDF } from "jspdf"
import type { Complaint } from "./storage-service"

export const generateComplaintPDF = (complaint: Complaint, language: "english" | "tamil"): string => {
  const doc = new jsPDF()

  // Add title
  doc.setFontSize(20)
  doc.setFont("helvetica", "bold")
  doc.text(language === "english" ? "Complaint Details" : "புகார் விவரங்கள்", 105, 20, { align: "center" })

  // Add complaint ID and date
  doc.setFontSize(12)
  doc.setFont("helvetica", "normal")
  doc.text(language === "english" ? `Complaint ID: ${complaint.id}` : `புகார் எண்: ${complaint.id}`, 20, 35)

  const date = new Date(complaint.createdAt).toLocaleDateString()
  doc.text(language === "english" ? `Date: ${date}` : `தேதி: ${date}`, 20, 42)

  // Add status
  doc.setFont("helvetica", "bold")
  doc.text(
    language === "english" ? `Status: ${complaint.status.toUpperCase()}` : `நிலை: ${complaint.status.toUpperCase()}`,
    20,
    50,
  )

  // Add horizontal line
  doc.setDrawColor(200, 200, 200)
  doc.line(20, 55, 190, 55)

  // Add personal details
  doc.setFontSize(16)
  doc.text(language === "english" ? "Personal Details" : "தனிப்பட்ட விவரங்கள்", 20, 65)

  doc.setFontSize(12)
  doc.setFont("helvetica", "normal")
  doc.text(language === "english" ? `Name: ${complaint.name}` : `பெயர்: ${complaint.name}`, 20, 75)

  doc.text(language === "english" ? `Phone: ${complaint.phone}` : `தொலைபேசி: ${complaint.phone}`, 20, 82)

  if (complaint.address) {
    doc.text(language === "english" ? `Address: ${complaint.address}` : `முகவரி: ${complaint.address}`, 20, 89)
  }

  // Add incident details
  doc.setFontSize(16)
  doc.setFont("helvetica", "bold")
  doc.text(language === "english" ? "Incident Details" : "சம்பவ விவரங்கள்", 20, 100)

  doc.setFontSize(12)
  doc.setFont("helvetica", "normal")

  if (complaint.incidentDate) {
    doc.text(
      language === "english" ? `Incident Date: ${complaint.incidentDate}` : `சம்பவ தேதி: ${complaint.incidentDate}`,
      20,
      110,
    )
  }

  if (complaint.incidentLocation) {
    doc.text(
      language === "english"
        ? `Incident Location: ${complaint.incidentLocation}`
        : `சம்பவ இடம்: ${complaint.incidentLocation}`,
      20,
      117,
    )
  }

  // Add description with word wrap
  doc.setFontSize(16)
  doc.setFont("helvetica", "bold")
  doc.text(language === "english" ? "Description" : "விளக்கம்", 20, 130)

  doc.setFontSize(12)
  doc.setFont("helvetica", "normal")

  const splitDescription = doc.splitTextToSize(complaint.description, 170)
  doc.text(splitDescription, 20, 140)

  // Add footer
  doc.setFontSize(10)
  doc.text(
    language === "english"
      ? "This is an electronically generated document and does not require a signature."
      : "இது மின்னணு முறையில் உருவாக்கப்பட்ட ஆவணம் மற்றும் கையொப்பம் தேவையில்லை.",
    105,
    280,
    { align: "center" },
  )

  // Return the PDF as a data URL
  return doc.output("dataurlstring")
}

