"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { FileText, Image, File, X, Upload, FileUp } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import type { FileAttachment } from "@/lib/storage-service"

interface FileUploadProps {
  onFilesSelected: (files: FileAttachment[]) => void
  maxFiles?: number
  maxSizeMB?: number
  acceptedTypes?: string
}

export function FileUpload({
  onFilesSelected,
  maxFiles = 5,
  maxSizeMB = 5,
  acceptedTypes = "image/*,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}: FileUploadProps) {
  const [files, setFiles] = useState<FileAttachment[]>([])
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { t, language } = useLanguage()

  const maxSizeBytes = maxSizeMB * 1024 * 1024

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || [])
    setError(null)

    // Check if adding these files would exceed the maximum
    if (files.length + selectedFiles.length > maxFiles) {
      setError(
        language === "english"
          ? `You can upload a maximum of ${maxFiles} files`
          : `நீங்கள் அதிகபட்சம் ${maxFiles} கோப்புகளை பதிவேற்ற முடியும்`,
      )
      return
    }

    // Check file sizes
    const oversizedFiles = selectedFiles.filter((file) => file.size > maxSizeBytes)
    if (oversizedFiles.length > 0) {
      setError(
        language === "english"
          ? `Some files exceed the maximum size of ${maxSizeMB}MB`
          : `சில கோப்புகள் அதிகபட்ச அளவான ${maxSizeMB}MB ஐ தாண்டுகின்றன`,
      )
      return
    }

    // Process files
    const newAttachments: FileAttachment[] = []

    for (const file of selectedFiles) {
      try {
        const dataUrl = await readFileAsDataURL(file)
        const attachment: FileAttachment = {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
          name: file.name,
          type: file.type,
          size: file.size,
          dataUrl,
          createdAt: new Date().toISOString(),
        }
        newAttachments.push(attachment)
      } catch (error) {
        console.error("Error reading file:", error)
        setError(
          language === "english"
            ? "Error reading file. Please try again."
            : "கோப்பைப் படிப்பதில் பிழை. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.",
        )
      }
    }

    const updatedFiles = [...files, ...newAttachments]
    setFiles(updatedFiles)
    onFilesSelected(updatedFiles)

    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const readFileAsDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
  }

  const removeFile = (id: string) => {
    const updatedFiles = files.filter((file) => file.id !== id)
    setFiles(updatedFiles)
    onFilesSelected(updatedFiles)
  }

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <Image className="h-5 w-5" />
    if (type.includes("pdf")) return <FileText className="h-5 w-5" />
    return <File className="h-5 w-5" />
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6 bg-gray-50 hover:bg-gray-100 transition-colors">
        <FileUp className="h-10 w-10 text-gray-400 mb-2" />
        <p className="text-sm text-gray-500 mb-2">
          {language === "english"
            ? `Drag and drop files here, or click to select files`
            : `கோப்புகளை இங்கே இழுத்து விடவும், அல்லது கோப்புகளைத் தேர்ந்தெடுக்க கிளிக் செய்யவும்`}
        </p>
        <p className="text-xs text-gray-400 mb-4">
          {language === "english"
            ? `Maximum ${maxFiles} files, up to ${maxSizeMB}MB each`
            : `அதிகபட்சம் ${maxFiles} கோப்புகள், ஒவ்வொன்றும் ${maxSizeMB}MB வரை`}
        </p>
        <Button
          type="button"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2"
        >
          <Upload className="h-4 w-4" />
          {language === "english" ? "Select Files" : "கோப்புகளைத் தேர்ந்தெடுக்கவும்"}
        </Button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          multiple
          accept={acceptedTypes}
          className="hidden"
        />
      </div>

      {error && <p className="text-sm text-red-500">{error}</p>}

      {files.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium">
            {language === "english" ? "Selected Files" : "தேர்ந்தெடுக்கப்பட்ட கோப்புகள்"}
          </h4>
          <ul className="space-y-2">
            {files.map((file) => (
              <li key={file.id} className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
                <div className="flex items-center gap-2">
                  {getFileIcon(file.type)}
                  <div className="flex flex-col">
                    <span className="text-sm font-medium truncate max-w-[200px]">{file.name}</span>
                    <span className="text-xs text-gray-500">{formatFileSize(file.size)}</span>
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeFile(file.id)}
                  className="h-8 w-8 text-gray-500 hover:text-red-500"
                >
                  <X className="h-4 w-4" />
                </Button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

