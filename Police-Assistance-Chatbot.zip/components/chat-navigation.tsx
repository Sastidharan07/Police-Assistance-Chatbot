"use client"
import { Button } from "@/components/ui/button"
import { MessageSquare, Phone, FileText, AlertTriangle, BookOpen, HelpCircle, MapPin } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface ChatNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function ChatNavigation({ activeTab, onTabChange }: ChatNavigationProps) {
  const { t, language, setLanguage } = useLanguage()

  const toggleLanguage = () => {
    setLanguage(language === "english" ? "tamil" : "english")
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-row md:flex-col gap-1 p-2 bg-background border rounded-lg overflow-x-auto md:overflow-visible">
        <Button
          variant={activeTab === "chat" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("chat")}
        >
          <MessageSquare className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.chat")}</span>
        </Button>

        <Button
          variant={activeTab === "emergency" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("emergency")}
        >
          <Phone className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.emergency")}</span>
        </Button>

        <Button
          variant={activeTab === "location" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("location")}
        >
          <MapPin className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.location")}</span>
        </Button>

        <Button
          variant={activeTab === "procedures" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("procedures")}
        >
          <FileText className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.procedures")}</span>
        </Button>

        <Button
          variant={activeTab === "legal" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("legal")}
        >
          <BookOpen className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.legal")}</span>
        </Button>

        <Button
          variant={activeTab === "complaint" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("complaint")}
        >
          <AlertTriangle className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.complaint")}</span>
        </Button>

        <Button
          variant={activeTab === "faq" ? "default" : "ghost"}
          className={`w-full justify-start text-xs md:text-sm ${language === "tamil" ? "font-tamil" : ""}`}
          onClick={() => onTabChange("faq")}
        >
          <HelpCircle className="h-4 w-4 md:mr-2 flex-shrink-0" />
          <span className="hidden md:inline">{t("nav.faq")}</span>
        </Button>
      </div>

      {/* Language selector button - hidden on mobile as it's already in the chat header */}
      <Button variant="outline" size="sm" onClick={toggleLanguage} className="w-full md:mt-2 hidden md:block">
        {language === "english" ? "தமிழ்" : "English"}
      </Button>
    </div>
  )
}

