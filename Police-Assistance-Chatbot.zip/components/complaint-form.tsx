"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, CheckCircle, Trash2, Download, FileText } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useLanguage } from "@/lib/language-context"
import { useAuth } from "@/lib/auth-context"
import {
  type Complaint,
  type FileAttachment,
  getComplaints,
  saveComplaint,
  updateComplaint,
} from "@/lib/storage-service"
import { getUserData, saveUserData } from "@/lib/storage-service"
import { validateMobile } from "@/lib/validation"
import { FileUpload } from "./file-upload"
import { AddressAutocomplete } from "./address-autocomplete"
import { QRCodeGenerator } from "./qr-code-generator"
import { generateComplaintPDF } from "@/lib/pdf-generator"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import dynamic from "next/dynamic"

// Replace the direct import with dynamic import
const LocationMap = dynamic(() => import("./location-map").then((mod) => mod.LocationMap), {
  ssr: false,
  loading: () => (
    <div className="h-[300px] rounded-md overflow-hidden border flex items-center justify-center bg-gray-100">
      <p className="text-gray-500">Loading map component...</p>
    </div>
  ),
})

export function ComplaintForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    address: "",
    incidentDate: "",
    incidentLocation: "",
    description: "",
  })
  const [attachments, setAttachments] = useState<FileAttachment[]>([])
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null)
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [activeTab, setActiveTab] = useState("details")
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { t, language } = useLanguage()
  const { mobileNumber } = useAuth()
  const formRef = useRef<HTMLFormElement>(null)

  useEffect(() => {
    if (mobileNumber) {
      setComplaints(getComplaints(mobileNumber))
    }
  }, [mobileNumber])

  // Handle form field changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target

    // For phone field, only allow digits and limit to 10 characters
    if (name === "phone") {
      const phoneValue = value.replace(/\D/g, "").slice(0, 10)
      setFormData((prev) => ({ ...prev, [name]: phoneValue }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }

    setError("")
    setSuccess(false)
  }

  // Handle file attachments
  const handleFilesSelected = (files: FileAttachment[]) => {
    setAttachments(files)
  }

  // Handle location selection
  const handleLocationSelected = (location: { lat: number; lng: number; address: string }) => {
    setCoordinates({ lat: location.lat, lng: location.lng })
    setFormData((prev) => ({ ...prev, incidentLocation: location.address }))
  }

  // Handle address selection
  const handleAddressChange = (address: string) => {
    setFormData((prev) => ({ ...prev, address }))
  }

  // Delete a complaint
  const handleDeleteComplaint = (id: string) => {
    if (!mobileNumber) return

    const userData = getUserData(mobileNumber)
    userData.complaints = userData.complaints.filter((complaint) => complaint.id !== id)
    saveUserData(mobileNumber, userData)

    setComplaints(getComplaints(mobileNumber))
    setSelectedComplaint(null)
  }

  // View complaint details
  const handleViewComplaint = (complaint: Complaint) => {
    setSelectedComplaint(complaint)
  }

  // Download complaint as PDF
  const handleDownloadPDF = (complaint: Complaint) => {
    const pdfDataUrl = generateComplaintPDF(complaint, language)

    const link = document.createElement("a")
    link.href = pdfDataUrl
    link.download = `complaint-${complaint.id}.pdf`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Submit the complaint form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!mobileNumber) return

    setIsSubmitting(true)

    try {
      // Basic validation
      if (!formData.name || !formData.phone || !formData.description) {
        setError(language === "english" ? "Please fill in all required fields" : "அனைத்து தேவையான புலங்களையும் நிரப்பவும்")
        setIsSubmitting(false)
        return
      }

      if (!validateMobile(formData.phone)) {
        setError(
          language === "english"
            ? "Please enter a valid 10-digit phone number"
            : "சரியான 10-இலக்க தொலைபேசி எண்ணை உள்ளிடவும்",
        )
        setIsSubmitting(false)
        return
      }

      // Save complaint with attachments and coordinates
      const newComplaint = await saveComplaint(mobileNumber, {
        ...formData,
        attachments,
        coordinates: coordinates || undefined,
      })

      // Generate QR code for the complaint
      const complaintUrl = `${window.location.origin}/complaint/${newComplaint.id}`
      updateComplaint(mobileNumber, newComplaint.id, { qrCode: complaintUrl })

      // Refresh complaints list
      setComplaints(getComplaints(mobileNumber))

      // Reset form and show success message
      setFormData({
        name: "",
        phone: "",
        address: "",
        incidentDate: "",
        incidentLocation: "",
        description: "",
      })
      setAttachments([])
      setCoordinates(null)
      setSuccess(true)
      setActiveTab("details")

      // Reset form
      if (formRef.current) {
        formRef.current.reset()
      }
    } catch (error) {
      console.error("Error submitting complaint:", error)
      setError(
        language === "english"
          ? "An error occurred while submitting your complaint. Please try again."
          : "உங்கள் புகாரைச் சமர்ப்பிக்கும்போது பிழை ஏற்பட்டது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.",
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t("complaint.title")}</CardTitle>
      </CardHeader>
      <CardContent>
        {success ? (
          <Alert className="bg-green-50 border-green-200 mb-4">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-600">
              {language === "english"
                ? "Your complaint has been submitted successfully. We will contact you soon."
                : "உங்கள் புகார் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. நாங்கள் விரைவில் உங்களைத் தொடர்பு கொள்வோம்."}
            </AlertDescription>
          </Alert>
        ) : null}

        {error ? (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="details">{language === "english" ? "Details" : "விவரங்கள்"}</TabsTrigger>
              <TabsTrigger value="location">{language === "english" ? "Location" : "இடம்"}</TabsTrigger>
              <TabsTrigger value="evidence">{language === "english" ? "Evidence" : "ஆதாரம்"}</TabsTrigger>
              <TabsTrigger value="review">{language === "english" ? "Review" : "மதிப்பாய்வு"}</TabsTrigger>
            </TabsList>

            {/* Details Tab */}
            <TabsContent value="details" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="name">{t("complaint.name")} *</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="phone">{t("complaint.phone")} *</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder={
                    language === "english" ? "Enter 10-digit phone number" : "10-இலக்க தொலைபேசி எண்ணை உள்ளிடவும்"
                  }
                  required
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="address">{t("complaint.address")}</Label>
                <AddressAutocomplete
                  value={formData.address}
                  onChange={handleAddressChange}
                  placeholder={language === "english" ? "Enter your address" : "உங்கள் முகவரியை உள்ளிடவும்"}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="description">{t("complaint.description")} *</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={5}
                  required
                />
              </div>

              <div className="flex justify-between">
                <div></div>
                <Button type="button" onClick={() => setActiveTab("location")}>
                  {language === "english" ? "Next: Location" : "அடுத்து: இடம்"}
                </Button>
              </div>
            </TabsContent>

            {/* Location Tab */}
            <TabsContent value="location" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="incidentDate">{t("complaint.date")}</Label>
                <Input
                  id="incidentDate"
                  name="incidentDate"
                  type="date"
                  value={formData.incidentDate}
                  onChange={handleChange}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="incidentLocation">
                  {language === "english" ? "Incident Location (Select on Map)" : "சம்பவ இடம் (வரைபடத்தில் தேர்ந்தெடுக்கவும்)"}
                </Label>
                <LocationMap onLocationSelected={handleLocationSelected} initialLocation={coordinates || undefined} />
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("details")}>
                  {language === "english" ? "Back" : "பின்னால்"}
                </Button>
                <Button type="button" onClick={() => setActiveTab("evidence")}>
                  {language === "english" ? "Next: Evidence" : "அடுத்து: ஆதாரம்"}
                </Button>
              </div>
            </TabsContent>

            {/* Evidence Tab */}
            <TabsContent value="evidence" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="attachments">
                  {language === "english" ? "Upload Evidence (Optional)" : "ஆதாரங்களை பதிவேற்றவும் (விருப்பத்திற்குரியது)"}
                </Label>
                <FileUpload onFilesSelected={handleFilesSelected} />
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("location")}>
                  {language === "english" ? "Back" : "பின்னால்"}
                </Button>
                <Button type="button" onClick={() => setActiveTab("review")}>
                  {language === "english" ? "Next: Review" : "அடுத்து: மதிப்பாய்வு"}
                </Button>
              </div>
            </TabsContent>

            {/* Review Tab */}
            <TabsContent value="review" className="space-y-4">
              <div className="space-y-4 p-4 border rounded-md bg-gray-50">
                <h3 className="font-medium text-lg">
                  {language === "english" ? "Review Your Complaint" : "உங்கள் புகாரை மதிப்பாய்வு செய்யவும்"}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Name" : "பெயர்"}
                    </h4>
                    <p>{formData.name || "-"}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Phone" : "தொலைபேசி"}
                    </h4>
                    <p>{formData.phone || "-"}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Address" : "முகவரி"}
                    </h4>
                    <p>{formData.address || "-"}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Incident Date" : "சம்பவ தேதி"}
                    </h4>
                    <p>{formData.incidentDate || "-"}</p>
                  </div>

                  <div className="col-span-2">
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Incident Location" : "சம்பவ இடம்"}
                    </h4>
                    <p>{formData.incidentLocation || "-"}</p>
                  </div>

                  <div className="col-span-2">
                    <h4 className="font-medium text-sm text-gray-500 mb-1">
                      {language === "english" ? "Description" : "விளக்கம்"}
                    </h4>
                    <p className="whitespace-pre-wrap">{formData.description || "-"}</p>
                  </div>

                  {attachments.length > 0 && (
                    <div className="col-span-2">
                      <h4 className="font-medium text-sm text-gray-500 mb-1">
                        {language === "english" ? "Attachments" : "இணைப்புகள்"}
                      </h4>
                      <p>
                        {attachments.length} {language === "english" ? "files attached" : "கோப்புகள் இணைக்கப்பட்டுள்ளன"}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("evidence")}>
                  {language === "english" ? "Back" : "பின்னால்"}
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting
                    ? language === "english"
                      ? "Submitting..."
                      : "சமர்ப்பிக்கிறது..."
                    : language === "english"
                      ? "Submit Complaint"
                      : "புகாரை சமர்ப்பிக்கவும்"}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </form>

        {/* Previous Complaints */}
        {complaints.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-medium mb-4">{t("complaint.previous")}</h3>
            <div className="space-y-4">
              {complaints.map((complaint) => (
                <div key={complaint.id} className="p-4 border rounded-md">
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{complaint.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">
                        {new Date(complaint.createdAt).toLocaleDateString()}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteComplaint(complaint.id)}
                        className="h-8 w-8 text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm mb-2">{complaint.description.substring(0, 100)}...</div>
                  <div className="text-xs text-muted-foreground mb-2">
                    Status: <span className="font-medium capitalize">{complaint.status}</span>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => handleViewComplaint(complaint)}>
                          <FileText className="h-4 w-4 mr-2" />
                          {language === "english" ? "View Details" : "விவரங்களைக் காண"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>{language === "english" ? "Complaint Details" : "புகார் விவரங்கள்"}</DialogTitle>
                        </DialogHeader>
                        {selectedComplaint && (
                          <div className="space-y-4 mt-4">
                            <div className="flex justify-between">
                              <div>
                                <h3 className="font-medium">{language === "english" ? "Complaint ID" : "புகார் எண்"}</h3>
                                <p className="text-sm">{selectedComplaint.id}</p>
                              </div>
                              <div>
                                <h3 className="font-medium">{language === "english" ? "Date" : "தேதி"}</h3>
                                <p className="text-sm">{new Date(selectedComplaint.createdAt).toLocaleDateString()}</p>
                              </div>
                              <div>
                                <h3 className="font-medium">{language === "english" ? "Status" : "நிலை"}</h3>
                                <p className="text-sm capitalize">{selectedComplaint.status}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                              <div>
                                <h3 className="font-medium">{language === "english" ? "Name" : "பெயர்"}</h3>
                                <p className="text-sm">{selectedComplaint.name}</p>
                              </div>
                              <div>
                                <h3 className="font-medium">{language === "english" ? "Phone" : "தொலைபேசி"}</h3>
                                <p className="text-sm">{selectedComplaint.phone}</p>
                              </div>
                              {selectedComplaint.address && (
                                <div className="col-span-2">
                                  <h3 className="font-medium">{language === "english" ? "Address" : "முகவரி"}</h3>
                                  <p className="text-sm">{selectedComplaint.address}</p>
                                </div>
                              )}
                            </div>

                            <div className="border-t pt-4">
                              <h3 className="font-medium">
                                {language === "english" ? "Incident Details" : "சம்பவ விவரங்கள்"}
                              </h3>
                              {selectedComplaint.incidentDate && (
                                <div className="mt-2">
                                  <h4 className="text-sm font-medium">{language === "english" ? "Date" : "தேதி"}</h4>
                                  <p className="text-sm">{selectedComplaint.incidentDate}</p>
                                </div>
                              )}
                              {selectedComplaint.incidentLocation && (
                                <div className="mt-2">
                                  <h4 className="text-sm font-medium">{language === "english" ? "Location" : "இடம்"}</h4>
                                  <p className="text-sm">{selectedComplaint.incidentLocation}</p>
                                </div>
                              )}
                              <div className="mt-2">
                                <h4 className="text-sm font-medium">
                                  {language === "english" ? "Description" : "விளக்கம்"}
                                </h4>
                                <p className="text-sm whitespace-pre-wrap">{selectedComplaint.description}</p>
                              </div>
                            </div>

                            {selectedComplaint.attachments && selectedComplaint.attachments.length > 0 && (
                              <div className="border-t pt-4">
                                <h3 className="font-medium">{language === "english" ? "Attachments" : "இணைப்புகள்"}</h3>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                                  {selectedComplaint.attachments.map((attachment) => (
                                    <div key={attachment.id} className="flex items-center p-2 border rounded">
                                      {attachment.type.startsWith("image/") ? (
                                        <img
                                          src={attachment.dataUrl || "/placeholder.svg"}
                                          alt={attachment.name}
                                          className="h-10 w-10 object-cover mr-2"
                                        />
                                      ) : (
                                        <FileText className="h-10 w-10 p-2 mr-2" />
                                      )}
                                      <div className="overflow-hidden">
                                        <p className="text-sm font-medium truncate">{attachment.name}</p>
                                        <p className="text-xs text-gray-500">
                                          {(attachment.size / 1024).toFixed(1)} KB
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="border-t pt-4 flex flex-col sm:flex-row gap-4 justify-between">
                              <div>
                                <Button
                                  variant="outline"
                                  onClick={() => handleDownloadPDF(selectedComplaint)}
                                  className="flex items-center gap-2"
                                >
                                  <Download className="h-4 w-4" />
                                  {language === "english" ? "Download PDF" : "PDF பதிவிறக்கம்"}
                                </Button>
                              </div>

                              <div>
                                <QRCodeGenerator
                                  value={selectedComplaint.qrCode || `complaint:${selectedComplaint.id}`}
                                  title={language === "english" ? "Complaint QR Code" : "புகார் QR குறியீடு"}
                                  downloadFileName={`complaint-${selectedComplaint.id}`}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>

                    <Button variant="outline" size="sm" onClick={() => handleDownloadPDF(complaint)}>
                      <Download className="h-4 w-4 mr-2" />
                      {language === "english" ? "Download" : "பதிவிறக்கம்"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

