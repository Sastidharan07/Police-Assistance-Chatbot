"use client"

import { useLanguage } from "@/lib/language-context"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Shield, Lock } from "lucide-react"

export function PrivacyPolicy() {
  const { language } = useLanguage()

  return (
    <ScrollArea className="h-[60vh] w-full rounded-md border p-4">
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Lock className="h-5 w-5 text-primary" />
          <h2 className="text-2xl font-bold">{language === "english" ? "Privacy Policy" : "தனியுரிமைக் கொள்கை"}</h2>
        </div>

        <p className="text-sm text-muted-foreground">
          {language === "english" ? "Last Updated: April 2, 2023" : "கடைசியாக புதுப்பிக்கப்பட்டது: ஏப்ரல் 2, 2023"}
        </p>

        <div className="space-y-4">
          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "1. Introduction" : "1. அறிமுகம்"}</h3>
            <p>
              {language === "english"
                ? 'The Tamil Nadu Police Assistance Chatbot ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and services.'
                : 'தமிழ்நாடு காவல்துறை உதவி சாட்போட் ("நாங்கள்" அல்லது "எங்களுடைய") உங்கள் தனியுரிமையைப் பாதுகாப்பதில் உறுதியாக உள்ளது. இந்த தனியுரிமைக் கொள்கை நீங்கள் எங்கள் மொபைல் பயன்பாடு மற்றும் சேவைகளைப் பயன்படுத்தும்போது உங்கள் தகவல்களை எவ்வாறு சேகரிக்கிறோம், பயன்படுத்துகிறோம், வெளிப்படுத்துகிறோம் மற்றும் பாதுகாக்கிறோம் என்பதை விளக்குகிறது.'}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "2. Information We Collect" : "2. நாங்கள் சேகரிக்கும் தகவல்"}
            </h3>
            <p>
              {language === "english"
                ? "We may collect several types of information from and about users of our application, including:"
                : "எங்கள் பயன்பாட்டின் பயனர்களிடமிருந்து பல வகையான தகவல்களை நாங்கள் சேகரிக்கலாம், அவற்றில் அடங்குபவை:"}
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                {language === "english"
                  ? "Personal information such as name, email address, phone number, and address"
                  : "பெயர், மின்னஞ்சல் முகவரி, தொலைபேசி எண் மற்றும் முகவரி போன்ற தனிப்பட்ட தகவல்கள்"}
              </li>
              <li>
                {language === "english"
                  ? "Location data when you choose to share your location"
                  : "நீங்கள் உங்கள் இருப்பிடத்தைப் பகிர தேர்வு செய்யும்போது இருப்பிட தரவு"}
              </li>
              <li>
                {language === "english"
                  ? "Information about your device including IP address, device type, and operating system"
                  : "IP முகவரி, சாதன வகை மற்றும் இயக்க அமைப்பு உள்ளிட்ட உங்கள் சாதனம் பற்றிய தகவல்கள்"}
              </li>
              <li>
                {language === "english"
                  ? "Chat history and interactions with our chatbot"
                  : "எங்கள் சாட்போட்டுடனான அரட்டை வரலாறு மற்றும் தொடர்புகள்"}
              </li>
              <li>
                {language === "english"
                  ? "Complaints and emergency contact information you provide"
                  : "நீங்கள் வழங்கும் புகார்கள் மற்றும் அவசர தொடர்பு தகவல்கள்"}
              </li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "3. How We Use Your Information" : "3. உங்கள் தகவலை நாங்கள் எவ்வாறு பயன்படுத்துகிறோம்"}
            </h3>
            <p>
              {language === "english"
                ? "We use the information we collect to:"
                : "நாங்கள் சேகரிக்கும் தகவலை நாங்கள் பயன்படுத்துவது:"}
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                {language === "english"
                  ? "Provide, maintain, and improve our services"
                  : "எங்கள் சேவைகளை வழங்க, பராமரிக்க மற்றும் மேம்படுத்த"}
              </li>
              <li>
                {language === "english"
                  ? "Process and respond to your complaints and inquiries"
                  : "உங்கள் புகார்கள் மற்றும் விசாரணைகளை செயலாக்கி பதிலளிக்க"}
              </li>
              <li>
                {language === "english"
                  ? "Connect you with emergency services when needed"
                  : "தேவைப்படும்போது உங்களை அவசர சேவைகளுடன் இணைக்க"}
              </li>
              <li>
                {language === "english"
                  ? "Send you important notifications about your account or the application"
                  : "உங்கள் கணக்கு அல்லது பயன்பாடு பற்றிய முக்கியமான அறிவிப்புகளை உங்களுக்கு அனுப்ப"}
              </li>
              <li>
                {language === "english"
                  ? "Improve our chatbot's responses and user experience"
                  : "எங்கள் சாட்போட்டின் பதில்கள் மற்றும் பயனர் அனுபவத்தை மேம்படுத்த"}
              </li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "4. Data Storage and Security" : "4. தரவு சேமிப்பு மற்றும் பாதுகாப்பு"}
            </h3>
            <p>
              {language === "english"
                ? "Your data is primarily stored locally on your device. We implement appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security."
                : "உங்கள் தரவு முதன்மையாக உங்கள் சாதனத்தில் உள்ளூரில் சேமிக்கப்படுகிறது. உங்கள் தனிப்பட்ட தகவல்களை அங்கீகரிக்கப்படாத அணுகல், மாற்றம், வெளிப்பாடு அல்லது அழிப்பிலிருந்து பாதுகாக்க நாங்கள் பொருத்தமான பாதுகாப்பு நடவடிக்கைகளை செயல்படுத்துகிறோம். இருப்பினும், இணையம் அல்லது மின்னணு சேமிப்பகத்தின் மூலம் பரிமாற்றம் செய்யும் எந்த முறையும் 100% பாதுகாப்பானது அல்ல, மேலும் நாங்கள் முழுமையான பாதுகாப்பை உத்தரவாதம் அளிக்க முடியாது."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "5. Sharing Your Information" : "5. உங்கள் தகவலைப் பகிர்தல்"}
            </h3>
            <p>{language === "english" ? "We may share your information with:" : "உங்கள் தகவலை நாங்கள் பகிர்ந்து கொள்ளலாம்:"}</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                {language === "english"
                  ? "Law enforcement agencies when required by law or in emergency situations"
                  : "சட்டத்தால் தேவைப்படும்போது அல்லது அவசர சூழ்நிலைகளில் சட்ட அமலாக்க நிறுவனங்களுடன்"}
              </li>
              <li>
                {language === "english"
                  ? "Service providers who assist us in operating our application and providing services"
                  : "எங்கள் பயன்பாட்டை இயக்குவதிலும் சேவைகளை வழங்குவதிலும் எங்களுக்கு உதவும் சேவை வழங்குநர்களுடன்"}
              </li>
              <li>
                {language === "english"
                  ? "Government authorities when required for legal compliance"
                  : "சட்ட இணக்கத்திற்காக தேவைப்படும்போது அரசு அதிகாரிகளுடன்"}
              </li>
            </ul>
            <p>
              {language === "english"
                ? "We will not sell or rent your personal information to third parties for marketing purposes."
                : "உங்கள் தனிப்பட்ட தகவல்களை சந்தைப்படுத்தல் நோக்கங்களுக்காக மூன்றாம் தரப்பினருக்கு விற்கவோ வாடகைக்கு விடவோ மாட்டோம்."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "6. Your Rights" : "6. உங்கள் உரிமைகள்"}</h3>
            <p>{language === "english" ? "You have the right to:" : "உங்களுக்கு உரிமை உண்டு:"}</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                {language === "english"
                  ? "Access, update, or delete your personal information"
                  : "உங்கள் தனிப்பட்ட தகவல்களை அணுக, புதுப்பிக்க அல்லது நீக்க"}
              </li>
              <li>
                {language === "english" ? "Opt-out of receiving notifications" : "அறிவிப்புகளைப் பெறுவதிலிருந்து விலக"}
              </li>
              <li>{language === "english" ? "Disable location sharing" : "இருப்பிடப் பகிர்வை முடக்க"}</li>
              <li>{language === "english" ? "Request a copy of your data" : "உங்கள் தரவின் நகலைக் கோர"}</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "7. Changes to This Privacy Policy" : "7. இந்த தனியுரிமைக் கொள்கையில் மாற்றங்கள்"}
            </h3>
            <p>
              {language === "english"
                ? 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.'
                : 'நாங்கள் எங்கள் தனியுரிமைக் கொள்கையை அவ்வப்போது புதுப்பிக்கலாம். இந்தப் பக்கத்தில் புதிய தனியுரிமைக் கொள்கையை வெளியிடுவதன் மூலமும், "கடைசியாக புதுப்பிக்கப்பட்டது" தேதியைப் புதுப்பிப்பதன் மூலமும் எந்த மாற்றங்களையும் நாங்கள் உங்களுக்குத் தெரிவிப்போம்.'}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "8. Contact Us" : "8. எங்களை தொடர்பு கொள்ளுங்கள்"}
            </h3>
            <p>
              {language === "english"
                ? "If you have any questions about this Privacy Policy, please contact us at privacy@tnpolice.gov.in"
                : "இந்த தனியுரிமைக் கொள்கை பற்றி உங்களுக்கு ஏதேனும் கேள்விகள் இருந்தால், தயவுசெய்து privacy@tnpolice.gov.in இல் எங்களைத் தொடர்பு கொள்ளவும்"}
            </p>
          </section>
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <p className="text-sm text-muted-foreground">
              {language === "english"
                ? "© 2023 Tamil Nadu Police. All rights reserved."
                : "© 2023 தமிழ்நாடு காவல்துறை. அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை."}
            </p>
          </div>
        </div>
      </div>
    </ScrollArea>
  )
}

