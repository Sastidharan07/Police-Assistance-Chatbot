import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/lib/auth-context"
import { LanguageProvider } from "@/lib/language-context"
import { LocationProvider } from "@/lib/location-context"
import { EmergencyAlertProvider } from "@/lib/emergency-alert-context"
import { DraggableDangerButton } from "@/components/draggable-danger-button"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Police Assistance Chatbot",
  description: "A chatbot to assist citizens with police-related queries and services",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <AuthProvider>
            <LanguageProvider>
              <LocationProvider>
                <EmergencyAlertProvider>
                  {children}
                  <DraggableDangerButton />
                  <Toaster />
                </EmergencyAlertProvider>
              </LocationProvider>
            </LanguageProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'