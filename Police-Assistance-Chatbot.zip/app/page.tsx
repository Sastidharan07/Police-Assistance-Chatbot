"use client"

import { useState, useEffect } from "react"
import { LoginForm } from "@/components/login-form"
import { useAuthCheck } from "@/hooks/use-auth-check"

export default function LoginPage() {
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)
  const isAuthenticated = useAuthCheck(false) // Call the hook unconditionally

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // No need to call useAuthCheck here, it's already called unconditionally
      } catch (error) {
        console.warn("Auth check failed:", error)
      } finally {
        setIsCheckingAuth(false)
      }
    }

    checkAuth()
  }, [isAuthenticated])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 p-4">
      {!isCheckingAuth && <LoginForm />}
    </div>
  )
}

