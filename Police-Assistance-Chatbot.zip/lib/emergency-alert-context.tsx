"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useAuth } from "./auth-context"
import { useLocation } from "./location-context"
import { sendEmergencyAlert, cancelEmergencyAlert } from "./emergency-alert-service"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "./language-context"

interface EmergencyAlertContextType {
  isAlertActive: boolean
  isPending: boolean
  alertId: string | null
  sendAlert: () => Promise<boolean>
  cancelAlert: () => Promise<boolean>
  gracePeriodRemaining: number | null
  nearestPoliceStation: any | null
}

const EmergencyAlertContext = createContext<EmergencyAlertContextType | undefined>(undefined)

const GRACE_PERIOD_SECONDS = 10

export function EmergencyAlertProvider({ children }: { children: ReactNode }) {
  const { mobileNumber } = useAuth()
  const { location, requestLocation, formattedLocation, isLocating } = useLocation()
  const { toast } = useToast()
  const { language } = useLanguage()

  const [isAlertActive, setIsAlertActive] = useState(false)
  const [isPending, setIsPending] = useState(false)
  const [alertId, setAlertId] = useState<string | null>(null)
  const [gracePeriodRemaining, setGracePeriodRemaining] = useState<number | null>(null)
  const [gracePeriodInterval, setGracePeriodInterval] = useState<NodeJS.Timeout | null>(null)
  const [alertSound, setAlertSound] = useState<HTMLAudioElement | null>(null)
  const [nearestPoliceStation, setNearestPoliceStation] = useState<any | null>(null)
  const [locationRefreshAttempted, setLocationRefreshAttempted] = useState(false)

  // Initialize alert sound
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Create audio element
      const sound = new Audio("/alert-sound.mp3")

      // Configure audio
      sound.loop = true
      sound.volume = 0.7

      // Preload audio
      sound.load()

      // Add error handling
      sound.onerror = (e) => {
        console.error("Error loading alert sound:", e)
      }

      setAlertSound(sound)
    }

    return () => {
      if (alertSound) {
        alertSound.pause()
        alertSound.currentTime = 0
      }
    }
  }, [])

  // Check for active alerts on mount
  useEffect(() => {
    if (typeof window !== "undefined" && mobileNumber) {
      const alerts = JSON.parse(localStorage.getItem("emergencyAlerts") || "[]")
      const activeAlert = alerts.find((a: any) => a.userId === mobileNumber && a.status === "active")

      if (activeAlert) {
        setAlertId(activeAlert.alertId)
        setIsAlertActive(true)
        setNearestPoliceStation(activeAlert.policeStation)

        // Start playing alert sound
        if (alertSound) {
          alertSound.play().catch((err) => console.error("Could not play alert sound:", err))
        }
      }
    }
  }, [mobileNumber, alertSound])

  // Handle grace period countdown
  useEffect(() => {
    if (gracePeriodRemaining !== null && gracePeriodRemaining > 0) {
      const interval = setInterval(() => {
        setGracePeriodRemaining((prev) => {
          if (prev === null || prev <= 1) {
            clearInterval(interval)
            return 0
          }
          return prev - 1
        })
      }, 1000)

      setGracePeriodInterval(interval)

      return () => {
        clearInterval(interval)
      }
    } else if (gracePeriodRemaining === 0) {
      // Grace period expired, finalize the alert
      finalizeAlert()
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gracePeriodRemaining])

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (gracePeriodInterval) {
        clearInterval(gracePeriodInterval)
      }
      if (alertSound) {
        alertSound.pause()
        alertSound.currentTime = 0
      }
    }
  }, [gracePeriodInterval, alertSound])

  // Refresh location data when needed
  useEffect(() => {
    if (locationRefreshAttempted && !isLocating && location) {
      // Location has been refreshed, proceed with alert
      if (gracePeriodRemaining === 0) {
        finalizeAlert()
      }
      setLocationRefreshAttempted(false)
    }
  }, [location, isLocating, locationRefreshAttempted, gracePeriodRemaining])

  const finalizeAlert = async () => {
    if (!mobileNumber) {
      setIsPending(false)
      setGracePeriodRemaining(null)

      toast({
        title: language === "english" ? "Error" : "பிழை",
        description:
          language === "english"
            ? "Could not send alert. User information missing."
            : "எச்சரிக்கையை அனுப்ப முடியவில்லை. பயனர் தகவல் காணவில்லை.",
        variant: "destructive",
      })

      return false
    }

    // Check if we have location data
    if (!location) {
      // If we already tried to refresh location but still don't have it
      if (locationRefreshAttempted) {
        setIsPending(false)
        setGracePeriodRemaining(null)

        toast({
          title: language === "english" ? "Location Error" : "இருப்பிட பிழை",
          description:
            language === "english"
              ? "Could not determine your location. Please enable location services and try again."
              : "உங்கள் இருப்பிடத்தைக் கண்டறிய முடியவில்லை. இருப்பிட சேவைகளை இயக்கி மீண்டும் முயற்சிக்கவும்.",
          variant: "destructive",
        })

        return false
      }

      // Try to get location
      setLocationRefreshAttempted(true)
      requestLocation()
      return false
    }

    // Start playing alert sound
    if (alertSound) {
      alertSound.play().catch((err) => console.error("Could not play alert sound:", err))
    }

    const result = await sendEmergencyAlert(mobileNumber, location, formattedLocation || undefined)

    if (result.success && result.alertId) {
      setAlertId(result.alertId)
      setIsAlertActive(true)
      setIsPending(false)
      setNearestPoliceStation(result.policeStation)

      // Play success sound
      const successSound = new Audio("/alert-success.mp3")
      successSound.play().catch((err) => console.error("Could not play success sound:", err))

      toast({
        title: language === "english" ? "Emergency Alert Sent" : "அவசர எச்சரிக்கை அனுப்பப்பட்டது",
        description:
          language === "english"
            ? "Your emergency alert has been sent to all your emergency contacts and nearby police stations."
            : "உங்கள் அவசர எச்சரிக்கை உங்கள் அனைத்து அவசர தொடர்புகளுக்கும் அருகிலுள்ள காவல் நிலையங்களுக்கும் அனுப்பப்பட்டுள்ளது.",
        variant: "default",
        className: "bg-red-500 text-white font-bold",
      })

      return true
    } else {
      setIsPending(false)
      setGracePeriodRemaining(null)

      // Play error sound
      const errorSound = new Audio("/alert-error.mp3")
      errorSound.play().catch((err) => console.error("Could not play error sound:", err))

      toast({
        title: language === "english" ? "Alert Failed" : "எச்சரிக்கை தோல்வியடைந்தது",
        description:
          result.error ||
          (language === "english"
            ? "Failed to send emergency alert. Please try again."
            : "அவசர எச்சரிக்கையை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்."),
        variant: "destructive",
      })

      return false
    }
  }

  const sendAlert = async (): Promise<boolean> => {
    setIsPending(true)

    // First, get the latest location
    if (!location) {
      try {
        setLocationRefreshAttempted(true)
        await requestLocation()
      } catch (error) {
        console.error("Failed to get location:", error)
        setIsPending(false)

        toast({
          title: language === "english" ? "Location Error" : "இருப்பிட பிழை",
          description:
            language === "english"
              ? "Could not determine your location. Please enable location services."
              : "உங்கள் இருப்பிடத்தைக் கண்டறிய முடியவில்லை. இருப்பிட சேவைகளை இயக்கவும்.",
          variant: "destructive",
        })

        return false
      }
    }

    // Start grace period
    setGracePeriodRemaining(GRACE_PERIOD_SECONDS)

    // Play warning sound
    const warningSound = new Audio("/alert-warning.mp3")
    warningSound.play().catch((err) => console.error("Could not play warning sound:", err))

    toast({
      title: language === "english" ? "Emergency Alert Initiated" : "அவசர எச்சரிக்கை தொடங்கப்பட்டது",
      description:
        language === "english"
          ? `Alert will be sent in ${GRACE_PERIOD_SECONDS} seconds. Tap 'Cancel' to stop.`
          : `எச்சரிக்கை ${GRACE_PERIOD_SECONDS} வினாடிகளில் அனுப்பப்படும். நிறுத்த 'ரத்து செய்' ஐத் தட்டவும்.`,
      variant: "default",
      className: "bg-yellow-500 text-black font-bold",
    })

    return true
  }

  const cancelAlert = async (): Promise<boolean> => {
    // If we're still in grace period, just cancel the countdown
    if (gracePeriodRemaining !== null && gracePeriodRemaining > 0) {
      if (gracePeriodInterval) {
        clearInterval(gracePeriodInterval)
      }

      setGracePeriodRemaining(null)
      setIsPending(false)

      toast({
        title: language === "english" ? "Alert Cancelled" : "எச்சரிக்கை ரத்து செய்யப்பட்டது",
        description: language === "english" ? "Emergency alert has been cancelled." : "அவசர எச்சரிக்கை ரத்து செய்யப்பட்டது.",
        variant: "default",
      })

      return true
    }

    // If alert is active, try to cancel it
    if (isAlertActive && alertId) {
      setIsPending(true)

      const success = await cancelEmergencyAlert(alertId)

      if (success) {
        setIsAlertActive(false)
        setAlertId(null)
        setIsPending(false)
        setNearestPoliceStation(null)

        // Stop alert sound
        if (alertSound) {
          alertSound.pause()
          alertSound.currentTime = 0
        }

        toast({
          title: language === "english" ? "Alert Cancelled" : "எச்சரிக்கை ரத்து செய்யப்பட்டது",
          description:
            language === "english" ? "Your emergency alert has been cancelled." : "உங்கள் அவசர எச்சரிக்கை ரத்து செய்யப்பட்டது.",
          variant: "default",
        })

        return true
      } else {
        setIsPending(false)

        toast({
          title: language === "english" ? "Error" : "பிழை",
          description:
            language === "english" ? "Failed to cancel emergency alert." : "அவசர எச்சரிக்கையை ரத்து செய்ய முடியவில்லை.",
          variant: "destructive",
        })

        return false
      }
    }

    return false
  }

  return (
    <EmergencyAlertContext.Provider
      value={{
        isAlertActive,
        isPending,
        alertId,
        sendAlert,
        cancelAlert,
        gracePeriodRemaining,
        nearestPoliceStation,
      }}
    >
      {children}
    </EmergencyAlertContext.Provider>
  )
}

export function useEmergencyAlert() {
  const context = useContext(EmergencyAlertContext)
  if (context === undefined) {
    throw new Error("useEmergencyAlert must be used within an EmergencyAlertProvider")
  }
  return context
}

