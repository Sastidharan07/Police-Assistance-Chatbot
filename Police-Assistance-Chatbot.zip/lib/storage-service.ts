export interface EmergencyContact {
  id: string
  name: string
  phone: string
}

export interface FileAttachment {
  id: string
  name: string
  type: string
  size: number
  dataUrl: string
  createdAt: string
}

export interface Complaint {
  id: string
  name: string
  phone: string
  address: string
  incidentDate: string
  incidentLocation: string
  description: string
  createdAt: string
  status: "pending" | "processing" | "resolved"
  attachments: FileAttachment[]
  coordinates?: {
    lat: number
    lng: number
  }
  qrCode?: string
}

export interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: string
}

export interface UserProfile {
  username: string
  phoneNumber: string
  email: string
  address: string
  gender: "male" | "female" | "other" | ""
  dateOfBirth?: string
  profilePicture?: string
  createdAt: string
  lastUpdated: string
}

export interface UserSettings {
  theme: "light" | "dark" | "system"
  language: "english" | "tamil"
  notifications: {
    enabled: boolean
    emergencyAlerts: boolean
    complaintUpdates: boolean
    newsUpdates: boolean
  }
  accessibility: {
    fontSize: "small" | "medium" | "large"
    highContrast: boolean
  }
  privacy: {
    shareLocation: boolean
    saveHistory: boolean
  }
}

export interface UserData {
  emergencyContacts: EmergencyContact[]
  complaints: Complaint[]
  chatHistory: ChatMessage[]
  profile?: UserProfile
  settings?: UserSettings
}

// Get user data by mobile number
export const getUserData = (mobileNumber: string): UserData => {
  if (typeof window === "undefined") return { emergencyContacts: [], complaints: [], chatHistory: [] }

  const userData = localStorage.getItem(`userData_${mobileNumber}`)
  return userData ? JSON.parse(userData) : { emergencyContacts: [], complaints: [], chatHistory: [] }
}

// Save user data by mobile number
export const saveUserData = (mobileNumber: string, userData: UserData): void => {
  if (typeof window === "undefined") return

  localStorage.setItem(`userData_${mobileNumber}`, JSON.stringify(userData))
}

// Emergency Contacts Storage
export const getEmergencyContacts = (mobileNumber: string): EmergencyContact[] => {
  return getUserData(mobileNumber).emergencyContacts
}

export const saveEmergencyContact = (
  mobileNumber: string,
  contact: Omit<EmergencyContact, "id">,
): EmergencyContact | null => {
  const userData = getUserData(mobileNumber)

  // Check if we already have 5 contacts
  if (userData.emergencyContacts.length >= 5) {
    return null
  }

  // Check for duplicate phone numbers
  if (userData.emergencyContacts.some((c) => c.phone === contact.phone)) {
    return null
  }

  const newContact = {
    ...contact,
    id: Date.now().toString(),
  }

  userData.emergencyContacts.push(newContact)
  saveUserData(mobileNumber, userData)

  return newContact
}

export const deleteEmergencyContact = (mobileNumber: string, id: string): boolean => {
  const userData = getUserData(mobileNumber)
  const initialLength = userData.emergencyContacts.length

  userData.emergencyContacts = userData.emergencyContacts.filter((contact) => contact.id !== id)

  if (userData.emergencyContacts.length === initialLength) {
    return false
  }

  saveUserData(mobileNumber, userData)
  return true
}

// Complaints Storage
export const getComplaints = (mobileNumber: string): Complaint[] => {
  return getUserData(mobileNumber).complaints
}

export const saveComplaint = (
  mobileNumber: string,
  complaint: Omit<Complaint, "id" | "createdAt" | "status" | "attachments" | "qrCode"> & {
    attachments?: FileAttachment[]
  },
): Complaint => {
  const userData = getUserData(mobileNumber)

  const newComplaint = {
    ...complaint,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    status: "pending" as const,
    attachments: complaint.attachments || [],
  }

  userData.complaints.push(newComplaint)
  saveUserData(mobileNumber, userData)

  return newComplaint
}

// Function to update an existing complaint
export const updateComplaint = (
  mobileNumber: string,
  complaintId: string,
  updates: Partial<Complaint>,
): Complaint | null => {
  const userData = getUserData(mobileNumber)
  const complaintIndex = userData.complaints.findIndex((c) => c.id === complaintId)

  if (complaintIndex === -1) return null

  userData.complaints[complaintIndex] = {
    ...userData.complaints[complaintIndex],
    ...updates,
  }

  saveUserData(mobileNumber, userData)
  return userData.complaints[complaintIndex]
}

// Chat History Storage
export const getChatHistory = (mobileNumber: string): ChatMessage[] => {
  return getUserData(mobileNumber).chatHistory
}

export const saveChatMessage = (mobileNumber: string, message: Omit<ChatMessage, "id" | "timestamp">): ChatMessage => {
  const userData = getUserData(mobileNumber)

  const newMessage = {
    ...message,
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
  }

  userData.chatHistory.push(newMessage)
  saveUserData(mobileNumber, userData)

  return newMessage
}

// Clear chat history
export const clearChatHistory = (mobileNumber: string): void => {
  const userData = getUserData(mobileNumber)
  userData.chatHistory = []
  saveUserData(mobileNumber, userData)
}

// User Profile Management
export const getUserProfile = (mobileNumber: string): UserProfile | null => {
  const userData = getUserData(mobileNumber)
  return userData.profile || null
}

export const saveUserProfile = (mobileNumber: string, profile: Partial<UserProfile>): UserProfile => {
  const userData = getUserData(mobileNumber)

  const now = new Date().toISOString()

  const updatedProfile = {
    username: "",
    phoneNumber: mobileNumber,
    email: "",
    address: "",
    gender: "",
    createdAt: userData.profile?.createdAt || now,
    lastUpdated: now,
    ...userData.profile,
    ...profile,
  } as UserProfile

  userData.profile = updatedProfile
  saveUserData(mobileNumber, userData)

  return updatedProfile
}

// User Settings Management
export const getUserSettings = (mobileNumber: string): UserSettings => {
  const userData = getUserData(mobileNumber)

  // Default settings
  const defaultSettings: UserSettings = {
    theme: "system",
    language: "english",
    notifications: {
      enabled: true,
      emergencyAlerts: true,
      complaintUpdates: true,
      newsUpdates: false,
    },
    accessibility: {
      fontSize: "medium",
      highContrast: false,
    },
    privacy: {
      shareLocation: true,
      saveHistory: true,
    },
  }

  return userData.settings || defaultSettings
}

export const saveUserSettings = (mobileNumber: string, settings: Partial<UserSettings>): UserSettings => {
  const userData = getUserData(mobileNumber)
  const currentSettings = userData.settings || getUserSettings(mobileNumber)

  const updatedSettings = {
    ...currentSettings,
    ...settings,
    notifications: {
      ...currentSettings.notifications,
      ...(settings.notifications || {}),
    },
    accessibility: {
      ...currentSettings.accessibility,
      ...(settings.accessibility || {}),
    },
    privacy: {
      ...currentSettings.privacy,
      ...(settings.privacy || {}),
    },
  }

  userData.settings = updatedSettings
  saveUserData(mobileNumber, userData)

  return updatedSettings
}

// Function to simulate OTP generation for a mobile number
export const generateOTP = (mobileNumber: string): string => {
  // In a real app, this would send an actual OTP to the mobile number
  // For demo purposes, we'll generate a random 6-digit OTP
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// Function to get AI response - simplified without Gemini
export const getAIResponse = async (message: string, language: "english" | "tamil"): Promise<string> => {
  try {
    // Call our local API endpoint
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ messages: [{ role: "user", content: message }], language }),
    })

    if (!response.ok) {
      throw new Error(`API responded with status: ${response.status}`)
    }

    const text = await response.text()
    return text
  } catch (error) {
    console.error("Failed to get AI response:", error)
    return language === "english"
      ? "I'm sorry, I couldn't process your request at the moment. Please try again later."
      : "மன்னிக்கவும், இப்போது உங்கள் கோரிக்கையை செயலாக்க முடியவில்லை. பின்னர் மீண்டும் முயற்சிக்கவும்."
  }
}

// Offline FAQ data
export interface FAQ {
  question: string
  answer: {
    english: string
    tamil: string
  }
  keywords: string[]
}

export const offlineFAQs: FAQ[] = [
  {
    question: "How do I file an FIR?",
    answer: {
      english:
        "To file an FIR (First Information Report), visit your nearest police station. Provide your personal details and describe the incident in detail. The officer will record your statement and give you a copy of the FIR with a reference number.",
      tamil:
        "FIR (முதல் தகவல் அறிக்கை) தாக்கல் செய்ய, உங்களுக்கு அருகிலுள்ள காவல் நிலையத்திற்குச் செல்லவும். உங்கள் தனிப்பட்ட விவரங்களை வழங்கி சம்பவத்தை விரிவாக விவரிக்கவும். அதிகாரி உங்கள் அறிக்கையைப் பதிவு செய்து, குறிப்பு எண்ணுடன் FIR நகலை உங்களுக்கு வழங்குவார்.",
    },
    keywords: ["fir", "file", "report", "complaint", "police report"],
  },
  {
    question: "What are the emergency police numbers?",
    answer: {
      english:
        "The main emergency police number in India is 100. For women's helpline, call 1091. For traffic police, call 103. For anti-corruption, call 1064.",
      tamil:
        "இந்தியாவில் முக்கிய அவசர காவல்துறை எண் 100. பெண்கள் உதவி எண்ணிற்கு, 1091 ஐ அழைக்கவும். போக்குவரத்து காவல்துறைக்கு, 103 ஐ அழைக்கவும். ஊழல் எதிர்ப்புக்கு, 1064 ஐ அழைக்கவும்.",
    },
    keywords: ["emergency", "number", "helpline", "contact", "police number"],
  },
  {
    question: "What is the punishment for theft?",
    answer: {
      english:
        "Under Section 379 of the Indian Penal Code, theft is punishable with imprisonment up to 3 years, or with fine, or both. The exact punishment depends on the value of stolen property and circumstances of the theft.",
      tamil:
        "இந்திய தண்டனைச் சட்டத்தின் பிரிவு 379 இன் கீழ், திருட்டுக்கு 3 ஆண்டுகள் வரை சிறைத்தண்டனை அல்லது அபராதம் அல்லது இரண்டும் விதிக்கப்படலாம். சரியான தண்டனை திருடப்பட்ட சொத்தின் மதிப்பு மற்றும் திருட்டின் சூழ்நிலைகளைப் பொறுத்தது.",
    },
    keywords: ["theft", "punishment", "penalty", "jail", "fine", "stolen"],
  },
  {
    question: "How long can police keep me in custody?",
    answer: {
      english:
        "Police can keep a person in custody for a maximum of 24 hours without producing them before a magistrate. After 24 hours, they must either release the person or produce them before a magistrate who may authorize further detention.",
      tamil:
        "காவல்துறையினர் ஒரு நபரை நீதிபதி முன் ஆஜர்படுத்தாமல் அதிகபட்சம் 24 மணி நேரம் வரை காவலில் வைத்திருக்கலாம். 24 மணி நேரத்திற்குப் பிறகு, அவர்கள் அந்த நபரை விடுவிக்க வேண்டும் அல்லது மேலும் தடுப்புக்காவலை அங்கீகரிக்கக்கூடிய நீதிபதி முன் ஆஜர்படுத்த வேண்டும்.",
    },
    keywords: ["custody", "arrest", "detention", "jail", "police custody", "rights"],
  },
  {
    question: "What should I do if I witness a crime?",
    answer: {
      english:
        "If you witness a crime, ensure your safety first. Call the police emergency number (100) immediately. Note down details like time, location, description of persons involved, and vehicle numbers if applicable. Cooperate with police investigation and be willing to provide a statement.",
      tamil:
        "நீங்கள் ஒரு குற்றத்தைப் பார்த்தால், முதலில் உங்கள் பாதுகாப்பை உறுதிப்படுத்திக் கொள்ளுங்கள். உடனடியாக காவல்துறை அவசர எண்ணை (100) அழைக்கவும். நேரம், இடம், சம்பந்தப்பட்ட நபர்களின் விவரம் மற்றும் பொருந்தக்கூடிய வாகன எண்கள் போன்ற விவரங்களைக் குறித்து வைக்கவும். காவல்துறை விசாரணையில் ஒத்துழைத்து அறிக்கை அளிக்க தயாராக இருங்கள்.",
    },
    keywords: ["witness", "crime", "report", "saw", "observed"],
  },
]

// Function to search offline FAQs
export const searchOfflineFAQs = (query: string, language: "english" | "tamil"): string | null => {
  const normalizedQuery = query.toLowerCase()

  for (const faq of offlineFAQs) {
    // Check if query contains any keywords
    if (faq.keywords.some((keyword) => normalizedQuery.includes(keyword.toLowerCase()))) {
      return faq.answer[language]
    }

    // Check if query is similar to the question
    if (normalizedQuery.includes(faq.question.toLowerCase())) {
      return faq.answer[language]
    }
  }

  return null
}

