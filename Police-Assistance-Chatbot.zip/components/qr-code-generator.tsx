"use client"

import { QRCodeSVG } from "qrcode.react"
import { Button } from "@/components/ui/button"
import { Download, Share2 } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface QRCodeGeneratorProps {
  value: string
  size?: number
  title?: string
  downloadFileName?: string
}

export function QRCodeGenerator({ value, size = 128, title, downloadFileName = "qr-code" }: QRCodeGeneratorProps) {
  const { language } = useLanguage()

  const downloadQRCode = () => {
    const canvas = document.getElementById("qr-code-canvas") as HTMLCanvasElement
    if (!canvas) return

    const url = canvas.toDataURL("image/png")
    const link = document.createElement("a")
    link.href = url
    link.download = `${downloadFileName}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const shareQRCode = async () => {
    if (!navigator.share) {
      alert(language === "english" ? "Sharing is not supported on this device" : "இந்த சாதனத்தில் பகிர்வு ஆதரிக்கப்படவில்லை")
      return
    }

    try {
      const canvas = document.getElementById("qr-code-canvas") as HTMLCanvasElement
      if (!canvas) return

      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob)
        }, "image/png")
      })

      const file = new File([blob], `${downloadFileName}.png`, { type: "image/png" })

      await navigator.share({
        title: title || (language === "english" ? "QR Code" : "QR குறியீடு"),
        files: [file],
      })
    } catch (error) {
      console.error("Error sharing QR code:", error)
    }
  }

  return (
    <div className="flex flex-col items-center p-4 border rounded-lg bg-white">
      {title && <h3 className="text-lg font-medium mb-3">{title}</h3>}

      <div className="bg-white p-2 rounded-lg shadow-sm mb-4">
        <QRCodeSVG
          id="qr-code-canvas"
          value={value}
          size={size}
          level="H"
          includeMargin
          bgColor="#FFFFFF"
          fgColor="#000000"
        />
      </div>

      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={downloadQRCode}>
          <Download className="h-4 w-4 mr-2" />
          {language === "english" ? "Download" : "பதிவிறக்கம்"}
        </Button>

        {navigator.share && (
          <Button variant="outline" size="sm" onClick={shareQRCode}>
            <Share2 className="h-4 w-4 mr-2" />
            {language === "english" ? "Share" : "பகிர்"}
          </Button>
        )}
      </div>
    </div>
  )
}

