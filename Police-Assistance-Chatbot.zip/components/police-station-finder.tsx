"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { useLanguage } from "@/lib/language-context"
import { useLocation } from "@/lib/location-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Loader2, MapPin, Navigation, AlertTriangle, Phone, X, CheckCircle, RefreshCw, Shield } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import L from "leaflet"

// Update the PoliceStation interface to include a visible property
interface PoliceStation {
  name: string
  distance: number
  lat: number
  lon: number
  address: string
  visible?: boolean
  inTamilNadu?: boolean
}

// Tamil Nadu boundaries (approximate)
const TAMIL_NADU_BOUNDS = {
  north: 13.496,
  south: 8.077,
  east: 80.347,
  west: 76.23,
}

// Progressive search radii in kilometers
const SEARCH_RADII = [5, 10, 15, 20, 50, 100]

export function PoliceStationFinder() {
  const { t, language } = useLanguage()
  const { location, locationError, isLocating, requestLocation, formattedLocation } = useLocation()
  const [isSearching, setIsSearching] = useState(false)
  const [nearbyStations, setNearbyStations] = useState<PoliceStation[]>([])
  const [selectedStation, setSelectedStation] = useState<PoliceStation | null>(null)
  const [showDirections, setShowDirections] = useState(false)
  const [isSendingAlert, setIsSendingAlert] = useState(false)
  const [alertSent, setAlertSent] = useState(false)
  const [alertError, setAlertError] = useState<string | null>(null)
  const [alertSentTimestamp, setAlertSentTimestamp] = useState<Date | null>(null)
  const [alertCooldown, setAlertCooldown] = useState(false)
  const [cooldownRemaining, setCooldownRemaining] = useState(0)
  const [mapInitialized, setMapInitialized] = useState(false) // Track if map is initialized
  const mapRef = useRef<HTMLDivElement>(null)
  const leafletMap = useRef<L.Map | null>(null)
  const routingControl = useRef<any>(null)
  const { toast } = useToast()

  // Add CSS for pulse animation - moved inside the component
  useEffect(() => {
    const style = document.createElement("style")
    style.textContent = `
      .pulse-animation {
        animation: pulse 1.5s infinite;
      }
      @keyframes pulse {
        0% {
          box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
        }
        70% {
          box-shadow: 0 0 0 10px rgba(59, 130, 246, 0);
        }
        100% {
          box-shadow: 0 0 0 0 rgba(59, 130, 246, 0);
        }
      }
    `
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(style)
    }
  }, [])

  // Initialize map when component mounts
  useEffect(() => {
    if (typeof window !== "undefined" && mapRef.current && !leafletMap.current && !mapInitialized) {
      // Default view centered on Tamil Nadu
      leafletMap.current = L.map(mapRef.current).setView([10.7905, 78.7047], 7) // Center of Tamil Nadu

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(leafletMap.current)

      // Add Tamil Nadu boundary (simplified)
      const tamilNaduBounds = [
        [TAMIL_NADU_BOUNDS.north, TAMIL_NADU_BOUNDS.east],
        [TAMIL_NADU_BOUNDS.north, TAMIL_NADU_BOUNDS.west],
        [TAMIL_NADU_BOUNDS.south, TAMIL_NADU_BOUNDS.west],
        [TAMIL_NADU_BOUNDS.south, TAMIL_NADU_BOUNDS.east],
      ]

      L.polygon(tamilNaduBounds, {
        color: "#3b82f6",
        fillColor: "#3b82f680",
        fillOpacity: 0.1,
        weight: 2,
      }).addTo(leafletMap.current)

      setMapInitialized(true) // Mark map as initialized
    }

    return () => {
      if (leafletMap.current) {
        leafletMap.current.remove()
        leafletMap.current = null
        setMapInitialized(false) // Reset map initialization status
      }
    }
  }, [mapInitialized])

  // Check if coordinates are within Tamil Nadu
  const isInTamilNadu = (lat: number, lon: number): boolean => {
    return (
      lat <= TAMIL_NADU_BOUNDS.north &&
      lat >= TAMIL_NADU_BOUNDS.south &&
      lon <= TAMIL_NADU_BOUNDS.east &&
      lon >= TAMIL_NADU_BOUNDS.west
    )
  }

  // Update map when location changes
  useEffect(() => {
    if (location && leafletMap.current) {
      // Center map on user location
      leafletMap.current.setView([location.latitude, location.longitude], 10)

      // Add marker for user location
      const userIcon = L.divIcon({
        html: `<div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-md pulse-animation"></div>`,
        className: "user-location-marker",
        iconSize: [20, 20],
      })

      L.marker([location.latitude, location.longitude], { icon: userIcon })
        .addTo(leafletMap.current)
        .bindPopup(language === "english" ? "Your Location" : "உங்கள் இருப்பிடம்")
        .openPopup()

      // Find nearby police stations
      findNearbyPoliceStations()
    }
  }, [location])

  // Clean up routing control when directions are hidden
  useEffect(() => {
    if (!showDirections && routingControl.current && leafletMap.current) {
      leafletMap.current.removeControl(routingControl.current)
      routingControl.current = null
    }
  }, [showDirections])

  // Reset alert status after 30 seconds
  useEffect(() => {
    if (alertSent) {
      const timer = setTimeout(() => {
        setAlertSent(false)
      }, 30000)
      return () => clearTimeout(timer)
    }
  }, [alertSent])

  // Handle cooldown timer for SOS button
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (alertCooldown && alertSentTimestamp) {
      // Set cooldown period to 5 minutes (300 seconds)
      const cooldownPeriod = 300

      interval = setInterval(() => {
        const now = new Date()
        const elapsedSeconds = Math.floor((now.getTime() - alertSentTimestamp.getTime()) / 1000)
        const remaining = cooldownPeriod - elapsedSeconds

        if (remaining <= 0) {
          setAlertCooldown(false)
          setCooldownRemaining(0)
          clearInterval(interval)
        } else {
          setCooldownRemaining(remaining)
        }
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [alertCooldown, alertSentTimestamp])

  // Format remaining cooldown time
  const formatCooldownTime = useCallback((seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }, [])

  // Find nearby police stations using Nominatim API with progressive radius
  const findNearbyPoliceStations = async () => {
    if (!location) return

    setIsSearching(true)
    setNearbyStations([])

    // Start with the smallest radius and progressively increase if no stations found
    let foundStations: PoliceStation[] = []
    let currentRadiusIndex = 0

    try {
      while (foundStations.length === 0 && currentRadiusIndex < SEARCH_RADII.length) {
        const currentRadius = SEARCH_RADII[currentRadiusIndex]

        // Update UI to show current search radius
        toast({
          title: language === "english" ? "Searching..." : "தேடுகிறது...",
          description:
            language === "english"
              ? `Searching for police stations within ${currentRadius}km`
              : `${currentRadius}கிமீ க்குள் காவல் நிலையங்களைத் தேடுகிறது`,
          variant: "default",
        })

        // Specifically target Tamil Nadu police stations
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?q=police+station+Tamil+Nadu&format=json&limit=20&addressdetails=1&lat=${location.latitude}&lon=${location.longitude}`,
        )

        if (!response.ok) throw new Error("Failed to fetch police stations")

        const data = await response.json()

        // Process and sort police stations by distance
        const stations: PoliceStation[] = data
          .filter((item: any) => item.lat && item.lon)
          .map((item: any) => {
            const lat = Number.parseFloat(item.lat)
            const lon = Number.parseFloat(item.lon)
            const distance = calculateDistance(location.latitude, location.longitude, lat, lon)

            const inTamilNadu = isInTamilNadu(lat, lon)

            return {
              name: item.name || (language === "english" ? "Police Station" : "காவல் நிலையம்"),
              distance,
              lat,
              lon,
              address: item.display_name || "",
              visible: distance <= currentRadius, // Only show stations within current radius
              inTamilNadu,
            }
          })
          .filter((station) => station.visible && station.inTamilNadu) // Filter stations within current radius and in Tamil Nadu
          .sort((a, b) => a.distance - b.distance)

        foundStations = stations

        // If no stations found, increase the radius
        if (foundStations.length === 0) {
          currentRadiusIndex++
        }
      }

      // Set the found stations
      setNearbyStations(foundStations)

      // Get the final search radius used
      const finalRadius = SEARCH_RADII[Math.min(currentRadiusIndex, SEARCH_RADII.length - 1)]

      // Add markers for police stations
      if (leafletMap.current) {
        // Clear existing markers first
        leafletMap.current.eachLayer((layer) => {
          if (layer instanceof L.Marker) {
            leafletMap.current?.removeLayer(layer)
          }
        })

        // Add user location marker again
        const userIcon = L.divIcon({
          html: `<div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-md pulse-animation"></div>`,
          className: "user-location-marker",
          iconSize: [20, 20],
        })

        L.marker([location.latitude, location.longitude], { icon: userIcon })
          .addTo(leafletMap.current)
          .bindPopup(language === "english" ? "Your Location" : "உங்கள் இருப்பிடம்")

        // Add markers for police stations within search radius and in Tamil Nadu
        foundStations.forEach((station) => {
          const stationIcon = L.divIcon({
            html: `<div class="w-5 h-5 bg-red-500 rounded-full border-2 border-white shadow-md flex items-center justify-center text-white text-xs">P</div>`,
            className: "police-station-marker",
            iconSize: [24, 24],
          })

          L.marker([station.lat, station.lon], { icon: stationIcon })
            .addTo(leafletMap.current!)
            .bindPopup(`<b>${station.name}</b><br>${station.address}<br>${station.distance.toFixed(2)} km away`)
        })

        // If stations found, fit bounds to include all markers
        if (foundStations.length > 0) {
          const bounds = L.latLngBounds([
            [location.latitude, location.longitude],
            ...foundStations.map((s) => [s.lat, s.lon]),
          ])
          leafletMap.current.fitBounds(bounds, { padding: [50, 50] })
        }
      }

      // Show message if no stations found within maximum radius in Tamil Nadu
      if (foundStations.length === 0) {
        toast({
          title: language === "english" ? "No Police Stations Found" : "காவல் நிலையங்கள் எதுவும் கண்டறியப்படவில்லை",
          description:
            language === "english"
              ? `No Tamil Nadu police stations found within ${SEARCH_RADII[SEARCH_RADII.length - 1]}km of your location.`
              : `உங்கள் இருப்பிடத்திலிருந்து ${SEARCH_RADII[SEARCH_RADII.length - 1]}கிமீ தொலைவில் தமிழ்நாடு காவல் நிலையங்கள் எதுவும் கண்டறியப்படவில்லை.`,
          variant: "warning",
        })
      } else {
        // Show success message with the radius that found stations
        toast({
          title: language === "english" ? "Police Stations Found" : "காவல் நிலையங்கள் கண்டறியப்பட்டன",
          description:
            language === "english"
              ? `Found ${foundStations.length} police station${foundStations.length > 1 ? "s" : ""} within ${finalRadius}km.`
              : `${finalRadius}கிமீ க்குள் ${foundStations.length} காவல் நிலையம் கண்டறியப்பட்டது.`,
          variant: "success",
        })
      }
    } catch (error) {
      console.error("Error finding police stations:", error)
      toast({
        title: language === "english" ? "Error" : "பிழை",
        description:
          language === "english"
            ? "Failed to find nearby police stations. Please try again."
            : "அருகிலுள்ள காவல் நிலையங்களைக் கண்டறிய முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  // Calculate distance between two coordinates in kilometers
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371 // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1)
    const dLon = deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  const deg2rad = (deg: number): number => {
    return deg * (Math.PI / 180)
  }

  // Show directions to selected police station
  const showDirectionsToStation = (station: PoliceStation) => {
    if (!location || !leafletMap.current) return

    setSelectedStation(station)
    setShowDirections(true)

    // Remove existing routing control if any
    if (routingControl.current) {
      leafletMap.current.removeControl(routingControl.current)
    }

    // Add Leaflet Routing Machine control
    // Note: In a real app, you would need to include the Leaflet Routing Machine library
    // For this demo, we'll simulate the routing with a simple polyline
    const userLatLng = L.latLng(location.latitude, location.longitude)
    const stationLatLng = L.latLng(station.lat, station.lon)

    const routeLine = L.polyline([userLatLng, stationLatLng], { color: "blue", weight: 4 })
    routeLine.addTo(leafletMap.current)

    // Fit bounds to show the entire route
    const bounds = L.latLngBounds([userLatLng, stationLatLng])
    leafletMap.current.fitBounds(bounds, { padding: [50, 50] })

    // Store reference to remove later
    routingControl.current = {
      remove: () => {
        if (leafletMap.current) {
          leafletMap.current.removeLayer(routeLine)
        }
      },
    }
  }

  // Hide directions and reset view
  const hideDirections = () => {
    setShowDirections(false)
    setSelectedStation(null)

    if (routingControl.current && leafletMap.current) {
      leafletMap.current.removeControl(routingControl.current)
      routingControl.current = null
    }

    // Reset map view to user location
    if (location && leafletMap.current) {
      leafletMap.current.setView([location.latitude, location.longitude], 10)
    }
  }

  // Reset SOS alert state to allow sending another alert
  const resetSOSAlert = () => {
    setAlertCooldown(false)
    setAlertSent(false)
    setAlertError(null)
    setCooldownRemaining(0)
    setAlertSentTimestamp(null)

    toast({
      title: language === "english" ? "SOS Alert Reset" : "SOS எச்சரிக்கை மீட்டமைக்கப்பட்டது",
      description:
        language === "english"
          ? "You can now send another SOS alert if needed."
          : "தேவைப்பட்டால் இப்போது மற்றொரு SOS எச்சரிக்கையை அனுப்பலாம்.",
    })
  }

  // Send SOS alert to nearest police station - immediately without confirmation
  const sendSOSAlert = async () => {
    // Check if alert is in cooldown period
    if (alertCooldown) {
      toast({
        title: language === "english" ? "Alert Already Sent" : "எச்சரிக்கை ஏற்கனவே அனுப்பப்பட்டது",
        description:
          language === "english"
            ? `Please wait ${formatCooldownTime(cooldownRemaining)} before sending another alert.`
            : `மற்றொரு எச்சரிக்கையை அனுப்புவதற்கு முன் ${formatCooldownTime(cooldownRemaining)} காத்திருக்கவும்.`,
        variant: "warning",
      })
      return
    }

    if (!location) {
      toast({
        title: language === "english" ? "Location Required" : "இருப்பிடம் தேவை",
        description:
          language === "english"
            ? "Please enable location services to send an SOS alert."
            : "SOS எச்சரிக்கையை அனுப்ப இருப்பிட சேவைகளை இயக்கவும்.",
        variant: "destructive",
      })
      return
    }

    // Immediately start sending the alert
    setIsSendingAlert(true)
    setAlertError(null)

    try {
      // In a real app, this would send an actual alert to emergency services
      // For this demo, we'll simulate the process with a timeout
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Get the nearest police station if available
      const nearestStation = nearbyStations.length > 0 ? nearbyStations[0] : null

      // Prepare alert data with user's location
      const alertData = {
        location: {
          latitude: location.latitude,
          longitude: location.longitude,
          address: formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`,
        },
        timestamp: new Date().toISOString(),
        targetStation: nearestStation
          ? {
              name: nearestStation.name,
              distance: nearestStation.distance,
              coordinates: [nearestStation.lat, nearestStation.lon],
            }
          : null,
      }

      console.log("SOS Alert sent with data:", alertData)

      // Simulate successful alert
      setAlertSent(true)
      setAlertCooldown(true)
      setAlertSentTimestamp(new Date())

      // Show success toast
      toast({
        title: language === "english" ? "SOS Alert Sent" : "SOS எச்சரிக்கை அனுப்பப்பட்டது",
        description:
          language === "english"
            ? nearestStation
              ? `Emergency alert sent to ${nearestStation.name} (${nearestStation.distance.toFixed(2)}km away)`
              : "Emergency alert sent to Tamil Nadu Police control room"
            : nearestStation
              ? `அவசர எச்சரிக்கை ${nearestStation.name} (${nearestStation.distance.toFixed(2)}கிமீ தொலைவில்) க்கு அனுப்பப்பட்டது`
              : "அவசர எச்சரிக்கை தமிழ்நாடு காவல்துறை கட்டுப்பாட்டு அறைக்கு அனுப்பப்பட்டது",
        variant: "success",
      })
    } catch (error) {
      console.error("Error sending SOS alert:", error)
      setAlertError(
        language === "english"
          ? "Failed to send SOS alert. Please try again or call emergency services directly."
          : "SOS எச்சரிக்கையை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும் அல்லது நேரடியாக அவசர சேவைகளை அழைக்கவும்.",
      )

      toast({
        title: language === "english" ? "Alert Failed" : "எச்சரிக்கை தோல்வியடைந்தது",
        description:
          language === "english"
            ? "Failed to send SOS alert. Please try again or call emergency services directly."
            : "SOS எச்சரிக்கையை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும் அல்லது நேரடியாக அவசர சேவைகளை அழைக்கவும்.",
        variant: "destructive",
      })
    } finally {
      setIsSendingAlert(false)
    }
  }

  return (
    <div className="flex flex-col space-y-4 w-full">
      <Card className="w-full shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl flex items-center">
            <Shield className="h-5 w-5 mr-2 text-primary" />
            {language === "english" ? "Tamil Nadu Police Station Finder" : "தமிழ்நாடு காவல் நிலைய கண்டுபிடிப்பான்"}
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Location status */}
          <div className="flex flex-col space-y-2">
            {location ? (
              <div className="text-sm bg-green-50 p-3 rounded-md border border-green-200 flex items-start">
                <MapPin className="h-4 w-4 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium text-green-700">
                    {language === "english" ? "Location Found" : "இருப்பிடம் கண்டறியப்பட்டது"}
                  </p>
                  <p className="text-green-600 text-xs mt-1 break-words">{formattedLocation}</p>
                </div>
              </div>
            ) : locationError ? (
              <div className="text-sm bg-red-50 p-3 rounded-md border border-red-200 flex items-start">
                <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium text-red-700">
                    {language === "english" ? "Location Error" : "இருப்பிட பிழை"}
                  </p>
                  <p className="text-red-600 text-xs mt-1">{locationError}</p>
                </div>
              </div>
            ) : (
              <div className="text-sm bg-blue-50 p-3 rounded-md border border-blue-200">
                <p className="font-medium text-blue-700">
                  {language === "english"
                    ? "Location services are required to find nearby police stations"
                    : "அருகிலுள்ள காவல் நிலையங்களைக் கண்டறிய இருப்பிட சேவைகள் தேவை"}
                </p>
              </div>
            )}
          </div>

          {/* Map container */}
          <div ref={mapRef} className="w-full h-[300px] rounded-md border shadow-sm overflow-hidden"></div>

          {/* Location and search buttons */}
          <div className="flex flex-wrap gap-2">
            <Button onClick={requestLocation} disabled={isLocating} className="flex-1">
              {isLocating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <MapPin className="h-4 w-4 mr-2" />}
              {language === "english" ? "Get My Location" : "என் இருப்பிடத்தைப் பெறு"}
            </Button>

            <Button
              onClick={findNearbyPoliceStations}
              disabled={isSearching || !location}
              variant="secondary"
              className="flex-1"
            >
              {isSearching ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Navigation className="h-4 w-4 mr-2" />
              )}
              {language === "english" ? "Find Police Stations" : "காவல் நிலையங்களைக் கண்டறி"}
            </Button>
          </div>

          {/* SOS button with enhanced feedback - immediate action */}
          <div className="space-y-2">
            <Button
              onClick={sendSOSAlert}
              disabled={isSendingAlert || !location || alertCooldown}
              variant="destructive"
              size="lg"
              className="w-full py-6 text-lg font-bold"
            >
              {isSendingAlert ? (
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              ) : alertSent ? (
                <CheckCircle className="h-5 w-5 mr-2" />
              ) : (
                <Phone className="h-5 w-5 mr-2" />
              )}

              {isSendingAlert
                ? language === "english"
                  ? "SENDING ALERT..."
                  : "எச்சரிக்கை அனுப்புகிறது..."
                : alertSent
                  ? language === "english"
                    ? "ALERT SENT"
                    : "எச்சரிக்கை அனுப்பப்பட்டது"
                  : alertCooldown
                    ? language === "english"
                      ? `COOLDOWN (${formatCooldownTime(cooldownRemaining)})`
                      : `குளிர்விப்பு (${formatCooldownTime(cooldownRemaining)})`
                    : language === "english"
                      ? "SEND SOS ALERT"
                      : "SOS எச்சரிக்கையை அனுப்பு"}
            </Button>

            {/* Reset button - only show after alert is sent */}
            {alertCooldown && (
              <Button onClick={resetSOSAlert} variant="outline" className="w-full">
                <RefreshCw className="h-4 w-4 mr-2" />
                {language === "english" ? "Reset SOS (For Emergency Only)" : "SOS ஐ மீட்டமை (அவசரத்திற்கு மட்டும்)"}
              </Button>
            )}

            {/* Alert status information */}
            {alertCooldown && (
              <div className="text-xs text-center text-muted-foreground">
                {language === "english"
                  ? "SOS alert has been sent. Reset only if you need to send another emergency alert."
                  : "SOS எச்சரிக்கை அனுப்பப்பட்டுள்ளது. மற்றொரு அவசர எச்சரிக்கையை அனுப்ப வேண்டும் என்றால் மட்டுமே மீட்டமைக்கவும்."}
              </div>
            )}
          </div>

          {/* Alert status */}
          <AnimatePresence>
            {alertSent && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <AlertTitle className="text-green-700">
                    {language === "english" ? "SOS Alert Sent" : "SOS எச்சரிக்கை அனுப்பப்பட்டது"}
                  </AlertTitle>
                  <AlertDescription className="text-green-600">
                    {language === "english"
                      ? "Your emergency alert has been sent to Tamil Nadu Police with your location details. Emergency services have been notified and assistance is on the way."
                      : "உங்கள் அவசர எச்சரிக்கை உங்கள் இருப்பிட விவரங்களுடன் தமிழ்நாடு காவல்துறைக்கு அனுப்பப்பட்டுள்ளது. அவசர சேவைகளுக்கு அறிவிக்கப்பட்டுள்ளது மற்றும் உதவி வழியில் உள்ளது."}
                  </AlertDescription>
                </Alert>
              </motion.div>
            )}

            {alertError && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>{language === "english" ? "Alert Failed" : "எச்சரிக்கை தோல்வியடைந்தது"}</AlertTitle>
                  <AlertDescription>{alertError}</AlertDescription>
                </Alert>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Nearby police stations list - only show stations within 100km in Tamil Nadu */}
      {nearbyStations.length > 0 && (
        <Card className="w-full shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">
              {language === "english"
                ? `Nearby Tamil Nadu Police Stations (${nearbyStations.length} found)`
                : `அருகிலுள்ள தமிழ்நாடு காவல் நிலையங்கள் (${nearbyStations.length} கண்டறியப்பட்டது)`}
            </CardTitle>
          </CardHeader>

          <CardContent className="space-y-3">
            {nearbyStations.map((station, index) => (
              <div
                key={index}
                className={`p-3 rounded-md border ${
                  selectedStation?.name === station.name ? "bg-blue-50 border-blue-300" : "bg-gray-50 border-gray-200"
                } hover:bg-blue-50 hover:border-blue-300 transition-colors cursor-pointer`}
                onClick={() => showDirectionsToStation(station)}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-medium">{station.name}</h3>
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">{station.address}</p>
                  </div>
                  <div className="ml-3 flex flex-col items-end">
                    <div className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md border border-blue-100">
                      {station.distance < 1
                        ? `${(station.distance * 1000).toFixed(0)} m`
                        : `${station.distance.toFixed(1)} km`}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {index === 0 && (language === "english" ? "Nearest" : "அருகிலுள்ள")}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Directions panel */}
      <AnimatePresence>
        {showDirections && selectedStation && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="w-full shadow-md">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-lg flex items-center">
                  <Navigation className="h-4 w-4 mr-2 text-primary" />
                  {language === "english" ? "Directions" : "திசைகள்"}
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={hideDirections}>
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>

              <CardContent className="space-y-3">
                <div className="bg-blue-50 p-3 rounded-md border border-blue-200">
                  <h3 className="font-medium">{selectedStation.name}</h3>
                  <p className="text-xs text-gray-600 mt-1">{selectedStation.address}</p>
                  <div className="flex items-center mt-2">
                    <MapPin className="h-4 w-4 text-blue-500 mr-1" />
                    <span className="text-sm text-blue-700">
                      {selectedStation.distance.toFixed(2)} km {language === "english" ? "away" : "தொலைவில்"}
                    </span>
                  </div>
                </div>

                <div className="text-sm">
                  <p>
                    {language === "english"
                      ? `Follow the blue line on the map to reach ${selectedStation.name}.`
                      : `${selectedStation.name} ஐ அடைய வரைபடத்தில் உள்ள நீல கோட்டைப் பின்பற்றவும்.`}
                  </p>
                </div>

                <Button
                  className="w-full"
                  onClick={() => {
                    // Open in Google Maps if available
                    const url = `https://www.google.com/maps/dir/?api=1&destination=${selectedStation.lat},${selectedStation.lon}`
                    window.open(url, "_blank")
                  }}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  {language === "english" ? "Open in Google Maps" : "Google Maps இல் திற"}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

