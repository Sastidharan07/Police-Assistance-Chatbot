"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { User, LogOut, Settings, ChevronDown } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserProfileTab } from "@/components/user-profile-tab"
import { SettingsTab } from "@/components/settings-tab"

export function UserProfile() {
  const { mobileNumber, logout, userProfile } = useAuth()
  const { language } = useLanguage()
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)
  const [showProfileDialog, setShowProfileDialog] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")

  // Format mobile number for display
  const formatMobile = (mobile: string | null) => {
    if (!mobile) return ""
    return `+91 ${mobile.slice(0, 3)}****${mobile.slice(-3)}`
  }

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!userProfile?.username) return "U"

    const nameParts = userProfile.username.split(" ")
    if (nameParts.length === 1) return nameParts[0].charAt(0).toUpperCase()

    return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase()
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="flex items-center gap-1 h-8 btn-hover-effect">
            <Avatar className="h-6 w-6 mr-1">
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <span className="hidden sm:inline text-xs">{formatMobile(mobileNumber)}</span>
            <ChevronDown className="h-4 w-4 ml-1" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end">
          <DropdownMenuLabel>{language === "english" ? "My Account" : "எனது கணக்கு"}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem
              onClick={() => {
                setActiveTab("profile")
                setShowProfileDialog(true)
              }}
            >
              <User className="mr-2 h-4 w-4" />
              <span>{language === "english" ? "Profile" : "சுயவிவரம்"}</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                setActiveTab("settings")
                setShowProfileDialog(true)
              }}
            >
              <Settings className="mr-2 h-4 w-4" />
              <span>{language === "english" ? "Settings" : "அமைப்புகள்"}</span>
            </DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-red-500 focus:text-red-500" onClick={() => setShowLogoutConfirm(true)}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>{language === "english" ? "Logout" : "வெளியேறு"}</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Logout Confirmation Dialog */}
      <Dialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{language === "english" ? "Confirm Logout" : "வெளியேற உறுதிப்படுத்தவும்"}</DialogTitle>
            <DialogDescription>
              {language === "english"
                ? "Are you sure you want to logout from your account?"
                : "உங்கள் கணக்கிலிருந்து வெளியேற விரும்புகிறீர்களா?"}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex flex-row justify-between sm:justify-between gap-2 mt-4">
            <Button type="button" variant="outline" onClick={() => setShowLogoutConfirm(false)}>
              {language === "english" ? "Cancel" : "ரத்து செய்"}
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => {
                logout()
                setShowLogoutConfirm(false)
              }}
            >
              {language === "english" ? "Logout" : "வெளியேறு"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Profile/Settings Dialog */}
      <Dialog open={showProfileDialog} onOpenChange={setShowProfileDialog}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {activeTab === "profile"
                ? language === "english"
                  ? "User Profile"
                  : "பயனர் சுயவிவரம்"
                : language === "english"
                  ? "Settings"
                  : "அமைப்புகள்"}
            </DialogTitle>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="profile">
                <User className="h-4 w-4 mr-2" />
                {language === "english" ? "Profile" : "சுயவிவரம்"}
              </TabsTrigger>
              <TabsTrigger value="settings">
                <Settings className="h-4 w-4 mr-2" />
                {language === "english" ? "Settings" : "அமைப்புகள்"}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <UserProfileTab />
            </TabsContent>

            <TabsContent value="settings">
              <SettingsTab />
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-4">
            <Button type="button" variant="outline" onClick={() => setShowProfileDialog(false)}>
              {language === "english" ? "Close" : "மூடு"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

