"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useLanguage } from "./language-context"

interface LocationContextType {
  location: GeolocationCoordinates | null
  locationError: string | null
  isLocating: boolean
  hasPermission: boolean | null
  requestLocation: () => Promise<GeolocationCoordinates | null>
  clearLocation: () => void
  formattedLocation: string | null
}

const LocationContext = createContext<LocationContextType | undefined>(undefined)

export function LocationProvider({ children }: { children: ReactNode }) {
  const [location, setLocation] = useState<GeolocationCoordinates | null>(null)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [isLocating, setIsLocating] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [formattedLocation, setFormattedLocation] = useState<string | null>(null)
  const { language } = useLanguage()

  // Check for stored location on mount
  useEffect(() => {
    const storedLocation = sessionStorage.getItem("userLocation")
    if (storedLocation) {
      try {
        const parsedLocation = JSON.parse(storedLocation)
        setLocation(parsedLocation)
        formatLocationAddress(parsedLocation)
      } catch (error) {
        console.error("Error parsing stored location:", error)
        sessionStorage.removeItem("userLocation")
      }
    }
  }, [])

  // Format location coordinates to human-readable address
  const formatLocationAddress = async (coords: GeolocationCoordinates) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${coords.latitude}&lon=${coords.longitude}&zoom=18&addressdetails=1`,
      )
      const data = await response.json()

      if (data && data.display_name) {
        setFormattedLocation(data.display_name)
      } else {
        setFormattedLocation(`${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`)
      }
    } catch (error) {
      console.error("Error getting address:", error)
      setFormattedLocation(`${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`)
    }
  }

  const requestLocation = async (): Promise<GeolocationCoordinates | null> => {
    if (!navigator.geolocation) {
      const errorMsg =
        language === "english" ? "Geolocation is not supported by your browser" : "உங்கள் உலாவியால் புவியிடம் ஆதரிக்கப்படவில்லை"
      setLocationError(errorMsg)
      setHasPermission(false)
      return null
    }

    setIsLocating(true)
    setLocationError(null)

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve(pos),
          (err) => reject(err),
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
        )
      })

      setLocation(position.coords)
      setHasPermission(true)
      setIsLocating(false)

      // Store location in session storage
      sessionStorage.setItem("userLocation", JSON.stringify(position.coords))

      // Format location to address
      await formatLocationAddress(position.coords)

      return position.coords
    } catch (error) {
      console.error("Error getting location:", error)

      let errorMsg = ""
      if (error instanceof GeolocationPositionError) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMsg = language === "english" ? "Location permission denied" : "இருப்பிட அனுமதி மறுக்கப்பட்டது"
            setHasPermission(false)
            break
          case error.POSITION_UNAVAILABLE:
            errorMsg = language === "english" ? "Location information is unavailable" : "இருப்பிட தகவல் கிடைக்கவில்லை"
            break
          case error.TIMEOUT:
            errorMsg = language === "english" ? "Location request timed out" : "இருப்பிட கோரிக்கை நேரம் முடிந்தது"
            break
          default:
            errorMsg = language === "english" ? "An unknown error occurred" : "அறியப்படாத பிழை ஏற்பட்டது"
        }
      } else {
        errorMsg = language === "english" ? "Error getting location" : "இருப்பிடத்தைப் பெறுவதில் பிழை"
      }

      setLocationError(errorMsg)
      setIsLocating(false)
      return null
    }
  }

  const clearLocation = () => {
    setLocation(null)
    setFormattedLocation(null)
    sessionStorage.removeItem("userLocation")
  }

  return (
    <LocationContext.Provider
      value={{
        location,
        locationError,
        isLocating,
        hasPermission,
        requestLocation,
        clearLocation,
        formattedLocation,
      }}
    >
      {children}
    </LocationContext.Provider>
  )
}

export function useLocation() {
  const context = useContext(LocationContext)
  if (context === undefined) {
    throw new Error("useLocation must be used within a LocationProvider")
  }
  return context
}

