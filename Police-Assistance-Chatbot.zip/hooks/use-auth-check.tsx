"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

export function useAuthCheck(requireAuth = true) {
  const [authReady, setAuthReady] = useState(false)
  const auth = useAuth()
  const router = useRouter()

  const { isAuthenticated, login } = auth

  useEffect(() => {
    setAuthReady(true)
  }, [])

  useEffect(() => {
    if (!authReady) {
      return
    }

    const storedIsAuthenticated = sessionStorage.getItem("isAuthenticated") === "true"
    const storedMobileNumber = sessionStorage.getItem("mobileNumber")

    // If we require authentication and user is not authenticated, redirect to login
    if (requireAuth && !isAuthenticated && !storedIsAuthenticated) {
      router.push("/")
    }

    // If we don't require auth (login page) but user is authenticated, redirect to chat
    if (!requireAuth && (isAuthenticated || storedIsAuthenticated)) {
      if (storedMobileNumber && !isAuthenticated) {
        login(storedMobileNumber)
      } else {
        router.push("/chat")
      }
    }
  }, [isAuthenticated, requireAuth, router, login, authReady])
}

