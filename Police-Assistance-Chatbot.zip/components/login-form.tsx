"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/lib/auth-context"
import { validateMobile, validateOTP } from "@/lib/validation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { AlertCircle, CheckCircle, Shield, Loader2, User } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useLanguage } from "@/lib/language-context"
import { OtpInput } from "./otp-input"
import { motion, AnimatePresence } from "framer-motion"
import { initRecaptchaVerifier, sendOTP, verifyOTP, manualVerifyOTP } from "@/lib/firebase-service"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function LoginForm() {
  const [mobile, setMobile] = useState("")
  const [otp, setOtp] = useState("")
  const [mobileError, setMobileError] = useState("")
  const [otpError, setOtpError] = useState("")
  const [showOtpField, setShowOtpField] = useState(false)
  const [isVerifying, setIsVerifying] = useState(false)
  const [isSendingOtp, setIsSendingOtp] = useState(false)
  const [resendTimer, setResendTimer] = useState(0)
  const [resendSuccess, setResendSuccess] = useState(false)
  const [useTestMode, setUseTestMode] = useState(false)
  const [shakeMobile, setShakeMobile] = useState(false)
  const [shakeOtp, setShakeOtp] = useState(false)
  const [activeTab, setActiveTab] = useState("login")
  const [profileData, setProfileData] = useState({
    username: "",
    email: "",
    address: "",
    gender: "",
  })
  const recaptchaContainerRef = useRef<HTMLDivElement>(null)
  const { login } = useAuth()
  const { language, setLanguage, t } = useLanguage()

  // Timer for resend OTP
  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => {
        setResendTimer(resendTimer - 1)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [resendTimer])

  // Reset resend success message after 3 seconds
  useEffect(() => {
    if (resendSuccess) {
      const timer = setTimeout(() => {
        setResendSuccess(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [resendSuccess])

  // Reset shake animations after they complete
  useEffect(() => {
    if (shakeMobile) {
      const timer = setTimeout(() => {
        setShakeMobile(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [shakeMobile])

  useEffect(() => {
    if (shakeOtp) {
      const timer = setTimeout(() => {
        setShakeOtp(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [shakeOtp])

  // Initialize recaptcha when component mounts
  useEffect(() => {
    if (!useTestMode && recaptchaContainerRef.current) {
      initRecaptchaVerifier("recaptcha-container")
    }
  }, [useTestMode])

  // Try to load last used mobile number
  useEffect(() => {
    const lastMobile = localStorage.getItem("lastMobileNumber")
    if (lastMobile) {
      setMobile(lastMobile)
    }
  }, [])

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow digits and limit to 10 characters
    const value = e.target.value.replace(/\D/g, "").slice(0, 10)
    setMobile(value)
    setMobileError("")
  }

  const handleOtpChange = (value: string) => {
    setOtp(value)
    setOtpError("")
  }

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfileData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleGenderChange = (value: string) => {
    setProfileData((prev) => ({
      ...prev,
      gender: value,
    }))
  }

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateMobile(mobile)) {
      setMobileError(
        language === "english"
          ? "Please enter a valid Indian mobile number"
          : "தயவுசெய்து சரியான இந்திய மொபைல் எண்ணை உள்ளிடவும்",
      )
      setShakeMobile(true)
      return
    }

    setIsSendingOtp(true)

    if (useTestMode) {
      // In test mode, just show the OTP field without actually sending OTP
      setTimeout(() => {
        setShowOtpField(true)
        setIsSendingOtp(false)
        setResendTimer(30)
      }, 1000)
    } else {
      // Send OTP using Firebase
      try {
        const result = await sendOTP(mobile)

        if (result.success) {
          setShowOtpField(true)
          setResendTimer(30)
        } else {
          setMobileError(
            language === "english" ? `Failed to send OTP: ${result.error}` : `OTP அனுப்ப முடியவில்லை: ${result.error}`,
          )
          setShakeMobile(true)
        }
      } catch (error) {
        console.error("Error sending OTP:", error)
        setMobileError(
          language === "english" ? "Failed to send OTP. Please try again." : "OTP அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
        )
        setShakeMobile(true)
      } finally {
        setIsSendingOtp(false)
      }
    }
  }

  const handleResendOtp = async () => {
    if (resendTimer > 0) return

    setIsSendingOtp(true)

    if (useTestMode) {
      // In test mode, just reset the timer
      setTimeout(() => {
        setResendSuccess(true)
        setResendTimer(30)
        setIsSendingOtp(false)
      }, 1000)
    } else {
      // Resend OTP using Firebase
      try {
        const result = await sendOTP(mobile)

        if (result.success) {
          setResendSuccess(true)
          setResendTimer(30)
        } else {
          setOtpError(
            language === "english"
              ? `Failed to resend OTP: ${result.error}`
              : `OTP மீண்டும் அனுப்ப முடியவில்லை: ${result.error}`,
          )
          setShakeOtp(true)
        }
      } catch (error) {
        console.error("Error resending OTP:", error)
        setOtpError(
          language === "english"
            ? "Failed to resend OTP. Please try again."
            : "OTP மீண்டும் அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
        )
        setShakeOtp(true)
      } finally {
        setIsSendingOtp(false)
      }
    }
  }

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault()

    let hasError = false

    if (!validateMobile(mobile)) {
      setMobileError(
        language === "english"
          ? "Please enter a valid Indian mobile number (starting with 9, 8, 7, or 6)"
          : "தயவுசெய்து சரியான இந்திய மொபைல் எண்ணை உள்ளிடவும் (9, 8, 7 அல்லது 6 இல் தொடங்க வேண்டும்)",
      )
      setShakeMobile(true)
      hasError = true
    }

    if (!validateOTP(otp)) {
      setOtpError(
        language === "english" ? "Invalid OTP. Please enter a 6-digit code." : "தவறான OTP. 6-இலக்க குறியீட்டை உள்ளிடவும்.",
      )
      setShakeOtp(true)
      hasError = true
    }

    if (!hasError) {
      setIsVerifying(true)

      try {
        let verificationResult

        if (useTestMode) {
          // In test mode, use manual verification
          verificationResult = await manualVerifyOTP(mobile, otp)
        } else {
          // Verify OTP using Firebase
          verificationResult = await verifyOTP(otp)
        }

        if (verificationResult.success) {
          // Save mobile number to localStorage for persistence
          localStorage.setItem("lastMobileNumber", mobile)

          // Login the user with profile data if provided
          login(
            mobile,
            activeTab === "register"
              ? {
                  username: profileData.username || "",
                  email: profileData.email || "",
                  address: profileData.address || "",
                  gender: profileData.gender || "",
                  phoneNumber: mobile,
                  createdAt: new Date().toISOString(),
                  lastUpdated: new Date().toISOString(),
                }
              : undefined,
          )
        } else {
          setOtpError(language === "english" ? "Invalid OTP. Please try again." : "தவறான OTP. மீண்டும் முயற்சிக்கவும்.")
          setShakeOtp(true)
        }
      } catch (error) {
        console.error("Error verifying OTP:", error)
        setOtpError(
          language === "english"
            ? "Failed to verify OTP. Please try again."
            : "OTP சரிபார்க்க முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
        )
        setShakeOtp(true)
      } finally {
        setIsVerifying(false)
      }
    }
  }

  const toggleLanguage = () => {
    setLanguage(language === "english" ? "tamil" : "english")
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="w-full max-w-md shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="h-12 w-12 bg-white rounded-full flex items-center justify-center overflow-hidden border shadow-md hover:shadow-lg transition-all duration-300">
                <motion.img
                  src="/tn-police-logo.png"
                  alt="Tamil Nadu Police Logo"
                  className="h-10 w-10 object-contain"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  onError={(e) => {
                    e.currentTarget.src =
                      "https://upload.wikimedia.org/wikipedia/en/thumb/3/3e/Tamil_Nadu_Police_Logo.svg/1200px-Tamil_Nadu_Police_Logo.svg.png"
                  }}
                />
              </div>
              <CardTitle
                className={`text-2xl ${language === "tamil" ? "font-tamil" : ""} bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600`}
              >
                {t("login.title")}
              </CardTitle>
            </div>
            <Button variant="outline" size="sm" onClick={toggleLanguage} className="min-w-[80px] btn-hover-effect">
              {language === "english" ? "தமிழ்" : "English"}
            </Button>
          </div>
          <CardDescription className={`${language === "tamil" ? "font-tamil" : ""} animate-fade-in`}>
            {t("login.description")}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="login">{language === "english" ? "Login" : "உள்நுழைய"}</TabsTrigger>
              <TabsTrigger value="register">{language === "english" ? "Register" : "பதிவு செய்ய"}</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={showOtpField ? handleVerify : handleSendOtp}>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label
                      htmlFor="mobile"
                      className={`flex items-center gap-1 ${language === "tamil" ? "font-tamil" : ""}`}
                    >
                      {t("login.mobile")}
                      <span className="text-red-500">*</span>
                    </Label>
                    <div className="flex">
                      <div className="bg-muted flex items-center justify-center px-3 border border-r-0 rounded-l-md">
                        +91
                      </div>
                      <Input
                        id="mobile"
                        type="tel"
                        inputMode="numeric"
                        value={mobile}
                        onChange={handleMobileChange}
                        placeholder={t("login.mobile.placeholder")}
                        className={`rounded-l-none text-base ${language === "tamil" ? "font-tamil" : ""} ${shakeMobile ? "animate-shake border-red-300" : ""} transition-all focus:border-primary focus:ring-2 focus:ring-primary/20`}
                        disabled={showOtpField || isSendingOtp}
                      />
                    </div>
                    <AnimatePresence>
                      {mobileError && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                        >
                          <Alert variant="destructive" className="py-2 animate-fade-in">
                            <AlertCircle className="h-4 w-4" />
                            <AlertDescription className={language === "tamil" ? "font-tamil" : ""}>
                              {mobileError}
                            </AlertDescription>
                          </Alert>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <AnimatePresence>
                    {showOtpField && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="grid gap-2"
                      >
                        <Label
                          htmlFor="otp"
                          className={`flex items-center gap-1 ${language === "tamil" ? "font-tamil" : ""}`}
                        >
                          {t("login.otp")}
                          <span className="text-red-500">*</span>
                        </Label>
                        <div className={shakeOtp ? "animate-shake" : ""}>
                          <OtpInput value={otp} onChange={handleOtpChange} />
                        </div>

                        {/* Resend OTP section */}
                        <div className="flex justify-between items-center mt-2">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={handleResendOtp}
                            disabled={resendTimer > 0 || isSendingOtp}
                            className={`text-xs ${language === "tamil" ? "font-tamil" : ""} btn-hover-effect`}
                          >
                            {isSendingOtp ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : null}
                            {t("login.resendOtp")} {resendTimer > 0 ? `(${resendTimer}s)` : ""}
                          </Button>

                          <AnimatePresence>
                            {resendSuccess && (
                              <motion.div
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className={`flex items-center text-green-600 text-xs ${language === "tamil" ? "font-tamil" : ""}`}
                              >
                                <CheckCircle className="h-3 w-3 mr-1 animate-bounce-subtle" />
                                {t("login.resendSuccess")}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        <AnimatePresence>
                          {otpError && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                            >
                              <Alert variant="destructive" className="py-2 animate-fade-in">
                                <AlertCircle className="h-4 w-4" />
                                <AlertDescription className={language === "tamil" ? "font-tamil" : ""}>
                                  {otpError}
                                </AlertDescription>
                              </Alert>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Test mode toggle (for development/testing) */}
                  <div className="flex items-center space-x-2 hover:bg-gray-50 p-2 rounded-md transition-colors">
                    <Checkbox
                      id="test-mode"
                      checked={useTestMode}
                      onCheckedChange={(checked) => setUseTestMode(checked === true)}
                      className="transition-all data-[state=checked]:bg-blue-500 data-[state=checked]:animate-pulse-subtle"
                    />
                    <Label
                      htmlFor="test-mode"
                      className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
                    >
                      {language === "english"
                        ? "Use test mode (OTP: 123456)"
                        : "சோதனை முறையைப் பயன்படுத்தவும் (OTP: 123456)"}
                    </Label>
                  </div>
                </div>

                <div className="mt-4">
                  <motion.div className="w-full" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg"
                      disabled={isVerifying || isSendingOtp}
                    >
                      {isVerifying || isSendingOtp ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                          className="mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"
                        />
                      ) : (
                        <Shield className="mr-2 h-4 w-4" />
                      )}
                      <span className={language === "tamil" ? "font-tamil" : ""}>
                        {showOtpField
                          ? t("login.verify")
                          : isSendingOtp
                            ? language === "english"
                              ? "Sending..."
                              : "அனுப்புகிறது..."
                            : t("login.sendOtp")}
                      </span>
                    </Button>
                  </motion.div>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={showOtpField ? handleVerify : handleSendOtp}>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label
                      htmlFor="mobile"
                      className={`flex items-center gap-1 ${language === "tamil" ? "font-tamil" : ""}`}
                    >
                      {t("login.mobile")}
                      <span className="text-red-500">*</span>
                    </Label>
                    <div className="flex">
                      <div className="bg-muted flex items-center justify-center px-3 border border-r-0 rounded-l-md">
                        +91
                      </div>
                      <Input
                        id="mobile"
                        type="tel"
                        inputMode="numeric"
                        value={mobile}
                        onChange={handleMobileChange}
                        placeholder={t("login.mobile.placeholder")}
                        className={`rounded-l-none text-base ${language === "tamil" ? "font-tamil" : ""} ${shakeMobile ? "animate-shake border-red-300" : ""} transition-all focus:border-primary focus:ring-2 focus:ring-primary/20`}
                        disabled={showOtpField || isSendingOtp}
                      />
                    </div>
                    <AnimatePresence>
                      {mobileError && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                        >
                          <Alert variant="destructive" className="py-2 animate-fade-in">
                            <AlertCircle className="h-4 w-4" />
                            <AlertDescription className={language === "tamil" ? "font-tamil" : ""}>
                              {mobileError}
                            </AlertDescription>
                          </Alert>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Profile fields */}
                  <div className="grid gap-2">
                    <Label htmlFor="username">{language === "english" ? "Full Name" : "முழு பெயர்"}</Label>
                    <Input
                      id="username"
                      name="username"
                      value={profileData.username}
                      onChange={handleProfileChange}
                      placeholder={language === "english" ? "Enter your full name" : "உங்கள் முழு பெயரை உள்ளிடவும்"}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="email">{language === "english" ? "Email Address" : "மின்னஞ்சல் முகவரி"}</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={profileData.email}
                      onChange={handleProfileChange}
                      placeholder={language === "english" ? "Enter your email" : "உங்கள் மின்னஞ்சலை உள்ளிடவும்"}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="address">{language === "english" ? "Address" : "முகவரி"}</Label>
                    <Input
                      id="address"
                      name="address"
                      value={profileData.address}
                      onChange={handleProfileChange}
                      placeholder={language === "english" ? "Enter your address" : "உங்கள் முகவரியை உள்ளிடவும்"}
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="gender">{language === "english" ? "Gender" : "பாலினம்"}</Label>
                    <Select onValueChange={handleGenderChange} value={profileData.gender}>
                      <SelectTrigger>
                        <SelectValue
                          placeholder={language === "english" ? "Select gender" : "பாலினத்தைத் தேர்ந்தெடுக்கவும்"}
                        />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">{language === "english" ? "Male" : "ஆண்"}</SelectItem>
                        <SelectItem value="female">{language === "english" ? "Female" : "பெண்"}</SelectItem>
                        <SelectItem value="other">{language === "english" ? "Other" : "மற்றவை"}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <AnimatePresence>
                    {showOtpField && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="grid gap-2"
                      >
                        <Label
                          htmlFor="otp"
                          className={`flex items-center gap-1 ${language === "tamil" ? "font-tamil" : ""}`}
                        >
                          {t("login.otp")}
                          <span className="text-red-500">*</span>
                        </Label>
                        <div className={shakeOtp ? "animate-shake" : ""}>
                          <OtpInput value={otp} onChange={handleOtpChange} />
                        </div>

                        {/* Resend OTP section */}
                        <div className="flex justify-between items-center mt-2">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={handleResendOtp}
                            disabled={resendTimer > 0 || isSendingOtp}
                            className={`text-xs ${language === "tamil" ? "font-tamil" : ""} btn-hover-effect`}
                          >
                            {isSendingOtp ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : null}
                            {t("login.resendOtp")} {resendTimer > 0 ? `(${resendTimer}s)` : ""}
                          </Button>

                          <AnimatePresence>
                            {resendSuccess && (
                              <motion.div
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className={`flex items-center text-green-600 text-xs ${language === "tamil" ? "font-tamil" : ""}`}
                              >
                                <CheckCircle className="h-3 w-3 mr-1 animate-bounce-subtle" />
                                {t("login.resendSuccess")}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        <AnimatePresence>
                          {otpError && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                            >
                              <Alert variant="destructive" className="py-2 animate-fade-in">
                                <AlertCircle className="h-4 w-4" />
                                <AlertDescription className={language === "tamil" ? "font-tamil" : ""}>
                                  {otpError}
                                </AlertDescription>
                              </Alert>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Test mode toggle (for development/testing) */}
                  <div className="flex items-center space-x-2 hover:bg-gray-50 p-2 rounded-md transition-colors">
                    <Checkbox
                      id="test-mode-register"
                      checked={useTestMode}
                      onCheckedChange={(checked) => setUseTestMode(checked === true)}
                      className="transition-all data-[state=checked]:bg-blue-500 data-[state=checked]:animate-pulse-subtle"
                    />
                    <Label
                      htmlFor="test-mode-register"
                      className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
                    >
                      {language === "english"
                        ? "Use test mode (OTP: 123456)"
                        : "சோதனை முறையைப் பயன்படுத்தவும் (OTP: 123456)"}
                    </Label>
                  </div>
                </div>

                <div className="mt-4">
                  <motion.div className="w-full" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg"
                      disabled={isVerifying || isSendingOtp}
                    >
                      {isVerifying || isSendingOtp ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                          className="mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"
                        />
                      ) : (
                        <User className="mr-2 h-4 w-4" />
                      )}
                      <span className={language === "tamil" ? "font-tamil" : ""}>
                        {showOtpField
                          ? t("login.verify")
                          : isSendingOtp
                            ? language === "english"
                              ? "Sending..."
                              : "அனுப்புகிறது..."
                            : language === "english"
                              ? "Register & Send OTP"
                              : "பதிவு செய்து OTP அனுப்பு"}
                      </span>
                    </Button>
                  </motion.div>
                </div>
              </form>
            </TabsContent>
          </Tabs>

          {/* Recaptcha container */}
          <div id="recaptcha-container" ref={recaptchaContainerRef}></div>
        </CardContent>
        <CardFooter className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <p className="text-xs text-center w-full text-gray-500">
            {language === "english"
              ? "By logging in, you agree to our Terms of Service and Privacy Policy"
              : "உள்நுழைவதன் மூலம், எங்கள் சேவை விதிமுறைகள் மற்றும் தனியுரிமைக் கொள்கையை ஒப்புக்கொள்கிறீர்கள்"}
          </p>
        </CardFooter>
      </Card>
    </motion.div>
  )
}

