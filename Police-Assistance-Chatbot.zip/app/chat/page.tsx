"use client"

import { useState } from "react"
import { ChatInterface } from "@/components/chat-interface"
import { ChatNavigation } from "@/components/chat-navigation"
import { EmergencyContacts } from "@/components/emergency-contacts"
import { ProceduresBox } from "@/components/procedures-box"
import { LegalRights } from "@/components/legal-rights"
import { ComplaintForm } from "@/components/complaint-form"
import { QuickAccessQuestions } from "@/components/quick-access-questions"
import { PoliceStationFinder } from "@/components/police-station-finder"
import { useAuthCheck } from "@/hooks/use-auth-check"

export default function ChatPage() {
  const [activeTab, setActiveTab] = useState("chat")

  // Check if user is authenticated
  useAuthCheck()

  return (
    <div className="container mx-auto py-4 px-2 sm:px-4 md:py-8">
      <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-4">
        <div>
          <ChatNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        </div>
        <div>
          {activeTab === "chat" && <ChatInterface />}
          {activeTab === "emergency" && <EmergencyContacts />}
          {activeTab === "procedures" && <ProceduresBox />}
          {activeTab === "legal" && <LegalRights />}
          {activeTab === "complaint" && <ComplaintForm />}
          {activeTab === "faq" && <QuickAccessQuestions />}
          {activeTab === "location" && <PoliceStationFinder />}
        </div>
      </div>
    </div>
  )
}

