"use client"

import { useEffect } from "react"
import { useMapEvents } from "react-leaflet"
import L from "leaflet"

// Fix for Leaflet marker icons
const icon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
})

interface MapEventsProps {
  onLocationUpdate: (lat: number, lng: number) => void
}

export function MapEvents({ onLocationUpdate }: MapEventsProps) {
  const map = useMapEvents({
    click: (e) => {
      onLocationUpdate(e.latlng.lat, e.latlng.lng)
    },
  })

  // Set default icon for all markers
  useEffect(() => {
    // @ts-ignore - This is a valid property but TypeScript doesn't recognize it
    L.Marker.prototype.options.icon = icon
  }, [])

  return null
}

