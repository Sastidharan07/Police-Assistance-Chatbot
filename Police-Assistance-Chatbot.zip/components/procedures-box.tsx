"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-context"

export function ProceduresBox() {
  const { t } = useLanguage()

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t("procedures.title")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="p-2 border-l-2 border-primary">{t("procedures.step1")}</div>
        <div className="p-2 border-l-2 border-primary">{t("procedures.step2")}</div>
        <div className="p-2 border-l-2 border-primary">{t("procedures.step3")}</div>
        <div className="p-2 border-l-2 border-primary">{t("procedures.step4")}</div>
        <div className="p-2 border-l-2 border-primary">{t("procedures.step5")}</div>
      </CardContent>
    </Card>
  )
}

