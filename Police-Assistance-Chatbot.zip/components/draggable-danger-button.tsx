"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { AlertCircle, AlertTriangle, Move } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"
import { useEmergencyAlert } from "@/lib/emergency-alert-context"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { cn } from "@/lib/utils"

interface Position {
  x: number
  y: number
}

export function DraggableDangerButton() {
  const { t, language } = useLanguage()
  const { sendAlert, isAlertActive, isPending } = useEmergencyAlert()
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [isConfirmOpen, setIsConfirmOpen] = useState(false)
  const [isEditMode, setIsEditMode] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const buttonRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Load saved position on mount
  useEffect(() => {
    try {
      const savedPosition = localStorage.getItem("dangerButtonPosition")
      if (savedPosition) {
        const parsedPosition = JSON.parse(savedPosition) as Position

        // Validate the saved position is within viewport
        validateAndSetPosition(parsedPosition)
      } else {
        // Default position at bottom right
        setPosition({ x: window.innerWidth - 100, y: window.innerHeight - 100 })
      }
    } catch (error) {
      console.error("Error loading button position:", error)
      // Default position if there's an error
      setPosition({ x: window.innerWidth - 100, y: window.innerHeight - 100 })
    }
  }, [])

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  // Handle window resize to keep button in viewport
  useEffect(() => {
    const handleResize = () => {
      validateAndSetPosition(position)
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [position])

  // Save position when it changes
  useEffect(() => {
    if (!isDragging) {
      localStorage.setItem("dangerButtonPosition", JSON.stringify(position))
    }
  }, [position, isDragging])

  // Validate position is within viewport and adjust if necessary
  const validateAndSetPosition = (pos: Position) => {
    if (!buttonRef.current) return

    const buttonWidth = buttonRef.current.offsetWidth
    const buttonHeight = buttonRef.current.offsetHeight

    // Calculate boundaries
    const maxX = window.innerWidth - buttonWidth
    const maxY = window.innerHeight - buttonHeight

    // Ensure position is within viewport
    const validatedPos = {
      x: Math.min(Math.max(0, pos.x), maxX),
      y: Math.min(Math.max(0, pos.y), maxY),
    }

    setPosition(validatedPos)
  }

  const handleDragStart = () => {
    if (!isEditMode) return
    setIsDragging(true)
  }

  const handleDragEnd = () => {
    setIsDragging(false)
  }

  const handleButtonClick = () => {
    if (isEditMode) {
      return // Don't trigger alert in edit mode
    }

    // Add haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate(100)
    }

    setIsConfirmOpen(true)
  }

  const handleConfirm = async () => {
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 200])
    }
    await sendAlert()
    setIsConfirmOpen(false)
  }

  const toggleEditMode = () => {
    setIsEditMode(!isEditMode)
  }

  return (
    <>
      <div ref={containerRef} className="fixed inset-0 pointer-events-none z-40">
        <motion.div
          ref={buttonRef}
          className="absolute pointer-events-auto"
          style={{
            zIndex: 50,
            boxShadow: isDragging ? "0 0 15px rgba(255, 0, 0, 0.5)" : "0 4px 12px rgba(0, 0, 0, 0.15)",
          }}
          drag={isEditMode}
          dragMomentum={false}
          dragElastic={0}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          animate={{
            x: position.x,
            y: position.y,
            scale: isDragging ? 1.1 : 1,
            opacity: isDragging ? 0.8 : 1,
          }}
          transition={{
            type: "spring",
            damping: 20,
            stiffness: 300,
          }}
        >
          <div className="relative">
            <Button
              variant="destructive"
              size="lg"
              className={cn(
                "rounded-full shadow-lg flex items-center justify-center",
                "active:scale-95 transition-transform duration-200",
                "touch-manipulation tap-highlight-transparent",
                isMobile ? "h-[60px] w-[60px]" : "h-16 w-16",
                isAlertActive && "bg-red-700 hover:bg-red-800 animate-pulse",
                isEditMode && "border-2 border-dashed border-yellow-400",
              )}
              onClick={handleButtonClick}
              disabled={isPending}
              aria-label={language === "english" ? "Emergency Alert" : "அவசர எச்சரிக்கை"}
            >
              {isEditMode ? (
                <Move className={isMobile ? "h-7 w-7" : "h-8 w-8"} />
              ) : (
                <AlertCircle className={isMobile ? "h-7 w-7" : "h-8 w-8"} />
              )}
              <span className="sr-only">{language === "english" ? "Emergency Alert" : "அவசர எச்சரிக்கை"}</span>
            </Button>

            {/* Edit mode toggle button */}
            <Button
              variant="outline"
              size="icon"
              className="absolute -top-3 -right-3 h-6 w-6 rounded-full bg-white dark:bg-gray-800 shadow-md"
              onClick={toggleEditMode}
            >
              {isEditMode ? <span className="text-xs">✓</span> : <span className="text-xs">⋮</span>}
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <DialogContent className={cn("sm:max-w-md max-h-[90vh] overflow-y-auto", isMobile && "w-[95%] p-4 rounded-xl")}>
          <DialogHeader className={isMobile ? "space-y-2" : ""}>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 flex-shrink-0" />
              <span className="text-wrap">
                {language === "english" ? "Emergency Alert Confirmation" : "அவசர எச்சரிக்கை உறுதிப்படுத்தல்"}
              </span>
            </DialogTitle>
            <DialogDescription className={isMobile ? "text-sm" : ""}>
              {language === "english"
                ? "This will send an emergency alert with your current location to all your emergency contacts and nearby police stations."
                : "இது உங்கள் தற்போதைய இருப்பிடத்துடன் உங்கள் அனைத்து அவசர தொடர்புகளுக்கும் அருகிலுள்ள காவல் நிலையங்களுக்கும் ஒரு அவசர எச்சரிக்கையை அனுப்பும்."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className={cn("flex flex-row sm:justify-between gap-2", isMobile && "mt-2")}>
            <Button
              variant="outline"
              onClick={() => setIsConfirmOpen(false)}
              className={isMobile ? "text-sm py-1 px-3 h-9" : ""}
            >
              {language === "english" ? "Cancel" : "ரத்து செய்"}
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirm}
              className={cn("active:scale-95 transition-transform duration-200", isMobile && "text-sm py-1 px-3 h-9")}
            >
              {language === "english" ? "Send Alert" : "எச்சரிக்கையை அனுப்பு"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

