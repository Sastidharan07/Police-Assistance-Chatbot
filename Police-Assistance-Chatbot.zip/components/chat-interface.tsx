"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { useLocation } from "@/lib/location-context"
import { useOfflineMode } from "@/hooks/use-offline-mode"
import { Send, WifiOff, Bot, UserIcon, MapPin, AlertCircle, Loader2, X, HelpCircle, Trash2 } from "lucide-react"
import {
  saveChatMessage,
  getChatHistory,
  getAIResponse,
  searchOfflineFAQs,
  clearChatHistory,
} from "@/lib/storage-service"
import { motion, AnimatePresence } from "framer-motion"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { DefaultSafetyQuestions } from "./default-safety-questions"
import { ThemeToggle } from "./theme-toggle"
import { UserProfile } from "./user-profile"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export function ChatInterface() {
  const { t, language, setLanguage } = useLanguage()
  const isOffline = useOfflineMode()
  const { logout, mobileNumber } = useAuth()
  const { location, locationError, isLocating, requestLocation, clearLocation, formattedLocation } = useLocation()

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [currentTypingMessage, setCurrentTypingMessage] = useState("")
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string; id: string }>>([
    {
      id: "welcome",
      role: "assistant",
      content: t("welcome"),
    },
  ])
  const [shakeInput, setShakeInput] = useState(false)
  const [newMessageAlert, setNewMessageAlert] = useState(false)
  const [apiErrorCount, setApiErrorCount] = useState(0)
  const [showSafetyQuestions, setShowSafetyQuestions] = useState(false)
  const [showClearChatDialog, setShowClearChatDialog] = useState(false)

  // Load chat history from local storage when component mounts
  useEffect(() => {
    if (mobileNumber) {
      const history = getChatHistory(mobileNumber)
      if (history.length > 0) {
        // Convert the stored chat history to the format expected by the component
        const formattedHistory = history.map((msg) => ({
          id: msg.id,
          role: msg.role,
          content: msg.content,
        }))

        // Add welcome message if it doesn't exist
        if (!formattedHistory.some((msg) => msg.id === "welcome")) {
          formattedHistory.unshift({
            id: "welcome",
            role: "assistant",
            content: t("welcome"),
          })
        }

        setMessages(formattedHistory)
      }
    }
  }, [mobileNumber, t])

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })

      // Show new message alert if user has scrolled up
      const container = messagesEndRef.current.parentElement
      if (container && container.scrollHeight - container.scrollTop > container.clientHeight + 100) {
        setNewMessageAlert(true)
      }
    }
  }, [messages, isTyping])

  // Update welcome message when language changes
  useEffect(() => {
    setMessages((prev) => {
      const updated = [...prev]
      if (updated[0]?.id === "welcome") {
        updated[0].content = t("welcome")
      }
      return updated
    })
  }, [language, t])

  // Focus input field when component mounts
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  // Reset shake animation after it completes
  useEffect(() => {
    if (shakeInput) {
      const timer = setTimeout(() => {
        setShakeInput(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [shakeInput])

  // Reset new message alert when user scrolls to bottom
  useEffect(() => {
    const handleScroll = () => {
      const container = messagesEndRef.current?.parentElement
      if (container && container.scrollHeight - container.scrollTop <= container.clientHeight + 50) {
        setNewMessageAlert(false)
      }
    }

    const container = messagesEndRef.current?.parentElement
    if (container) {
      container.addEventListener("scroll", handleScroll)
      return () => container.removeEventListener("scroll", handleScroll)
    }
  }, [])

  // Reset API error count after 5 minutes
  useEffect(() => {
    if (apiErrorCount > 0) {
      const timer = setTimeout(
        () => {
          setApiErrorCount(0)
        },
        5 * 60 * 1000,
      ) // 5 minutes
      return () => clearTimeout(timer)
    }
  }, [apiErrorCount])

  // Enhanced typing animation effect
  const typeMessage = async (message: string) => {
    setIsTyping(true)
    setCurrentTypingMessage("")

    // Simulate typing effect with variable speed based on character type
    for (let i = 0; i < message.length; i++) {
      setCurrentTypingMessage(message.substring(0, i + 1))
      // Vary typing speed based on character type (punctuation, space, or letter)
      const char = message[i]
      let delay = 15 // base delay

      if (".!?,:;".includes(char)) {
        delay = 50 // pause longer at punctuation
      } else if (char === " ") {
        delay = 30 // pause at spaces
      } else if (Math.random() < 0.1) {
        delay = 60 // occasional random longer pause
      }

      await new Promise((resolve) => setTimeout(resolve, delay + Math.random() * 20))
    }

    // Slight pause at the end to simulate "thinking"
    await new Promise((resolve) => setTimeout(resolve, 300))
    setIsTyping(false)
    return message
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim()) {
      setShakeInput(true)
      return
    }

    if (!mobileNumber || isLoading) return

    // Close safety questions panel if open
    if (showSafetyQuestions) {
      setShowSafetyQuestions(false)
    }

    // Add user message to chat with animation
    const userMessage = {
      id: Date.now().toString(),
      role: "user" as const,
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    saveChatMessage(mobileNumber, { role: "user", content: input })

    // Clear input and set loading state
    const userQuery = input
    setInput("")
    setIsLoading(true)

    try {
      // Check if we're offline or have had too many API errors
      if (isOffline || apiErrorCount >= 3) {
        // Try to find an answer in offline FAQs
        const offlineAnswer = searchOfflineFAQs(userQuery, language)

        if (offlineAnswer) {
          // If we found an offline answer, use it
          const typedResponse = await typeMessage(offlineAnswer)

          const assistantMessage = {
            id: (Date.now() + 1).toString(),
            role: "assistant" as const,
            content: typedResponse,
          }

          setMessages((prev) => [...prev, assistantMessage])
          saveChatMessage(mobileNumber, { role: "assistant", content: assistantMessage.content })
        } else {
          // If no offline answer, show offline message
          const offlineMessage =
            language === "english"
              ? "I'm currently in offline mode and can't answer this question. Please try again when you're connected to the internet."
              : "நான் தற்போது ஆஃப்லைன் பயன்முறையில் உள்ளேன், இந்தக் கேள்விக்கு பதிலளிக்க முடியாது. நீங்கள் இணையத்துடன் இணைக்கப்பட்டிருக்கும்போது மீண்டும் முயற்சிக்கவும்."

          const typedResponse = await typeMessage(offlineMessage)

          const assistantMessage = {
            id: (Date.now() + 1).toString(),
            role: "assistant" as const,
            content: typedResponse,
          }

          setMessages((prev) => [...prev, assistantMessage])
          saveChatMessage(mobileNumber, { role: "assistant", content: assistantMessage.content })
        }
      } else {
        // Get AI response from our simplified API
        try {
          const response = await getAIResponse(userQuery, language)

          // Type out the response with animation
          const typedResponse = await typeMessage(response)

          // Add AI response to chat
          const assistantMessage = {
            id: (Date.now() + 1).toString(),
            role: "assistant" as const,
            content: typedResponse,
          }

          setMessages((prev) => [...prev, assistantMessage])
          saveChatMessage(mobileNumber, { role: "assistant", content: assistantMessage.content })

          // Reset API error count on successful response
          if (apiErrorCount > 0) {
            setApiErrorCount(0)
          }
        } catch (error) {
          console.error("Error getting AI response:", error)

          // Increment API error count
          setApiErrorCount((prev) => prev + 1)

          // Add error message
          const errorMessage = {
            id: (Date.now() + 1).toString(),
            role: "assistant" as const,
            content:
              language === "english"
                ? "I'm sorry, I couldn't process your request at the moment. Please try again later."
                : "மன்னிக்கவும், இப்போது உங்கள் கோரிக்கையை செயலாக்க முடியவில்லை. பின்னர் மீண்டும் முயற்சிக்கவும்.",
          }

          const typedResponse = await typeMessage(errorMessage.content)
          errorMessage.content = typedResponse

          setMessages((prev) => [...prev, errorMessage])
          saveChatMessage(mobileNumber, { role: "assistant", content: errorMessage.content })
        }
      }
    } catch (error) {
      console.error("Error in chat flow:", error)

      // Add error message
      const errorMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant" as const,
        content:
          language === "english"
            ? "I'm sorry, I couldn't process your request at the moment. Please try again later."
            : "மன்னிக்கவும், இப்போது உங்கள் கோரிக்கையை செயலாக்க முடியவில்லை. பின்னர் மீண்டும் முயற்சிக்கவும்.",
      }

      const typedResponse = await typeMessage(errorMessage.content)
      errorMessage.content = typedResponse

      setMessages((prev) => [...prev, errorMessage])
      saveChatMessage(mobileNumber, { role: "assistant", content: errorMessage.content })
    } finally {
      setIsLoading(false)
      // Focus back on input field
      if (inputRef.current) {
        inputRef.current.focus()
      }
    }
  }

  const handleShareLocation = async () => {
    if (location) {
      // If location already exists, share it in chat
      const locationMessage = {
        id: Date.now().toString(),
        role: "user" as const,
        content:
          language === "english"
            ? `My current location: ${formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`}`
            : `என் தற்போதைய இருப்பிடம்: ${formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`}`,
      }

      setMessages((prev) => [...prev, locationMessage])
      saveChatMessage(mobileNumber!, { role: "user", content: locationMessage.content })

      // Add a response acknowledging the location
      const responseMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant" as const,
        content:
          language === "english"
            ? "Thank you for sharing your location. This will help us provide more accurate assistance."
            : "உங்கள் இருப்பிடத்தைப் பகிர்ந்தமைக்கு நன்றி. இது நாங்கள் துல்லியமான உதவியை வழங்க உதவும்.",
      }

      await typeMessage(responseMessage.content)
      setMessages((prev) => [...prev, responseMessage])
      saveChatMessage(mobileNumber!, { role: "assistant", content: responseMessage.content })
    } else {
      // Request location if not already available
      const coords = await requestLocation()
      if (coords) {
        // Location was successfully obtained
        const locationMessage = {
          id: Date.now().toString(),
          role: "user" as const,
          content:
            language === "english"
              ? `My current location: ${formattedLocation || `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`}`
              : `என் தற்போதைய இருப்பிடம்: ${formattedLocation || `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`}`,
        }

        setMessages((prev) => [...prev, locationMessage])
        saveChatMessage(mobileNumber!, { role: "user", content: locationMessage.content })

        // Add a response acknowledging the location
        const responseMessage = {
          id: (Date.now() + 1).toString(),
          role: "assistant" as const,
          content:
            language === "english"
              ? "Thank you for sharing your location. This will help us provide more accurate assistance."
              : "உங்கள் இருப்பிடத்தைப் பகிர்ந்தமைக்கு நன்றி. இது நாங்கள் துல்லியமான உதவியை வழங்க உதவும்.",
        }

        await typeMessage(responseMessage.content)
        setMessages((prev) => [...prev, responseMessage])
        saveChatMessage(mobileNumber!, { role: "assistant", content: responseMessage.content })
      }
    }
  }

  const toggleLanguage = () => {
    setLanguage(language === "english" ? "tamil" : "english")
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    setNewMessageAlert(false)
  }

  // Handle safety question selection
  const handleSafetyQuestionSelect = (question: string) => {
    setInput(question)
    setShowSafetyQuestions(false)
    // Focus on input field
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  // Handle clear chat
  const handleClearChat = () => {
    setShowClearChatDialog(true)
  }

  // Confirm clear chat
  const confirmClearChat = () => {
    if (mobileNumber) {
      // Clear chat history from storage
      clearChatHistory(mobileNumber)

      // Reset messages to just the welcome message
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: t("welcome"),
        },
      ])

      setShowClearChatDialog(false)
    }
  }

  return (
    <Card className="w-full max-w-4xl h-[80vh] flex flex-col shadow-lg transition-all duration-300 hover:shadow-xl">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 border-b bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-900">
        <div className="flex items-center space-x-2">
          <Avatar className="h-8 w-8 ring-2 ring-primary/20 transition-all duration-300 hover:ring-primary">
            <AvatarImage src="/tn-police-logo.png" alt="Tamil Nadu Police Logo" className="animate-fade-in" />
            <AvatarFallback>TN</AvatarFallback>
          </Avatar>
          <CardTitle className="text-base sm:text-lg md:text-xl flex items-center">
            {t("chat.title")}
            {isOffline && (
              <div className="flex items-center text-amber-500 text-xs sm:text-sm ml-2 animate-pulse-subtle">
                <WifiOff className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                <span className="hidden sm:inline">{t("offline.mode")}</span>
              </div>
            )}
          </CardTitle>
        </div>
        <div className="flex items-center space-x-1 sm:space-x-2">
          <ThemeToggle />
          <Button
            variant="outline"
            size="sm"
            onClick={toggleLanguage}
            className="min-w-[40px] sm:min-w-[80px] text-xs sm:text-sm px-1 sm:px-3 btn-hover-effect"
          >
            {language === "english" ? "தமிழ்" : "English"}
          </Button>
          <UserProfile />
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-4 relative">
        {messages.map((message, index) => (
          <motion.div
            key={message.id}
            className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{
              duration: 0.3,
              delay: index === messages.length - 1 ? 0 : 0, // Only delay the latest message
              type: "spring",
              stiffness: 260,
              damping: 20,
            }}
          >
            <div
              className={`flex items-start max-w-[90%] sm:max-w-[80%] rounded-lg px-3 py-2 shadow-sm hover:shadow-md transition-all duration-300 ${
                message.role === "user"
                  ? "bg-primary text-primary-foreground message-out rounded-tr-none"
                  : "bg-muted message-in rounded-tl-none"
              }`}
            >
              {message.role === "assistant" && (
                <div className="flex-shrink-0 mr-2 mt-1">
                  <Bot className="h-4 w-4 sm:h-5 sm:w-5 animate-bounce-subtle" />
                </div>
              )}
              {message.role === "user" && (
                <div className="flex-shrink-0 mr-2 mt-1">
                  <UserIcon className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
              )}
              <div className={`text-sm sm:text-base break-words ${language === "tamil" ? "font-tamil" : ""}`}>
                {message.content}
              </div>
            </div>
          </motion.div>
        ))}

        {/* Enhanced typing indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              className="flex justify-start"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <div className="flex items-start max-w-[90%] sm:max-w-[80%] rounded-lg px-3 py-2 bg-muted rounded-tl-none shadow-sm">
                <Bot className="h-4 w-4 sm:h-5 sm:w-5 mr-2 mt-1 flex-shrink-0 animate-bounce-subtle" />
                <div className="flex flex-col">
                  <div className={`text-sm sm:text-base break-words ${language === "tamil" ? "font-tamil" : ""}`}>
                    {currentTypingMessage}
                  </div>
                  {!currentTypingMessage && (
                    <div className="flex mt-1">
                      <span className="typing-dot"></span>
                      <span className="typing-dot"></span>
                      <span className="typing-dot"></span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* New message alert */}
        <AnimatePresence>
          {newMessageAlert && (
            <motion.div
              className="absolute bottom-4 right-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <Button
                size="sm"
                onClick={scrollToBottom}
                className="shadow-lg animate-bounce-subtle bg-primary/90 hover:bg-primary"
              >
                <span className="mr-2">New message</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 19V5M5 12l7 7 7-7" />
                </svg>
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Safety Questions Panel */}
        <AnimatePresence>
          {showSafetyQuestions && (
            <motion.div
              className="absolute inset-0 bg-white/95 dark:bg-gray-900/95 z-10 p-4 overflow-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">
                  {language === "english" ? "Common Safety Questions" : "பொதுவான பாதுகாப்பு கேள்விகள்"}
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setShowSafetyQuestions(false)} className="h-8 w-8 p-0">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <DefaultSafetyQuestions onQuestionSelect={handleSafetyQuestionSelect} />
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </CardContent>
      <CardFooter className="pt-0 border-t p-2 sm:p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-900">
        <form onSubmit={handleSubmit} className="flex w-full items-center space-x-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className={`h-9 w-9 sm:h-10 sm:w-10 flex-shrink-0 btn-hover-effect ${location ? "text-green-500 border-green-200" : ""}`}
              >
                {isLocating ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <MapPin className={`h-4 w-4 ${location ? "text-green-500 animate-pulse-subtle" : ""}`} />
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 shadow-lg animate-fade-in" align="start">
              <div className="space-y-2">
                <div className="font-medium">{language === "english" ? "Location Services" : "இருப்பிட சேவைகள்"}</div>
                {locationError && (
                  <div className="text-sm text-destructive flex items-start animate-shake">
                    <AlertCircle className="h-4 w-4 mr-1 mt-0.5 flex-shrink-0" />
                    <span>{locationError}</span>
                  </div>
                )}
                {location && (
                  <div className="text-sm border rounded-md p-2 animate-fade-in hover:shadow-md transition-all duration-300">
                    <div className="font-medium mb-1">
                      {language === "english" ? "Current Location:" : "தற்போதைய இருப்பிடம்:"}
                    </div>
                    <div className="text-muted-foreground break-words">
                      {formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`}
                    </div>
                  </div>
                )}
                <div className="flex justify-between">
                  {location ? (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={clearLocation}
                        className="text-xs btn-hover-effect hover:bg-red-50 hover:text-red-500"
                      >
                        <X className="h-3 w-3 mr-1" />
                        {language === "english" ? "Clear" : "அழி"}
                      </Button>
                      <Button size="sm" onClick={handleShareLocation} className="text-xs btn-hover-effect">
                        {language === "english" ? "Share in Chat" : "அரட்டையில் பகிர்"}
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      onClick={requestLocation}
                      disabled={isLocating}
                      className="w-full text-xs btn-hover-effect"
                    >
                      {isLocating ? (
                        <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                      ) : (
                        <MapPin className="h-3 w-3 mr-1" />
                      )}
                      {language === "english" ? "Get My Location" : "என் இருப்பிடத்தைப் பெறு"}
                    </Button>
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  {language === "english"
                    ? "Your location is only shared when you choose to share it and is used solely to provide you with better assistance."
                    : "உங்கள் இருப்பிடம் நீங்கள் பகிர தேர்வு செய்யும்போது மட்டுமே பகிரப்படுகிறது மற்றும் உங்களுக்கு சிறந்த உதவியை வழங்க மட்டுமே பயன்படுத்தப்படுகிறது."}
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Safety Questions Button */}
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => setShowSafetyQuestions(!showSafetyQuestions)}
            className="h-9 w-9 sm:h-10 sm:w-10 flex-shrink-0 btn-hover-effect"
            title={language === "english" ? "Safety Questions" : "பாதுகாப்பு கேள்விகள்"}
          >
            <HelpCircle className="h-4 w-4" />
          </Button>

          {/* Clear Chat Button */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={handleClearChat}
                  className="h-9 w-9 sm:h-10 sm:w-10 flex-shrink-0 btn-hover-effect"
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="animate-fade-in">
                <p>{language === "english" ? "Clear chat history" : "அரட்டை வரலாற்றை அழிக்கவும்"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t("chat.input.placeholder")}
            disabled={isLoading || isTyping}
            className={`flex-1 text-sm sm:text-base ${language === "tamil" ? "font-tamil" : ""} ${shakeInput ? "animate-shake border-red-300" : ""} transition-all focus:border-primary focus:ring-2 focus:ring-primary/20`}
          />

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || isTyping}
                  className={`${!input.trim() ? "opacity-50" : "opacity-100"} transition-all h-9 w-9 sm:h-10 sm:w-10 flex-shrink-0 btn-hover-effect ${input.trim() ? "bg-primary hover:bg-primary/90" : ""}`}
                >
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="animate-fade-in">
                <p>{language === "english" ? "Send message" : "செய்தி அனுப்பு"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </form>
      </CardFooter>

      {/* Clear Chat Confirmation Dialog */}
      <AlertDialog open={showClearChatDialog} onOpenChange={setShowClearChatDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {language === "english" ? "Clear Chat History" : "அரட்டை வரலாற்றை அழிக்கவும்"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {language === "english"
                ? "Are you sure you want to clear all chat history? This action cannot be undone."
                : "அனைத்து அரட்டை வரலாற்றையும் அழிக்க விரும்புகிறீர்களா? இந்த செயலை செயல்தவிர்க்க முடியாது."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{language === "english" ? "Cancel" : "ரத்து செய்"}</AlertDialogCancel>
            <AlertDialogAction onClick={confirmClearChat} className="bg-red-500 hover:bg-red-600">
              {language === "english" ? "Clear" : "அழி"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

