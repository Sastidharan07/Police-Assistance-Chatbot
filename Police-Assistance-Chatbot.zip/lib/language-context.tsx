"use client"

import { createContext, useContext, useState, type ReactNode, useEffect } from "react"

type Language = "english" | "tamil"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

// Translations dictionary
const translations: Record<string, Record<Language, string>> = {
  welcome: {
    english: "Hello! I am your Police Assistance Chatbot. How can I help you today?",
    tamil: "வணக்கம்! நான் உங்கள் காவல்துறை உதவி சாட்போட். நான் உங்களுக்கு எப்படி உதவ முடியும்?",
  },
  "login.title": {
    english: "Police Assistance Portal",
    tamil: "காவல்துறை உதவி போர்டல்",
  },
  "login.description": {
    english: "Enter your mobile number and verify with OTP to access the assistance chatbot.",
    tamil: "உதவி சாட்போட்டை அணுக உங்கள் மொபைல் எண்ணை உள்ளிட்டு OTP மூலம் சரிபார்க்கவும்.",
  },
  "login.mobile": {
    english: "Mobile Number",
    tamil: "மொபைல் எண்",
  },
  "login.mobile.placeholder": {
    english: "Enter 10-digit mobile number",
    tamil: "10-இலக்க மொபைல் எண்ணை உள்ளிடவும்",
  },
  "login.otp": {
    english: "OTP",
    tamil: "OTP",
  },
  "login.otp.placeholder": {
    english: "Enter 6-digit OTP",
    tamil: "6-இலக்க OTP ஐ உள்ளிடவும்",
  },
  "login.sendOtp": {
    english: "Send OTP",
    tamil: "OTP அனுப்பு",
  },
  "login.sending": {
    english: "Sending...",
    tamil: "அனுப்புகிறது...",
  },
  "login.verify": {
    english: "Verify",
    tamil: "சரிபார்க்க",
  },
  "login.verifying": {
    english: "Verifying...",
    tamil: "சரிபார்க்கிறது...",
  },
  "login.resendOtp": {
    english: "Resend OTP",
    tamil: "OTP மீண்டும் அனுப்பு",
  },
  "login.resendSuccess": {
    english: "Resent successfully",
    tamil: "வெற்றிகரமாக மீண்டும் அனுப்பப்பட்டது",
  },
  "login.testMode": {
    english: "Use test mode (OTP: 123456)",
    tamil: "சோதனை முறையைப் பயன்படுத்தவும் (OTP: 123456)",
  },
  "login.error.invalidMobile": {
    english: "Please enter a valid Indian mobile number (starting with 9, 8, 7, or 6)",
    tamil: "தயவுசெய்து சரியான இந்திய மொபைல் எண்ணை உள்ளிடவும் (9, 8, 7 அல்லது 6 இல் தொடங்க வேண்டும்)",
  },
  "login.error.invalidOtp": {
    english: "Invalid OTP. Please enter a 6-digit code.",
    tamil: "தவறான OTP. 6-இலக்க குறியீட்டை உள்ளிடவும்.",
  },
  "login.error.sendOtp": {
    english: "Failed to send OTP. Please try again.",
    tamil: "OTP அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
  },
  "login.error.verifyOtp": {
    english: "Failed to verify OTP. Please try again.",
    tamil: "OTP சரிபார்க்க முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
  },
  "chat.title": {
    english: "Police Assistance Chatbot",
    tamil: "காவல்துறை உதவி சாட்போட்",
  },
  "chat.input.placeholder": {
    english: "Type your message here...",
    tamil: "உங்கள் செய்தியை இங்கே தட்டச்சு செய்யவும்...",
  },
  "emergency.title": {
    english: "Emergency Contacts",
    tamil: "அவசர தொடர்புகள்",
  },
  "emergency.add": {
    english: "Add Contact",
    tamil: "தொடர்பைச் சேர்க்கவும்",
  },
  "emergency.name": {
    english: "Name",
    tamil: "பெயர்",
  },
  "emergency.phone": {
    english: "Phone Number",
    tamil: "தொலைபேசி எண்",
  },
  "emergency.save": {
    english: "Save",
    tamil: "சேமி",
  },
  "emergency.delete": {
    english: "Delete",
    tamil: "நீக்கு",
  },
  "emergency.call": {
    english: "Call",
    tamil: "அழைப்பு",
  },
  "emergency.message": {
    english: "Message",
    tamil: "செய்தி",
  },
  "emergency.tnServices": {
    english: "Tamil Nadu Emergency Services",
    tamil: "தமிழ்நாடு அவசர சேவைகள்",
  },
  "emergency.calling": {
    english: "Calling",
    tamil: "அழைக்கிறது",
  },
  "emergency.cancel": {
    english: "Cancel",
    tamil: "ரத்து செய்",
  },
  "emergency.error.name": {
    english: "Please enter a name",
    tamil: "தயவுசெய்து ஒரு பெயரை உள்ளிடவும்",
  },
  "emergency.error.phone": {
    english: "Please enter a phone number",
    tamil: "தயவுசெய்து ஒரு தொலைபேசி எண்ணை உள்ளிடவும்",
  },
  "emergency.error.invalidPhone": {
    english: "Please enter a valid 10-digit Indian mobile number (starting with 9, 8, 7, or 6)",
    tamil: "தயவுசெய்து சரியான 10-இலக்க இந்திய மொபைல் எண்ணை உள்ளிடவும் (9, 8, 7 அல்லது 6 இல் தொடங்க வேண்டும்)",
  },
  "emergency.error.limit": {
    english: "Could not add contact. You may have reached the limit of 5 contacts or this number is already saved.",
    tamil: "தொடர்பைச் சேர்க்க முடியவில்லை. நீங்கள் 5 தொடர்புகளின் வரம்பை அடைந்திருக்கலாம் அல்லது இந்த எண் ஏற்கனவே சேமிக்கப்பட்டிருக்கலாம்.",
  },
  "procedures.title": {
    english: "How to Use This Application",
    tamil: "இந்த பயன்பாட்டை எப்படி பயன்படுத்துவது",
  },
  "procedures.step1": {
    english: "1. Use the Chat tab to ask questions about police procedures and laws",
    tamil: "1. காவல்துறை நடைமுறைகள் மற்றும் சட்டங்கள் பற்றிய கேள்விகளைக் கேட்க அரட்டை தாவலைப் பயன்படுத்தவும்",
  },
  "procedures.step2": {
    english: "2. Add emergency contacts in the Emergency tab for quick access",
    tamil: "2. விரைவான அணுகலுக்கு அவசர தாவலில் அவசர தொடர்புகளைச் சேர்க்கவும்",
  },
  "procedures.step3": {
    english: "3. Submit complaints through the Complaint tab with all relevant details",
    tamil: "3. அனைத்து தொடர்புடைய விவரங்களுடன் புகார் தாவல் மூலம் புகார்களைச் சமர்ப்பிக்கவும்",
  },
  "procedures.step4": {
    english: "4. Switch between English and Tamil using the language button",
    tamil: "4. மொழி பொத்தானைப் பயன்படுத்தி ஆங்கிலம் மற்றும் தமிழுக்கு இடையே மாறவும்",
  },
  "procedures.step5": {
    english: "5. All your data is saved automatically and linked to your mobile number",
    tamil: "5. உங்கள் அனைத்து தரவும் தானாகவே சேமிக்கப்பட்டு உங்கள் மொபைல் எண்ணுடன் இணைக்கப்படும்",
  },
  "complaint.title": {
    english: "Submit a Complaint",
    tamil: "புகார் சமர்ப்பிக்கவும்",
  },
  "complaint.name": {
    english: "Full Name",
    tamil: "முழு பெயர்",
  },
  "complaint.phone": {
    english: "Phone Number",
    tamil: "தொலைபேசி எண்",
  },
  "complaint.address": {
    english: "Address",
    tamil: "முகவரி",
  },
  "complaint.incident": {
    english: "Incident Details",
    tamil: "சம்பவ விவரங்கள்",
  },
  "complaint.date": {
    english: "Incident Date",
    tamil: "சம்பவ தேதி",
  },
  "complaint.location": {
    english: "Incident Location",
    tamil: "சம்பவ இடம்",
  },
  "complaint.description": {
    english: "Description",
    tamil: "விளக்கம்",
  },
  "complaint.submit": {
    english: "Submit Complaint",
    tamil: "புகார் சமர்ப்பிக்கவும்",
  },
  "complaint.previous": {
    english: "Previous Complaints",
    tamil: "முந்தைய புகார்கள்",
  },
  "complaint.delete": {
    english: "Delete Complaint",
    tamil: "புகாரை நீக்கு",
  },
  "nav.chat": {
    english: "Chat",
    tamil: "அரட்டை",
  },
  "nav.emergency": {
    english: "Emergency",
    tamil: "அவசரம்",
  },
  "nav.procedures": {
    english: "Procedures",
    tamil: "நடைமுறைகள்",
  },
  "nav.complaint": {
    english: "Complaint",
    tamil: "புகார்",
  },
  "nav.legal": {
    english: "Legal Rights",
    tamil: "சட்ட உரிமைகள்",
  },
  "nav.faq": {
    english: "FAQs",
    tamil: "கேள்விகள்",
  },
  "nav.location": {
    english: "Police Stations",
    tamil: "காவல் நிலையங்கள்",
  },
  "legal.title": {
    english: "Legal Rights & Articles",
    tamil: "சட்ட உரிமைகள் & கட்டுரைகள்",
  },
  "legal.search": {
    english: "Search legal information...",
    tamil: "சட்ட தகவல்களைத் தேடுங்கள்...",
  },
  "legal.rights": {
    english: "Your Rights",
    tamil: "உங்கள் உரிமைகள்",
  },
  "legal.articles": {
    english: "Legal Articles",
    tamil: "சட்ட கட்டுரைகள்",
  },
  "legal.noResults": {
    english: "No results found. Try a different search term.",
    tamil: "முடிவுகள் எதுவும் கிடைக்கவில்லை. வேறு தேடல் சொல்லை முயற்சிக்கவும்.",
  },
  "faq.title": {
    english: "Quick Access Questions",
    tamil: "விரைவு அணுகல் கேள்விகள்",
  },
  "faq.search": {
    english: "Search questions...",
    tamil: "கேள்விகளைத் தேடுங்கள்...",
  },
  "faq.noResults": {
    english: "No questions found. Try a different search term.",
    tamil: "கேள்விகள் எதுவும் கிடைக்கவில்லை. வேறு தேடல் சொல்லை முயற்சிக்கவும்.",
  },
  "faq.all": {
    english: "All",
    tamil: "அனைத்தும்",
  },
  "faq.complaints": {
    english: "Complaints",
    tamil: "புகார்கள்",
  },
  "faq.legal": {
    english: "Legal",
    tamil: "சட்டம்",
  },
  "faq.emergency": {
    english: "Emergency",
    tamil: "அவசரம்",
  },
  "offline.mode": {
    english: "Offline Mode",
    tamil: "ஆஃப்லைன் பயன்முறை",
  },
  "location.services": {
    english: "Location Services",
    tamil: "இருப்பிட சேவைகள்",
  },
  "location.current": {
    english: "Current Location:",
    tamil: "தற்போதைய இருப்பிடம்:",
  },
  "location.get": {
    english: "Get My Location",
    tamil: "என் இருப்பிடத்தைப் பெறு",
  },
  "location.share": {
    english: "Share in Chat",
    tamil: "அரட்டையில் பகிர்",
  },
  "location.clear": {
    english: "Clear",
    tamil: "அழி",
  },
  "location.privacy": {
    english:
      "Your location is only shared when you choose to share it and is used solely to provide you with better assistance.",
    tamil:
      "உங்கள் இருப்பிடம் நீங்கள் பகிர தேர்வு செய்யும்போது மட்டுமே பகிரப்படுகிறது மற்றும் உங்களுக்கு சிறந்த உதவியை வழங்க மட்டுமே பயன்படுத்தப்படுகிறது.",
  },
  "location.error": {
    english: "Error getting location",
    tamil: "இருப்பிடத்தைப் பெறுவதில் பிழை",
  },
  "location.permission.denied": {
    english: "Location permission denied",
    tamil: "இருப்பிட அனுமதி மறுக்கப்பட்டது",
  },
  "location.unavailable": {
    english: "Location information is unavailable",
    tamil: "இருப்பிட தகவல் கிடைக்கவில்லை",
  },
  "location.timeout": {
    english: "Location request timed out",
    tamil: "இருப்பிட கோரிக்கை நேரம் முடிந்தது",
  },
  "location.unknown.error": {
    english: "An unknown error occurred",
    tamil: "அறியப்படாத பிழை ஏற்பட்டது",
  },
  "location.finder.title": {
    english: "Police Station Finder",
    tamil: "காவல் நிலைய கண்டுபிடிப்பான்",
  },
  "location.finder.description": {
    english: "Find the nearest police stations and get directions",
    tamil: "அருகிலுள்ள காவல் நிலையங்களைக் கண்டறிந்து வழிகாட்டுதல்களைப் பெறுங்கள்",
  },
  "location.finder.found": {
    english: "Location Found",
    tamil: "இருப்பிடம் கண்டறியப்பட்டது",
  },
  "location.finder.required": {
    english: "Location services are required to find nearby police stations",
    tamil: "அருகிலுள்ள காவல் நிலையங்களைக் கண்டறிய இருப்பிட சேவைகள் தேவை",
  },
  "location.finder.find": {
    english: "Find Police Stations",
    tamil: "காவல் நிலையங்களைக் கண்டறி",
  },
  "location.finder.nearby": {
    english: "Nearby Police Stations",
    tamil: "அருகிலுள்ள காவல் நிலையங்கள்",
  },
  "location.finder.directions": {
    english: "Directions",
    tamil: "திசைகள்",
  },
  "location.finder.open.maps": {
    english: "Open in Google Maps",
    tamil: "Google Maps இல் திற",
  },
  "location.finder.away": {
    english: "away",
    tamil: "தொலைவில்",
  },
  "location.finder.follow": {
    english: "Follow the blue line on the map to reach",
    tamil: "வரைபடத்தில் உள்ள நீல கோட்டைப் பின்பற்றி சென்றடையவும்",
  },
  "sos.button": {
    english: "SEND SOS ALERT",
    tamil: "SOS எச்சரிக்கையை அனுப்பு",
  },
  "sos.sent": {
    english: "SOS Alert Sent",
    tamil: "SOS எச்சரிக்கை அனுப்பப்பட்டது",
  },
  "sos.sent.description": {
    english: "Your emergency alert has been sent to the nearest police station with your location details.",
    tamil: "உங்கள் அவசர எச்சரிக்கை உங்கள் இருப்பிட விவரங்களுடன் அருகிலுள்ள காவல் நிலையத்திற்கு அனுப்பப்பட்டுள்ளது.",
  },
  "sos.failed": {
    english: "Alert Failed",
    tamil: "எச்சரிக்கை தோல்வியடைந்தது",
  },
  "sos.failed.description": {
    english: "Failed to send SOS alert. Please try again or call emergency services directly.",
    tamil: "SOS எச்சரிக்கையை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும் அல்லது நேரடியாக அவசர சேவைகளை அழைக்கவும்.",
  },
  "sos.location.required": {
    english: "Please enable location services to send an SOS alert.",
    tamil: "SOS எச்சரிக்கையை அனுப்ப இருப்பிட சேவைகளை இயக்கவும்.",
  },
  "safety.questions.title": {
    english: "Safety Questions",
    tamil: "பாதுகாப்பு கேள்விகள்",
  },
  "safety.questions.search": {
    english: "Search questions...",
    tamil: "கேள்விகளைத் தேடுங்கள்...",
  },
  "safety.questions.category.reporting": {
    english: "Reporting",
    tamil: "புகார் அளித்தல்",
  },
  "safety.questions.category.emergency": {
    english: "Emergency",
    tamil: "அவசரம்",
  },
  "safety.questions.category.safety": {
    english: "Safety Tips",
    tamil: "பாதுகாப்பு குறிப்புகள்",
  },
  "safety.questions.category.services": {
    english: "Services",
    tamil: "சேவைகள்",
  },
  "safety.questions.noResults": {
    english: "No questions found. Try a different search term.",
    tamil: "கேள்விகள் எதுவும் கிடைக்கவில்லை. வேறு தேடல் சொல்லை முயற்சிக்கவும்.",
  },
  "safety.questions.common": {
    english: "Common Safety Questions",
    tamil: "பொதுவான பாதுகாப்பு கேள்விகள்",
  },
  logout: {
    english: "Logout",
    tamil: "வெளியேறு",
  },
  language: {
    english: "தமிழ்", // Show Tamil as option when in English
    tamil: "English", // Show English as option when in Tamil
  },
  "theme.light": {
    english: "Light",
    tamil: "வெளிச்சம்",
  },
  "theme.dark": {
    english: "Dark",
    tamil: "இருள்",
  },
  "theme.system": {
    english: "System",
    tamil: "கணினி அமைப்பு",
  },
  "profile.myAccount": {
    english: "My Account",
    tamil: "எனது கணக்கு",
  },
  "profile.profile": {
    english: "Profile",
    tamil: "சுயவிவரம்",
  },
  "profile.settings": {
    english: "Settings",
    tamil: "அமைப்புகள்",
  },
  "profile.confirmLogout": {
    english: "Confirm Logout",
    tamil: "வெளியேற உறுதிப்படுத்தவும்",
  },
  "profile.confirmLogoutDesc": {
    english: "Are you sure you want to logout from your account?",
    tamil: "உங்கள் கணக்கிலிருந்து வெளியேற விரும்புகிறீர்களா?",
  },
  "profile.cancel": {
    english: "Cancel",
    tamil: "ரத்து செய்",
  },
  "chat.clearHistory": {
    english: "Clear chat history",
    tamil: "அரட்டை வரலாற்றை அழிக்கவும்",
  },
  "chat.clearHistoryTitle": {
    english: "Clear Chat History",
    tamil: "அரட்டை வரலாற்றை அழிக்கவும்",
  },
  "chat.clearHistoryDesc": {
    english: "Are you sure you want to clear all chat history? This action cannot be undone.",
    tamil: "அனைத்து அரட்டை வரலாற்றையும் அழிக்க விரும்புகிறீர்களா? இந்த செயலை செயல்தவிர்க்க முடியாது.",
  },
  "chat.clear": {
    english: "Clear",
    tamil: "அழி",
  },
  "chat.sendMessage": {
    english: "Send message",
    tamil: "செய்தி அனுப்பு",
  },
  "profile.title": {
    english: "User Profile",
    tamil: "பயனர் சுயவிவரம்",
  },
  "profile.description": {
    english: "Manage your personal information and account settings",
    tamil: "உங்கள் தனிப்பட்ட தகவல்களையும் கணக்கு அமைப்புகளையும் நிர்வகிக்கவும்",
  },
  "profile.fullName": {
    english: "Full Name",
    tamil: "முழு பெயர்",
  },
  "profile.email": {
    english: "Email Address",
    tamil: "மின்னஞ்சல் முகவரி",
  },
  "profile.phone": {
    english: "Phone Number",
    tamil: "தொலைபேசி எண்",
  },
  "profile.address": {
    english: "Address",
    tamil: "முகவரி",
  },
  "profile.gender": {
    english: "Gender",
    tamil: "பாலினம்",
  },
  "profile.gender.male": {
    english: "Male",
    tamil: "ஆண்",
  },
  "profile.gender.female": {
    english: "Female",
    tamil: "பெண்",
  },
  "profile.gender.other": {
    english: "Other",
    tamil: "மற்றவை",
  },
  "profile.dateOfBirth": {
    english: "Date of Birth",
    tamil: "பிறந்த தேதி",
  },
  "profile.memberSince": {
    english: "Member since",
    tamil: "உறுப்பினராக இருந்து",
  },
  "profile.edit": {
    english: "Edit Profile",
    tamil: "சுயவிவரத்தைத் திருத்து",
  },
  "profile.save": {
    english: "Save Changes",
    tamil: "மாற்றங்களைச் சேமிக்கவும்",
  },
  "profile.saving": {
    english: "Saving...",
    tamil: "சேமிக்கிறது...",
  },
  "profile.cancel": {
    english: "Cancel",
    tamil: "ரத்து செய்",
  },
  "profile.success": {
    english: "Profile updated successfully!",
    tamil: "சுயவிவரம் வெற்றிகரமாக புதுப்பிக்கப்பட்டது!",
  },
  "settings.title": {
    english: "Settings",
    tamil: "அமைப்புகள்",
  },
  "settings.description": {
    english: "Customize your application preferences and settings",
    tamil: "உங்கள் பயன்பாட்டு விருப்பங்கள் மற்றும் அமைப்புகளை தனிப்பயனாக்கவும்",
  },
  "settings.appearance": {
    english: "Appearance",
    tamil: "தோற்றம்",
  },
  "settings.notifications": {
    english: "Notifications",
    tamil: "அறிவிப்புகள்",
  },
  "settings.privacy": {
    english: "Privacy",
    tamil: "தனியுரிமை",
  },
  "settings.help": {
    english: "Help",
    tamil: "உதவி",
  },
  "settings.save": {
    english: "Save Changes",
    tamil: "மாற்றங்களைச் சேமிக்கவும்",
  },
  "settings.success": {
    english: "Settings saved successfully!",
    tamil: "அமைப்புகள் வெற்றிகரமாக சேமிக்கப்பட்டன!",
  },
  "register.title": {
    english: "Register",
    tamil: "பதிவு செய்ய",
  },
  "register.button": {
    english: "Register & Send OTP",
    tamil: "பதிவு செய்து OTP அனுப்பு",
  },
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("english")

  // Load language preference from localStorage on component mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "english" || savedLanguage === "tamil")) {
      setLanguageState(savedLanguage)
    }
  }, [])

  // Set the language attribute on the html element for proper font selection
  useEffect(() => {
    document.documentElement.lang = language === "english" ? "en" : "ta"

    // Add or remove tamil-text class from body based on language
    if (language === "tamil") {
      document.body.classList.add("tamil-text")
    } else {
      document.body.classList.remove("tamil-text")
    }
  }, [language])

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("language", newLanguage)
  }

  const t = (key: string): string => {
    const translation = translations[key]?.[language] || key
    return translation
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

