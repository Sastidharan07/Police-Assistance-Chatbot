import { type NextRequest, NextResponse } from "next/server"

// Mock responses for different categories of questions
const mockResponses = {
  english: {
    police: [
      "The Tamil Nadu Police is the primary law enforcement agency for the state of Tamil Nadu, India. You can contact them at emergency number 100.",
      "To file a police complaint in Tamil Nadu, visit your nearest police station with your ID proof and details of the incident.",
      "The Tamil Nadu Police has jurisdiction over all areas within the state of Tamil Nadu.",
    ],
    emergency: [
      "For police emergency in Tamil Nadu, dial 100.",
      "For medical emergency, dial 108 for ambulance services.",
      "For women's helpline, dial 1091.",
      "For child helpline, dial 1098.",
    ],
    legal: [
      "Under Indian law, you have the right to legal representation when arrested.",
      "You have the right to know the grounds of your arrest.",
      "You have the right to be presented before a magistrate within 24 hours of arrest.",
      "You have the right to bail for bailable offenses.",
    ],
    default: [
      "I'm your Police Assistance Chatbot. How can I help you today?",
      "I can provide information about police procedures, emergency contacts, and legal rights in Tamil Nadu.",
      "Please ask me any questions related to police services or legal assistance in Tamil Nadu.",
    ],
  },
  tamil: {
    police: [
      "தமிழ்நாடு காவல்துறை என்பது இந்தியாவின் தமிழ்நாடு மாநிலத்தின் முதன்மை சட்ட அமலாக்க நிறுவனமாகும். அவசர எண் 100 இல் அவர்களைத் தொடர்பு கொள்ளலாம்.",
      "தமிழ்நாட்டில் காவல்துறை புகார் அளிக்க, உங்கள் அடையாள சான்று மற்றும் சம்பவத்தின் விவரங்களுடன் உங்களுக்கு அருகிலுள்ள காவல் நிலையத்திற்குச் செல்லவும்.",
      "தமிழ்நாடு காவல்துறைக்கு தமிழ்நாடு மாநிலத்திற்குள் உள்ள அனைத்து பகுதிகளிலும் அதிகார எல்லை உள்ளது.",
    ],
    emergency: [
      "தமிழ்நாட்டில் காவல்துறை அவசரநிலைக்கு, 100 ஐ அழைக்கவும்.",
      "மருத்துவ அவசரநிலைக்கு, ஆம்புலன்ஸ் சேவைகளுக்கு 108 ஐ அழைக்கவும்.",
      "பெண்கள் உதவி எண்ணிற்கு, 1091 ஐ அழைக்கவும்.",
      "குழந்தைகள் உதவி எண்ணிற்கு, 1098 ஐ அழைக்கவும்.",
    ],
    legal: [
      "இந்திய சட்டத்தின் கீழ், கைது செய்யப்படும்போது சட்ட பிரதிநிதித்துவத்திற்கான உரிமை உங்களுக்கு உண்டு.",
      "உங்கள் கைது காரணங்களை அறியும் உரிமை உங்களுக்கு உண்டு.",
      "கைது செய்யப்பட்ட 24 மணி நேரத்திற்குள் நீதிபதி முன் ஆஜர்படுத்தப்படும் உரிமை உங்களுக்கு உண்டு.",
      "ஜாமீன் வழங்கக்கூடிய குற்றங்களுக்கு ஜாமீன் பெறும் உரிமை உங்களுக்கு உண்டு.",
    ],
    default: [
      "நான் உங்கள் காவல்துறை உதவி சாட்போட். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?",
      "நான் தமிழ்நாட்டில் காவல்துறை நடைமுறைகள், அவசர தொடர்புகள் மற்றும் சட்ட உரிமைகள் பற்றிய தகவல்களை வழங்க முடியும்.",
      "தமிழ்நாட்டில் காவல்துறை சேவைகள் அல்லது சட்ட உதவி தொடர்பான எந்தக் கேள்விகளையும் என்னிடம் கேளுங்கள்.",
    ],
  },
}

// Function to determine the category of a message
function determineCategory(message: string): string {
  message = message.toLowerCase()

  if (
    message.includes("police") ||
    message.includes("complaint") ||
    message.includes("fir") ||
    message.includes("காவல்") ||
    message.includes("புகார்")
  ) {
    return "police"
  }

  if (
    message.includes("emergency") ||
    message.includes("help") ||
    message.includes("urgent") ||
    message.includes("அவசர") ||
    message.includes("உதவி")
  ) {
    return "emergency"
  }

  if (
    message.includes("right") ||
    message.includes("law") ||
    message.includes("legal") ||
    message.includes("உரிமை") ||
    message.includes("சட்ட")
  ) {
    return "legal"
  }

  return "default"
}

// Function to get a random response from the appropriate category
function getResponse(message: string, language: string): string {
  const category = determineCategory(message)
  const responses =
    mockResponses[language as keyof typeof mockResponses][category as keyof (typeof mockResponses)["english"]]
  const randomIndex = Math.floor(Math.random() * responses.length)
  return responses[randomIndex]
}

export async function POST(request: NextRequest) {
  try {
    // Parse the request body
    const body = await request.json()
    const { messages, language = "english" } = body

    // Get the last user message
    const lastMessage = messages[messages.length - 1]

    if (!lastMessage || !lastMessage.content) {
      return new NextResponse("No message provided", { status: 400 })
    }

    // Get a response based on the message content and language
    const responseText = getResponse(lastMessage.content, language)

    // Return the response
    return new NextResponse(responseText)
  } catch (error) {
    console.error("Error processing chat request:", error)
    return new NextResponse("An error occurred while processing your request", { status: 500 })
  }
}

