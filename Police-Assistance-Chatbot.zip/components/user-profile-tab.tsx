"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { User, Mail, Phone, MapPin, Calendar, Save, Loader2, CheckCircle } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { motion, AnimatePresence } from "framer-motion"
import { format } from "date-fns"
import type { UserProfile } from "@/lib/storage-service"

export function UserProfileTab() {
  const { userProfile, updateUserProfile, mobileNumber } = useAuth()
  const { language } = useLanguage()
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    username: "",
    email: "",
    address: "",
    gender: "",
    dateOfBirth: "",
  })

  // Load user profile data when component mounts
  useEffect(() => {
    if (userProfile) {
      setFormData({
        username: userProfile.username || "",
        email: userProfile.email || "",
        address: userProfile.address || "",
        gender: userProfile.gender || "",
        dateOfBirth: userProfile.dateOfBirth || "",
      })
    }
  }, [userProfile])

  // Reset success message after 3 seconds
  useEffect(() => {
    if (saveSuccess) {
      const timer = setTimeout(() => {
        setSaveSuccess(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [saveSuccess])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleGenderChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      gender: value,
    }))
  }

  const handleSave = async () => {
    setIsSaving(true)

    try {
      // Update user profile
      updateUserProfile({
        ...formData,
        lastUpdated: new Date().toISOString(),
      })

      // Show success message
      setSaveSuccess(true)

      // Exit edit mode
      setIsEditing(false)
    } catch (error) {
      console.error("Error saving profile:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const getUserInitials = () => {
    if (!userProfile?.username) return "U"

    const nameParts = userProfile.username.split(" ")
    if (nameParts.length === 1) return nameParts[0].charAt(0).toUpperCase()

    return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase()
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return ""
    try {
      return format(new Date(dateString), "PPP")
    } catch (error) {
      return dateString
    }
  }

  return (
    <Card className="w-full shadow-md">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">{language === "english" ? "User Profile" : "பயனர் சுயவிவரம்"}</CardTitle>
          <Button
            variant={isEditing ? "outline" : "default"}
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
            disabled={isSaving}
          >
            {isEditing
              ? language === "english"
                ? "Cancel"
                : "ரத்து செய்"
              : language === "english"
                ? "Edit Profile"
                : "சுயவிவரத்தைத் திருத்து"}
          </Button>
        </div>
        <CardDescription>
          {language === "english"
            ? "Manage your personal information and account settings"
            : "உங்கள் தனிப்பட்ட தகவல்களையும் கணக்கு அமைப்புகளையும் நிர்வகிக்கவும்"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Profile header with avatar */}
        <div className="flex flex-col sm:flex-row items-center gap-4 pb-4 border-b">
          <Avatar className="h-20 w-20 border-2 border-primary/20">
            <AvatarImage src={userProfile?.profilePicture || ""} alt={userProfile?.username || "User"} />
            <AvatarFallback className="text-xl bg-primary text-primary-foreground">{getUserInitials()}</AvatarFallback>
          </Avatar>

          <div className="text-center sm:text-left">
            <h3 className="text-lg font-medium">
              {userProfile?.username || (language === "english" ? "User" : "பயனர்")}
            </h3>
            <p className="text-sm text-muted-foreground">{userProfile?.email || ""}</p>
            <p className="text-sm text-muted-foreground">
              {language === "english" ? "Member since: " : "உறுப்பினராக இருந்து: "}
              {userProfile?.createdAt ? formatDate(userProfile.createdAt) : "-"}
            </p>
          </div>
        </div>

        {/* Profile form */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="flex items-center gap-1">
                <User className="h-4 w-4 text-muted-foreground" />
                {language === "english" ? "Full Name" : "முழு பெயர்"}
              </Label>
              <Input
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                placeholder={language === "english" ? "Enter your full name" : "உங்கள் முழு பெயரை உள்ளிடவும்"}
                disabled={!isEditing}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-1">
                <Mail className="h-4 w-4 text-muted-foreground" />
                {language === "english" ? "Email Address" : "மின்னஞ்சல் முகவரி"}
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder={language === "english" ? "Enter your email" : "உங்கள் மின்னஞ்சலை உள்ளிடவும்"}
                disabled={!isEditing}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber" className="flex items-center gap-1">
                <Phone className="h-4 w-4 text-muted-foreground" />
                {language === "english" ? "Phone Number" : "தொலைபேசி எண்"}
              </Label>
              <div className="flex">
                <div className="bg-muted flex items-center justify-center px-3 border border-r-0 rounded-l-md">+91</div>
                <Input id="phoneNumber" value={mobileNumber || ""} className="rounded-l-none" disabled={true} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="gender" className="flex items-center gap-1">
                <User className="h-4 w-4 text-muted-foreground" />
                {language === "english" ? "Gender" : "பாலினம்"}
              </Label>
              {isEditing ? (
                <Select onValueChange={handleGenderChange} value={formData.gender || ""}>
                  <SelectTrigger>
                    <SelectValue placeholder={language === "english" ? "Select gender" : "பாலினத்தைத் தேர்ந்தெடுக்கவும்"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">{language === "english" ? "Male" : "ஆண்"}</SelectItem>
                    <SelectItem value="female">{language === "english" ? "Female" : "பெண்"}</SelectItem>
                    <SelectItem value="other">{language === "english" ? "Other" : "மற்றவை"}</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  value={
                    formData.gender === "male"
                      ? language === "english"
                        ? "Male"
                        : "ஆண்"
                      : formData.gender === "female"
                        ? language === "english"
                          ? "Female"
                          : "பெண்"
                        : formData.gender === "other"
                          ? language === "english"
                            ? "Other"
                            : "மற்றவை"
                          : ""
                  }
                  disabled={true}
                />
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address" className="flex items-center gap-1">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              {language === "english" ? "Address" : "முகவரி"}
            </Label>
            <Textarea
              id="address"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              placeholder={language === "english" ? "Enter your address" : "உங்கள் முகவரியை உள்ளிடவும்"}
              disabled={!isEditing}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dateOfBirth" className="flex items-center gap-1">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              {language === "english" ? "Date of Birth" : "பிறந்த தேதி"}
            </Label>
            <Input
              id="dateOfBirth"
              name="dateOfBirth"
              type="date"
              value={formData.dateOfBirth || ""}
              onChange={handleInputChange}
              disabled={!isEditing}
            />
          </div>
        </div>
      </CardContent>

      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            <CardFooter className="border-t pt-4">
              <Button onClick={handleSave} disabled={isSaving} className="ml-auto">
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {language === "english" ? "Saving..." : "சேமிக்கிறது..."}
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {language === "english" ? "Save Changes" : "மாற்றங்களைச் சேமிக்கவும்"}
                  </>
                )}
              </Button>
            </CardFooter>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {saveSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute bottom-4 right-4 bg-green-100 text-green-800 px-4 py-2 rounded-md shadow-md flex items-center"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            {language === "english" ? "Profile updated successfully!" : "சுயவிவரம் வெற்றிகரமாக புதுப்பிக்கப்பட்டது!"}
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  )
}

