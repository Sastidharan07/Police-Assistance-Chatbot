"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Save,
  Loader2,
  CheckCircle,
  Moon,
  Sun,
  Monitor,
  Bell,
  Globe,
  Eye,
  Lock,
  HelpCircle,
  FileText,
  Shield,
  MapPin,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { getUserSettings, saveUserSettings, type UserSettings } from "@/lib/storage-service"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { PrivacyPolicy } from "@/components/privacy-policy"
import { TermsOfService } from "@/components/terms-of-service"
import { HelpSupportForm } from "@/components/help-support-form"

export function SettingsTab() {
  const { mobileNumber } = useAuth()
  const { language, setLanguage } = useLanguage()
  const { theme, setTheme } = useTheme()
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [settings, setSettings] = useState<UserSettings>({
    theme: "system",
    language: "english",
    notifications: {
      enabled: true,
      emergencyAlerts: true,
      complaintUpdates: true,
      newsUpdates: false,
    },
    accessibility: {
      fontSize: "medium",
      highContrast: false,
    },
    privacy: {
      shareLocation: true,
      saveHistory: true,
    },
  })

  // Load user settings when component mounts
  useEffect(() => {
    if (mobileNumber) {
      const userSettings = getUserSettings(mobileNumber)
      setSettings(userSettings)

      // Sync with theme and language contexts
      if (userSettings.theme) {
        setTheme(userSettings.theme)
      }

      if (userSettings.language) {
        setLanguage(userSettings.language)
      }
    }
  }, [mobileNumber, setTheme, setLanguage])

  // Reset success message after 3 seconds
  useEffect(() => {
    if (saveSuccess) {
      const timer = setTimeout(() => {
        setSaveSuccess(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [saveSuccess])

  const handleSave = async () => {
    if (!mobileNumber) return

    setIsSaving(true)

    try {
      // Save settings
      saveUserSettings(mobileNumber, settings)

      // Update theme and language
      setTheme(settings.theme)
      setLanguage(settings.language)

      // Show success message
      setSaveSuccess(true)
    } catch (error) {
      console.error("Error saving settings:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const updateSettings = (path: string, value: any) => {
    const pathParts = path.split(".")

    setSettings((prev) => {
      const newSettings = { ...prev }

      if (pathParts.length === 1) {
        // Top level setting
        return { ...newSettings, [path]: value }
      } else if (pathParts.length === 2) {
        // Nested setting
        const [category, setting] = pathParts
        return {
          ...newSettings,
          [category]: {
            ...newSettings[category as keyof UserSettings],
            [setting]: value,
          },
        }
      }

      return newSettings
    })
  }

  return (
    <Card className="w-full shadow-md">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl">{language === "english" ? "Settings" : "அமைப்புகள்"}</CardTitle>
        <CardDescription>
          {language === "english"
            ? "Customize your application preferences and settings"
            : "உங்கள் பயன்பாட்டு விருப்பங்கள் மற்றும் அமைப்புகளை தனிப்பயனாக்கவும்"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <Tabs defaultValue="appearance">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="appearance">{language === "english" ? "Appearance" : "தோற்றம்"}</TabsTrigger>
            <TabsTrigger value="notifications">{language === "english" ? "Notifications" : "அறிவிப்புகள்"}</TabsTrigger>
            <TabsTrigger value="privacy">{language === "english" ? "Privacy" : "தனியுரிமை"}</TabsTrigger>
            <TabsTrigger value="help">{language === "english" ? "Help" : "உதவி"}</TabsTrigger>
          </TabsList>

          <TabsContent value="appearance" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Sun className="h-4 w-4 mr-2" />
                    {language === "english" ? "Theme" : "தீம்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english" ? "Choose your preferred theme" : "உங்களுக்கு விருப்பமான தீம் தேர்வு செய்யவும்"}
                  </p>
                </div>
                <Select value={settings.theme} onValueChange={(value) => updateSettings("theme", value)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light" className="flex items-center">
                      <div className="flex items-center">
                        <Sun className="h-4 w-4 mr-2" />
                        {language === "english" ? "Light" : "வெளிச்சம்"}
                      </div>
                    </SelectItem>
                    <SelectItem value="dark">
                      <div className="flex items-center">
                        <Moon className="h-4 w-4 mr-2" />
                        {language === "english" ? "Dark" : "இருள்"}
                      </div>
                    </SelectItem>
                    <SelectItem value="system">
                      <div className="flex items-center">
                        <Monitor className="h-4 w-4 mr-2" />
                        {language === "english" ? "System" : "கணினி அமைப்பு"}
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Globe className="h-4 w-4 mr-2" />
                    {language === "english" ? "Language" : "மொழி"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Choose your preferred language"
                      : "உங்களுக்கு விருப்பமான மொழியைத் தேர்வு செய்யவும்"}
                  </p>
                </div>
                <Select value={settings.language} onValueChange={(value) => updateSettings("language", value)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="tamil">தமிழ்</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Eye className="h-4 w-4 mr-2" />
                    {language === "english" ? "Font Size" : "எழுத்து அளவு"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Adjust text size for better readability"
                      : "சிறந்த வாசிப்புத்திறனுக்கு உரை அளவைச் சரிசெய்யவும்"}
                  </p>
                </div>
                <Select
                  value={settings.accessibility.fontSize}
                  onValueChange={(value) => updateSettings("accessibility.fontSize", value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">{language === "english" ? "Small" : "சிறிய"}</SelectItem>
                    <SelectItem value="medium">{language === "english" ? "Medium" : "நடுத்தர"}</SelectItem>
                    <SelectItem value="large">{language === "english" ? "Large" : "பெரிய"}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Eye className="h-4 w-4 mr-2" />
                    {language === "english" ? "High Contrast" : "அதிக வேறுபாடு"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Increase contrast for better visibility"
                      : "சிறந்த தெளிவுத்திறனுக்கு வேறுபாட்டை அதிகரிக்கவும்"}
                  </p>
                </div>
                <Switch
                  checked={settings.accessibility.highContrast}
                  onCheckedChange={(checked) => updateSettings("accessibility.highContrast", checked)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Bell className="h-4 w-4 mr-2" />
                    {language === "english" ? "Enable Notifications" : "அறிவிப்புகளை இயக்கு"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Receive notifications from the application"
                      : "பயன்பாட்டிலிருந்து அறிவிப்புகளைப் பெறுங்கள்"}
                  </p>
                </div>
                <Switch
                  checked={settings.notifications.enabled}
                  onCheckedChange={(checked) => updateSettings("notifications.enabled", checked)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Bell className="h-4 w-4 mr-2" />
                    {language === "english" ? "Emergency Alerts" : "அவசர எச்சரிக்கைகள்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Receive notifications for emergency alerts"
                      : "அவசர எச்சரிக்கைகளுக்கான அறிவிப்புகளைப் பெறுங்கள்"}
                  </p>
                </div>
                <Switch
                  checked={settings.notifications.emergencyAlerts}
                  onCheckedChange={(checked) => updateSettings("notifications.emergencyAlerts", checked)}
                  disabled={!settings.notifications.enabled}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Bell className="h-4 w-4 mr-2" />
                    {language === "english" ? "Complaint Updates" : "புகார் புதுப்பிப்புகள்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Receive notifications for complaint status updates"
                      : "புகார் நிலை புதுப்பிப்புகளுக்கான அறிவிப்புகளைப் பெறுங்கள்"}
                  </p>
                </div>
                <Switch
                  checked={settings.notifications.complaintUpdates}
                  onCheckedChange={(checked) => updateSettings("notifications.complaintUpdates", checked)}
                  disabled={!settings.notifications.enabled}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Bell className="h-4 w-4 mr-2" />
                    {language === "english" ? "News Updates" : "செய்தி புதுப்பிப்புகள்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Receive notifications for police news and updates"
                      : "காவல்துறை செய்திகள் மற்றும் புதுப்பிப்புகளுக்கான அறிவிப்புகளைப் பெறுங்கள்"}
                  </p>
                </div>
                <Switch
                  checked={settings.notifications.newsUpdates}
                  onCheckedChange={(checked) => updateSettings("notifications.newsUpdates", checked)}
                  disabled={!settings.notifications.enabled}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    {language === "english" ? "Share Location" : "இருப்பிடத்தைப் பகிரவும்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Allow the app to access your location"
                      : "உங்கள் இருப்பிடத்தை அணுக பயன்பாட்டை அனுமதிக்கவும்"}
                  </p>
                </div>
                <Switch
                  checked={settings.privacy.shareLocation}
                  onCheckedChange={(checked) => updateSettings("privacy.shareLocation", checked)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Lock className="h-4 w-4 mr-2" />
                    {language === "english" ? "Save Chat History" : "அரட்டை வரலாற்றைச் சேமிக்கவும்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english"
                      ? "Save your chat conversations for future reference"
                      : "எதிர்கால குறிப்புக்காக உங்கள் அரட்டை உரையாடல்களைச் சேமிக்கவும்"}
                  </p>
                </div>
                <Switch
                  checked={settings.privacy.saveHistory}
                  onCheckedChange={(checked) => updateSettings("privacy.saveHistory", checked)}
                />
              </div>

              <Separator />

              <div className="p-4 bg-amber-50 rounded-md border border-amber-200">
                <h3 className="font-medium text-amber-800 flex items-center">
                  <Shield className="h-4 w-4 mr-2" />
                  {language === "english" ? "Data Privacy" : "தரவு தனியுரிமை"}
                </h3>
                <p className="text-sm text-amber-700 mt-1">
                  {language === "english"
                    ? "Your data is stored locally on your device and is not shared with third parties without your consent."
                    : "உங்கள் தரவு உங்கள் சாதனத்தில் உள்ளூரில் சேமிக்கப்படுகிறது மற்றும் உங்கள் ஒப்புதல் இல்லாமல் மூன்றாம் தரப்பினருடன் பகிரப்படாது."}
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4">
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-md border border-blue-200">
                <h3 className="font-medium text-blue-800 flex items-center">
                  <HelpCircle className="h-4 w-4 mr-2" />
                  {language === "english" ? "Help & Support" : "உதவி & ஆதரவு"}
                </h3>
                <p className="text-sm text-blue-700 mt-1">
                  {language === "english"
                    ? "For assistance with the application, please submit a support request using the form below."
                    : "பயன்பாட்டிற்கான உதவிக்கு, கீழே உள்ள படிவத்தைப் பயன்படுத்தி ஆதரவு கோரிக்கையைச் சமர்ப்பிக்கவும்."}
                </p>
                <div className="mt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="text-blue-600 border-blue-200 hover:bg-blue-100">
                        {language === "english" ? "Submit Support Request" : "ஆதரவு கோரிக்கையை சமர்ப்பிக்கவும்"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>
                          {language === "english" ? "Submit Support Request" : "ஆதரவு கோரிக்கையை சமர்ப்பிக்கவும்"}
                        </DialogTitle>
                        <DialogDescription>
                          {language === "english"
                            ? "Please provide details about your issue or question."
                            : "உங்கள் சிக்கல் அல்லது கேள்வி பற்றிய விவரங்களை வழங்கவும்."}
                        </DialogDescription>
                      </DialogHeader>
                      <HelpSupportForm />
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-md border">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <FileText className="h-4 w-4 mr-2" />
                    {language === "english" ? "Terms of Service" : "சேவை விதிமுறைகள்"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english" ? "Read our terms of service" : "எங்கள் சேவை விதிமுறைகளைப் படிக்கவும்"}
                  </p>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm">
                      {language === "english" ? "View" : "பார்வை"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[700px] max-h-[90vh]">
                    <DialogHeader>
                      <DialogTitle>{language === "english" ? "Terms of Service" : "சேவை விதிமுறைகள்"}</DialogTitle>
                    </DialogHeader>
                    <TermsOfService />
                    <DialogFooter>
                      <Button variant="outline" className="mt-4">
                        {language === "english" ? "Close" : "மூடு"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-md border">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <Lock className="h-4 w-4 mr-2" />
                    {language === "english" ? "Privacy Policy" : "தனியுரிமைக் கொள்கை"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english" ? "Read our privacy policy" : "எங்கள் தனியுரிமைக் கொள்கையைப் படிக்கவும்"}
                  </p>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm">
                      {language === "english" ? "View" : "பார்வை"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[700px] max-h-[90vh]">
                    <DialogHeader>
                      <DialogTitle>{language === "english" ? "Privacy Policy" : "தனியுரிமைக் கொள்கை"}</DialogTitle>
                    </DialogHeader>
                    <PrivacyPolicy />
                    <DialogFooter>
                      <Button variant="outline" className="mt-4">
                        {language === "english" ? "Close" : "மூடு"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="p-4 bg-gray-50 rounded-md border">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center">
                    <HelpCircle className="h-4 w-4 mr-2" />
                    {language === "english" ? "About" : "பற்றி"}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === "english" ? "Police Assistance Chatbot v1.0.0" : "காவல்துறை உதவி சாட்போட் v1.0.0"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {language === "english"
                      ? "© 2023 Tamil Nadu Police. All rights reserved."
                      : "© 2023 தமிழ்நாடு காவல்துறை. அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை."}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      <CardFooter className="border-t pt-4">
        <Button onClick={handleSave} disabled={isSaving} className="ml-auto">
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {language === "english" ? "Saving..." : "சேமிக்கிறது..."}
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              {language === "english" ? "Save Changes" : "மாற்றங்களைச் சேமிக்கவும்"}
            </>
          )}
        </Button>
      </CardFooter>

      <AnimatePresence>
        {saveSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute bottom-4 right-4 bg-green-100 text-green-800 px-4 py-2 rounded-md shadow-md flex items-center"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            {language === "english" ? "Settings saved successfully!" : "அமைப்புகள் வெற்றிகரமாக சேமிக்கப்பட்டன!"}
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  )
}

