"use client"

import { useState, useEffect, useRef } from "react"
import { AlertCircle, X, AlertTriangle, CheckCircle, MapPin, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useEmergencyAlert } from "@/lib/emergency-alert-context"
import { useLanguage } from "@/lib/language-context"
import { useLocation } from "@/lib/location-context"
import { cn } from "@/lib/utils"
import { getEmergencyContacts } from "@/lib/storage-service"
import { useAuth } from "@/lib/auth-context"

export function EmergencyAlertButton() {
  const [isConfirmOpen, setIsConfirmOpen] = useState(false)
  const { isAlertActive, isPending, sendAlert, cancelAlert, gracePeriodRemaining, nearestPoliceStation } =
    useEmergencyAlert()
  const { language } = useLanguage()
  const { location, formattedLocation } = useLocation()
  const { mobileNumber } = useAuth()
  const [emergencyContacts, setEmergencyContacts] = useState<any[]>([])
  const [pulseAnimation, setPulseAnimation] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [buttonPosition, setButtonPosition] = useState({ bottom: 6, right: 6 })
  const buttonRef = useRef<HTMLDivElement>(null)

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)

      // Adjust button position based on screen size
      if (window.innerWidth < 640) {
        setButtonPosition({ bottom: 20, right: 20 })
      } else {
        setButtonPosition({ bottom: 6, right: 6 })
      }
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  // Load emergency contacts
  useEffect(() => {
    if (mobileNumber) {
      const contacts = getEmergencyContacts(mobileNumber)
      setEmergencyContacts(contacts)
    }
  }, [mobileNumber])

  // Handle pulse animation for the danger button
  useEffect(() => {
    if (isAlertActive) {
      // Create pulsing effect
      const interval = setInterval(() => {
        setPulseAnimation((prev) => !prev)
      }, 1000)

      return () => clearInterval(interval)
    } else {
      setPulseAnimation(false)
    }
  }, [isAlertActive])

  // Check for button overlap with other elements
  useEffect(() => {
    const checkOverlap = () => {
      if (buttonRef.current) {
        const buttonRect = buttonRef.current.getBoundingClientRect()
        const footerElements = document.querySelectorAll('footer, [role="contentinfo"]')

        // Adjust position if overlapping with footer or other important elements
        footerElements.forEach((element) => {
          const elementRect = element.getBoundingClientRect()
          if (
            buttonRect.right > elementRect.left &&
            buttonRect.left < elementRect.right &&
            buttonRect.bottom > elementRect.top &&
            buttonRect.top < elementRect.bottom
          ) {
            // Move button above the overlapping element
            setButtonPosition((prev) => ({ ...prev, bottom: window.innerHeight - elementRect.top + 20 }))
          }
        })
      }
    }

    // Check for overlaps after render and on resize
    checkOverlap()
    window.addEventListener("resize", checkOverlap)
    return () => window.removeEventListener("resize", checkOverlap)
  }, [])

  const handleDangerClick = () => {
    // Add haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate(100)
    }
    setIsConfirmOpen(true)
  }

  const handleConfirm = async () => {
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 200])
    }
    await sendAlert()
    setIsConfirmOpen(false)
  }

  const handleCancel = () => {
    setIsConfirmOpen(false)
  }

  const handleCancelAlert = async () => {
    await cancelAlert()
  }

  return (
    <>
      {/* Floating Danger Button */}
      <div
        ref={buttonRef}
        className="fixed z-50 shadow-lg"
        style={{
          bottom: `${buttonPosition.bottom}px`,
          right: `${buttonPosition.right}px`,
          transition: "all 0.3s ease",
        }}
      >
        <Button
          variant="destructive"
          size="lg"
          className={cn(
            "rounded-full shadow-lg flex items-center justify-center",
            "active:scale-95 transition-transform duration-200",
            "touch-manipulation tap-highlight-transparent",
            isMobile ? "h-[60px] w-[60px]" : "h-16 w-16",
            isAlertActive && pulseAnimation && "animate-pulse bg-red-700 hover:bg-red-800",
            isAlertActive && "bg-red-700 hover:bg-red-800",
          )}
          onClick={handleDangerClick}
          disabled={isPending}
          aria-label={language === "english" ? "Emergency Alert" : "அவசர எச்சரிக்கை"}
        >
          <AlertCircle className={isMobile ? "h-7 w-7" : "h-8 w-8"} />
          <span className="sr-only">{language === "english" ? "Emergency Alert" : "அவசர எச்சரிக்கை"}</span>
        </Button>
      </div>

      {/* Confirmation Dialog - Mobile Optimized */}
      <Dialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <DialogContent className={cn("sm:max-w-md max-h-[90vh] overflow-y-auto", isMobile && "w-[95%] p-4 rounded-xl")}>
          <DialogHeader className={isMobile ? "space-y-2" : ""}>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 flex-shrink-0" />
              <span className="text-wrap">
                {language === "english" ? "Emergency Alert Confirmation" : "அவசர எச்சரிக்கை உறுதிப்படுத்தல்"}
              </span>
            </DialogTitle>
            <DialogDescription className={isMobile ? "text-sm" : ""}>
              {language === "english"
                ? "This will send an emergency alert with your current location to all your emergency contacts and nearby police stations."
                : "இது உங்கள் தற்போதைய இருப்பிடத்துடன் உங்கள் அனைத்து அவசர தொடர்புகளுக்கும் அருகிலுள்ள காவல் நிலையங்களுக்கும் ஒரு அவசர எச்சரிக்கையை அனுப்பும்."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col space-y-3 py-2">
            <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
              <p className={cn("text-yellow-800 font-medium", isMobile && "text-sm")}>
                {language === "english"
                  ? "Are you sure you want to send an emergency alert?"
                  : "நீங்கள் நிச்சயமாக ஒரு அவசர எச்சரிக்கையை அனுப்ப விரும்புகிறீர்களா?"}
              </p>
            </div>

            {/* Show current location */}
            {location && (
              <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                <h4
                  className={cn(
                    "font-medium text-gray-700 mb-1 flex items-center gap-1",
                    isMobile ? "text-xs" : "text-sm",
                  )}
                >
                  <MapPin className={isMobile ? "h-3 w-3" : "h-4 w-4"} />
                  {language === "english" ? "Your current location:" : "உங்கள் தற்போதைய இருப்பிடம்:"}
                </h4>
                <p className={isMobile ? "text-[10px] text-gray-600" : "text-xs text-gray-600"}>
                  {formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`}
                </p>
              </div>
            )}

            {/* Show emergency contacts */}
            {emergencyContacts.length > 0 ? (
              <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                <h4 className={cn("font-medium text-gray-700 mb-1", isMobile ? "text-xs" : "text-sm")}>
                  {language === "english" ? "Will alert these contacts:" : "இந்த தொடர்புகளை எச்சரிக்கும்:"}
                </h4>
                <ul className={cn("text-gray-600 space-y-1", isMobile ? "text-[10px]" : "text-xs")}>
                  {emergencyContacts.slice(0, 3).map((contact) => (
                    <li key={contact.id} className="flex items-center gap-1">
                      <Phone className={isMobile ? "h-2 w-2" : "h-3 w-3"} /> {contact.name}
                    </li>
                  ))}
                  {emergencyContacts.length > 3 && (
                    <li className={isMobile ? "text-[10px] text-gray-500" : "text-xs text-gray-500"}>
                      {language === "english"
                        ? `+${emergencyContacts.length - 3} more contacts`
                        : `+${emergencyContacts.length - 3} மேலும் தொடர்புகள்`}
                    </li>
                  )}
                </ul>
              </div>
            ) : (
              <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
                <p className={isMobile ? "text-[10px] text-yellow-800" : "text-xs text-yellow-800"}>
                  {language === "english"
                    ? "No emergency contacts found. The alert will only be sent to nearby police stations."
                    : "அவசர தொடர்புகள் எதுவும் இல்லை. எச்சரிக்கை அருகிலுள்ள காவல் நிலையங்களுக்கு மட்டுமே அனுப்பப்படும்."}
                </p>
              </div>
            )}
          </div>
          <DialogFooter className={cn("flex flex-row sm:justify-between gap-2", isMobile && "mt-2")}>
            <Button variant="outline" onClick={handleCancel} className={isMobile ? "text-sm py-1 px-3 h-9" : ""}>
              {language === "english" ? "Cancel" : "ரத்து செய்"}
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirm}
              className={cn("active:scale-95 transition-transform duration-200", isMobile && "text-sm py-1 px-3 h-9")}
            >
              {language === "english" ? "Send Alert" : "எச்சரிக்கையை அனுப்பு"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Active Alert Dialog - Mobile Optimized */}
      {(gracePeriodRemaining !== null || isAlertActive) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div
            className={cn(
              "bg-white rounded-lg overflow-hidden",
              isMobile ? "max-w-[95%] w-full mx-2" : "max-w-md w-full mx-4",
            )}
          >
            <div className={cn("p-4", isAlertActive ? "bg-red-600" : "bg-yellow-500")}>
              <h2 className="text-white font-bold flex items-center justify-between">
                <span className="flex items-center gap-2">
                  {isAlertActive ? (
                    <AlertCircle className={isMobile ? "h-5 w-5" : "h-6 w-6"} />
                  ) : (
                    <AlertTriangle className={isMobile ? "h-5 w-5" : "h-6 w-6"} />
                  )}
                  <span className={isMobile ? "text-lg" : "text-xl"}>
                    {language === "english" ? "Emergency Alert" : "அவசர எச்சரிக்கை"}
                  </span>
                </span>
                {!isAlertActive && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-white hover:bg-yellow-600 rounded-full"
                    onClick={handleCancelAlert}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">{language === "english" ? "Cancel" : "ரத்து செய்"}</span>
                  </Button>
                )}
              </h2>
            </div>

            <div className={cn("p-4", isMobile && "p-3")}>
              {gracePeriodRemaining !== null && gracePeriodRemaining > 0 ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className={cn("font-medium", isMobile && "text-sm")}>
                      {language === "english" ? "Alert will be sent in:" : "எச்சரிக்கை அனுப்பப்படும் நேரம்:"}
                    </p>
                    <p className={cn("font-bold text-red-600", isMobile ? "text-xl" : "text-2xl")}>
                      {gracePeriodRemaining}s
                    </p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                      className="bg-red-600 h-2.5 rounded-full transition-all duration-1000 ease-linear"
                      style={{ width: `${(gracePeriodRemaining / 10) * 100}%` }}
                    ></div>
                  </div>
                  <p className={cn("text-gray-500", isMobile ? "text-xs" : "text-sm")}>
                    {language === "english"
                      ? "You can cancel this alert before it's sent."
                      : "அனுப்புவதற்கு முன் இந்த எச்சரிக்கையை ரத்து செய்யலாம்."}
                  </p>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full active:scale-95 transition-transform duration-200",
                      isMobile && "text-sm py-1 h-9",
                    )}
                    onClick={handleCancelAlert}
                  >
                    {language === "english" ? "Cancel Alert" : "எச்சரிக்கையை ரத்து செய்"}
                  </Button>
                </div>
              ) : isAlertActive ? (
                <div className="space-y-3">
                  <div className="bg-red-50 p-3 rounded-md border border-red-200">
                    <p className={cn("text-red-800 font-medium flex items-center gap-2", isMobile && "text-sm")}>
                      <CheckCircle className={isMobile ? "h-4 w-4 text-green-600" : "h-5 w-5 text-green-600"} />
                      {language === "english"
                        ? "Your emergency alert has been sent. Help is on the way."
                        : "உங்கள் அவசர எச்சரிக்கை அனுப்பப்பட்டது. உதவி வருகிறது."}
                    </p>
                  </div>

                  {/* Location information */}
                  {location && (
                    <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                      <h4
                        className={cn(
                          "font-medium text-gray-700 mb-1 flex items-center gap-1",
                          isMobile ? "text-xs" : "text-sm",
                        )}
                      >
                        <MapPin className={isMobile ? "h-3 w-3" : "h-4 w-4"} />
                        {language === "english" ? "Your shared location:" : "பகிரப்பட்ட இருப்பிடம்:"}
                      </h4>
                      <p className={isMobile ? "text-[10px] text-gray-600" : "text-xs text-gray-600"}>
                        {formattedLocation || `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`}
                      </p>
                    </div>
                  )}

                  {/* Police station information */}
                  {nearestPoliceStation && (
                    <div className="bg-blue-50 p-3 rounded-md border border-blue-200">
                      <h4
                        className={cn(
                          "font-medium text-blue-700 mb-1 flex items-center gap-1",
                          isMobile ? "text-xs" : "text-sm",
                        )}
                      >
                        <Phone className={isMobile ? "h-3 w-3" : "h-4 w-4"} />
                        {language === "english" ? "Nearest Police Station:" : "அருகிலுள்ள காவல் நிலையம்:"}
                      </h4>
                      <p className={isMobile ? "text-[10px] text-blue-600" : "text-xs text-blue-600"}>
                        {nearestPoliceStation.name} ({nearestPoliceStation.distance})
                      </p>
                      <p className={cn("text-blue-600 mt-1", isMobile ? "text-[10px]" : "text-xs")}>
                        {language === "english" ? "Emergency Number:" : "அவசர எண்:"} {nearestPoliceStation.phone}
                      </p>
                    </div>
                  )}

                  <Button
                    variant="outline"
                    className={cn(
                      "w-full active:scale-95 transition-transform duration-200",
                      isMobile && "text-sm py-1 h-9",
                    )}
                    onClick={handleCancelAlert}
                  >
                    {language === "english" ? "Cancel Alert" : "எச்சரிக்கையை ரத்து செய்"}
                  </Button>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}
    </>
  )
}

