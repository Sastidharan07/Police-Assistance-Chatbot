"use client"

import type React from "react"

import { useState } from "react"
import { useLanguage } from "@/lib/language-context"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, CheckCircle, HelpCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function HelpSupportForm() {
  const { language } = useLanguage()
  const { mobileNumber, userProfile } = useAuth()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: userProfile?.username || "",
    email: userProfile?.email || "",
    issueType: "",
    description: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
    setSubmitError(null)
  }

  const handleIssueTypeChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      issueType: value,
    }))
    setSubmitError(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.name.trim()) {
      setSubmitError(language === "english" ? "Please enter your name" : "தயவுசெய்து உங்கள் பெயரை உள்ளிடவும்")
      return
    }

    if (!formData.email.trim() || !formData.email.includes("@")) {
      setSubmitError(
        language === "english" ? "Please enter a valid email address" : "தயவுசெய்து சரியான மின்னஞ்சல் முகவரியை உள்ளிடவும்",
      )
      return
    }

    if (!formData.issueType) {
      setSubmitError(
        language === "english" ? "Please select an issue type" : "தயவுசெய்து ஒரு சிக்கல் வகையைத் தேர்ந்தெடுக்கவும்",
      )
      return
    }

    if (!formData.description.trim() || formData.description.length < 10) {
      setSubmitError(
        language === "english"
          ? "Please provide a detailed description (at least 10 characters)"
          : "தயவுசெய்து விரிவான விளக்கத்தை வழங்கவும் (குறைந்தபட்சம் 10 எழுத்துகள்)",
      )
      return
    }

    setIsSubmitting(true)
    setSubmitError(null)

    try {
      // In a real application, this would send the data to a backend service
      // For this demo, we'll simulate a successful submission after a delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Simulate successful submission
      setSubmitSuccess(true)

      // Reset form after 3 seconds
      setTimeout(() => {
        setSubmitSuccess(false)
        setFormData({
          name: userProfile?.username || "",
          email: userProfile?.email || "",
          issueType: "",
          description: "",
        })
      }, 3000)
    } catch (error) {
      console.error("Error submitting help request:", error)
      setSubmitError(
        language === "english"
          ? "Failed to submit your request. Please try again later."
          : "உங்கள் கோரிக்கையைச் சமர்ப்பிக்க முடியவில்லை. தயவுசெய்து பின்னர் மீண்டும் முயற்சிக்கவும்.",
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">
          {language === "english" ? "Your Name" : "உங்கள் பெயர்"} <span className="text-red-500">*</span>
        </Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          placeholder={language === "english" ? "Enter your name" : "உங்கள் பெயரை உள்ளிடவும்"}
          disabled={isSubmitting || submitSuccess}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">
          {language === "english" ? "Email Address" : "மின்னஞ்சல் முகவரி"} <span className="text-red-500">*</span>
        </Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder={language === "english" ? "Enter your email" : "உங்கள் மின்னஞ்சலை உள்ளிடவும்"}
          disabled={isSubmitting || submitSuccess}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="issueType">
          {language === "english" ? "Issue Type" : "சிக்கல் வகை"} <span className="text-red-500">*</span>
        </Label>
        <Select
          value={formData.issueType}
          onValueChange={handleIssueTypeChange}
          disabled={isSubmitting || submitSuccess}
        >
          <SelectTrigger>
            <SelectValue placeholder={language === "english" ? "Select issue type" : "சிக்கல் வகையைத் தேர்ந்தெடுக்கவும்"} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="technical">{language === "english" ? "Technical Issue" : "தொழில்நுட்ப சிக்கல்"}</SelectItem>
            <SelectItem value="account">{language === "english" ? "Account Problem" : "கணக்கு சிக்கல்"}</SelectItem>
            <SelectItem value="feature">{language === "english" ? "Feature Request" : "அம்ச கோரிக்கை"}</SelectItem>
            <SelectItem value="complaint">{language === "english" ? "Complaint" : "புகார்"}</SelectItem>
            <SelectItem value="other">{language === "english" ? "Other" : "மற்றவை"}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">
          {language === "english" ? "Description" : "விளக்கம்"} <span className="text-red-500">*</span>
        </Label>
        <Textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          placeholder={
            language === "english" ? "Please describe your issue in detail" : "உங்கள் சிக்கலை விரிவாக விவரிக்கவும்"
          }
          rows={5}
          disabled={isSubmitting || submitSuccess}
        />
      </div>

      {submitError && (
        <Alert variant="destructive">
          <AlertDescription>{submitError}</AlertDescription>
        </Alert>
      )}

      {submitSuccess ? (
        <Alert variant="success" className="bg-green-50 border-green-200 text-green-800">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertDescription>
            {language === "english"
              ? "Your request has been submitted successfully. Our team will contact you soon."
              : "உங்கள் கோரிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. எங்கள் குழு விரைவில் உங்களைத் தொடர்பு கொள்ளும்."}
          </AlertDescription>
        </Alert>
      ) : (
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {language === "english" ? "Submitting..." : "சமர்ப்பிக்கிறது..."}
            </>
          ) : (
            <>
              <HelpCircle className="mr-2 h-4 w-4" />
              {language === "english" ? "Submit Request" : "கோரிக்கையை சமர்ப்பிக்கவும்"}
            </>
          )}
        </Button>
      )}

      <p className="text-xs text-muted-foreground text-center">
        {language === "english"
          ? "Our support team typically responds within 24-48 hours."
          : "எங்கள் ஆதரவு குழு பொதுவாக 24-48 மணிநேரத்திற்குள் பதிலளிக்கும்."}
      </p>
    </form>
  )
}

