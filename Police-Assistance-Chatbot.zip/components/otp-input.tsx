"use client"

import type React from "react"

import { useState, useRef, useEffect, type KeyboardEvent, type ClipboardEvent } from "react"
import { Input } from "@/components/ui/input"
import { motion } from "framer-motion"

interface OtpInputProps {
  value: string
  onChange: (value: string) => void
  length?: number
}

export function OtpInput({ value, onChange, length = 6 }: OtpInputProps) {
  const [otp, setOtp] = useState<string[]>(value.split("").concat(Array(length - value.length).fill("")))
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  // Initialize refs array
  useEffect(() => {
    inputRefs.current = inputRefs.current.slice(0, length)
  }, [length])

  // Update parent component when OTP changes
  useEffect(() => {
    onChange(otp.join(""))
  }, [otp, onChange])

  // Update local state when value prop changes
  useEffect(() => {
    if (value) {
      setOtp(value.split("").concat(Array(length - value.length).fill("")))
    }
  }, [value, length])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const newValue = e.target.value

    // Only accept digits
    if (!/^\d*$/.test(newValue)) return

    // Take only the last character if multiple characters are entered
    const digit = newValue.slice(-1)

    // Update the OTP array
    const newOtp = [...otp]
    newOtp[index] = digit
    setOtp(newOtp)

    // Move focus to next input if a digit was entered
    if (digit && index < length - 1) {
      inputRefs.current[index + 1]?.focus()
      setActiveIndex(index + 1)
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>, index: number) => {
    // Move focus to previous input on backspace if current input is empty
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const newOtp = [...otp]
      newOtp[index - 1] = ""
      setOtp(newOtp)
      inputRefs.current[index - 1]?.focus()
      setActiveIndex(index - 1)
    }

    // Move focus on arrow keys
    if (e.key === "ArrowLeft" && index > 0) {
      inputRefs.current[index - 1]?.focus()
      setActiveIndex(index - 1)
    }
    if (e.key === "ArrowRight" && index < length - 1) {
      inputRefs.current[index + 1]?.focus()
      setActiveIndex(index + 1)
    }
  }

  const handlePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault()
    const pastedData = e.clipboardData.getData("text/plain").trim()

    // Only accept digits
    if (!/^\d+$/.test(pastedData)) return

    // Fill the OTP array with pasted digits
    const newOtp = [...otp]
    for (let i = 0; i < Math.min(pastedData.length, length); i++) {
      newOtp[i] = pastedData[i]
    }
    setOtp(newOtp)

    // Focus the next empty input or the last input
    const nextEmptyIndex = newOtp.findIndex((digit) => !digit)
    if (nextEmptyIndex !== -1 && nextEmptyIndex < length) {
      inputRefs.current[nextEmptyIndex]?.focus()
      setActiveIndex(nextEmptyIndex)
    } else {
      inputRefs.current[length - 1]?.focus()
      setActiveIndex(length - 1)
    }
  }

  const handleFocus = (index: number) => {
    setActiveIndex(index)
  }

  const handleBlur = () => {
    setActiveIndex(null)
  }

  return (
    <div className="flex gap-2 justify-center">
      {Array.from({ length }).map((_, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          whileHover={{ scale: 1.05 }}
        >
          <Input
            ref={(el) => (inputRefs.current[index] = el)}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={otp[index] || ""}
            onChange={(e) => handleChange(e, index)}
            onKeyDown={(e) => handleKeyDown(e, index)}
            onPaste={handlePaste}
            onFocus={() => handleFocus(index)}
            onBlur={handleBlur}
            className={`w-12 h-12 text-center text-lg transition-all duration-300 
              ${otp[index] ? "border-primary bg-primary/5" : "border-input"} 
              ${activeIndex === index ? "ring-2 ring-primary/20 border-primary" : ""}
              focus:border-primary focus:ring-2 focus:ring-primary/20`}
            aria-label={`OTP digit ${index + 1}`}
          />
        </motion.div>
      ))}
    </div>
  )
}

