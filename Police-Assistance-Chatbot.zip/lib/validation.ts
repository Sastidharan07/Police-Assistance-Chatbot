export function validateMobile(mobile: string): boolean {
  // Check if mobile is exactly 10 digits and starts with 9, 8, 7, or 6 (valid Indian mobile numbers)
  return /^[9876]\d{9}$/.test(mobile)
}

export function validateOTP(otp: string): boolean {
  // Check if OTP is exactly 6 digits
  return /^\d{6}$/.test(otp)
}

