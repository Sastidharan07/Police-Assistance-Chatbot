import { getEmergencyContacts } from "./storage-service"

export interface AlertData {
  location: {
    latitude: number
    longitude: number
    formattedAddress?: string
  }
  message: string
  timestamp: string
  userId: string
  alertId: string
}

// Function to find the nearest police station (simulated)
const findNearestPoliceStation = async (
  latitude: number,
  longitude: number,
): Promise<{ name: string; distance: string; phone: string }> => {
  // In a real app, this would query a backend service or API
  // For demo purposes, we'll return a simulated result

  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return {
    name: "Central Police Station",
    distance: "2.3 km",
    phone: "100",
  }
}

// In a real application, this would connect to a backend service
// For demo purposes, we'll simulate the alert sending process
export const sendEmergencyAlert = async (
  mobileNumber: string,
  location: GeolocationCoordinates,
  formattedAddress?: string,
): Promise<{ success: boolean; alertId?: string; error?: string; policeStation?: any }> => {
  try {
    // Get emergency contacts
    const contacts = getEmergencyContacts(mobileNumber)

    if (contacts.length === 0) {
      console.warn("No emergency contacts found for user:", mobileNumber)
      // Continue anyway, as we'll still alert police
    }

    // Find nearest police station
    const nearestPoliceStation = await findNearestPoliceStation(location.latitude, location.longitude)

    // Generate a unique alert ID
    const alertId = `ALERT-${Date.now()}-${Math.floor(Math.random() * 1000)}`

    // Create alert data
    const alertData: AlertData = {
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        formattedAddress,
      },
      message: "EMERGENCY: I need immediate assistance. This is an emergency alert.",
      timestamp: new Date().toISOString(),
      userId: mobileNumber,
      alertId,
    }

    // In a real app, this would send the alert to a backend service
    // which would then notify emergency contacts and nearby police stations
    console.log("Sending emergency alert:", alertData)
    console.log("To contacts:", contacts)
    console.log("To police station:", nearestPoliceStation)

    // Simulate network communication
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Store alert in local storage for demo purposes
    if (typeof window !== "undefined") {
      const alerts = JSON.parse(localStorage.getItem("emergencyAlerts") || "[]")
      alerts.push({
        ...alertData,
        contacts,
        policeStation: nearestPoliceStation,
        status: "active",
      })
      localStorage.setItem("emergencyAlerts", JSON.stringify(alerts))
    }

    // Return success
    return {
      success: true,
      alertId,
      policeStation: nearestPoliceStation,
    }
  } catch (error) {
    console.error("Error sending emergency alert:", error)
    return {
      success: false,
      error: "Failed to send emergency alert. Please try again.",
    }
  }
}

// Function to cancel an alert that's been sent
export const cancelEmergencyAlert = async (alertId: string): Promise<boolean> => {
  try {
    // In a real app, this would cancel the alert on the backend
    console.log("Cancelling emergency alert:", alertId)

    // Update alert status in local storage
    if (typeof window !== "undefined") {
      const alerts = JSON.parse(localStorage.getItem("emergencyAlerts") || "[]")
      const updatedAlerts = alerts.map((alert: any) => {
        if (alert.alertId === alertId) {
          return { ...alert, status: "cancelled" }
        }
        return alert
      })
      localStorage.setItem("emergencyAlerts", JSON.stringify(updatedAlerts))
    }

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return true
  } catch (error) {
    console.error("Error cancelling emergency alert:", error)
    return false
  }
}

// Function to get alert status
export const getAlertStatus = (alertId: string): "active" | "cancelled" | "completed" | null => {
  if (typeof window === "undefined") return null

  const alerts = JSON.parse(localStorage.getItem("emergencyAlerts") || "[]")
  const alert = alerts.find((a: any) => a.alertId === alertId)

  return alert ? alert.status : null
}

