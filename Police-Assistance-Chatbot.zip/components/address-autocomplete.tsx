"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { MapPin, X } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { useLocation } from "@/lib/location-context"

interface AddressAutocompleteProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export function AddressAutocomplete({ value, onChange, placeholder }: AddressAutocompleteProps) {
  const [query, setQuery] = useState(value)
  const [suggestions, setSuggestions] = useState<Array<{ display_name: string }>>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const { language } = useLanguage()
  const { formattedLocation } = useLocation()
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null)

  // Update query when value changes externally
  useEffect(() => {
    setQuery(value)
  }, [value])

  // Search for address suggestions
  const searchAddress = async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 3) {
      setSuggestions([])
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          searchQuery + ", Tamil Nadu, India",
        )}&limit=5`,
      )
      const data = await response.json()
      setSuggestions(data)
    } catch (error) {
      console.error("Error searching for address:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Handle input change with debounce
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuery = e.target.value
    setQuery(newQuery)

    // Clear previous timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    // Set new timer
    debounceTimerRef.current = setTimeout(() => {
      searchAddress(newQuery)
    }, 500)

    setShowSuggestions(true)
  }

  // Select a suggestion
  const selectSuggestion = (suggestion: { display_name: string }) => {
    setQuery(suggestion.display_name)
    onChange(suggestion.display_name)
    setSuggestions([])
    setShowSuggestions(false)
  }

  // Use current location address
  const useCurrentLocationAddress = () => {
    if (formattedLocation) {
      setQuery(formattedLocation)
      onChange(formattedLocation)
    }
  }

  // Clear input
  const clearInput = () => {
    setQuery("")
    onChange("")
    setSuggestions([])
  }

  return (
    <div className="relative">
      <div className="flex">
        <div className="relative flex-1">
          <Input
            value={query}
            onChange={handleInputChange}
            placeholder={placeholder || (language === "english" ? "Enter address..." : "முகவரியை உள்ளிடவும்...")}
            className="pr-10"
            onFocus={() => query.length >= 3 && setShowSuggestions(true)}
            onBlur={() => {
              // Delay hiding suggestions to allow clicking on them
              setTimeout(() => setShowSuggestions(false), 200)
            }}
          />
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={clearInput}
              className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        {formattedLocation && (
          <Button
            type="button"
            variant="outline"
            onClick={useCurrentLocationAddress}
            className="ml-2 whitespace-nowrap"
          >
            <MapPin className="h-4 w-4 mr-2" />
            {language === "english" ? "Use Current" : "தற்போதைய பயன்படுத்து"}
          </Button>
        )}
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-sm max-h-60 overflow-y-auto">
          <ul className="divide-y">
            {suggestions.map((suggestion, index) => (
              <li
                key={index}
                className="p-2 hover:bg-gray-100 cursor-pointer text-sm"
                onClick={() => selectSuggestion(suggestion)}
              >
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-gray-500" />
                  <span>{suggestion.display_name}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

