"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/lib/language-context"
import { motion } from "framer-motion"

// Define the question categories and questions
const safetyQuestions = {
  reporting: {
    english: [
      "How do I file a police complaint in Tamil Nadu?",
      "What is the procedure to report a theft?",
      "How can I report a missing person?",
      "What documents are required to file an FIR?",
      "Can I file a complaint online in Tamil Nadu?",
    ],
    tamil: [
      "தமிழ்நாட்டில் காவல்துறை புகார் எப்படி அளிப்பது?",
      "திருட்டு குறித்து புகார் அளிக்க என்ன செய்ய வேண்டும்?",
      "காணாமல் போன நபரை எவ்வாறு புகார் செய்வது?",
      "FIR பதிவு செய்ய என்னென்ன ஆவணங்கள் தேவை?",
      "தமிழ்நாட்டில் ஆன்லைனில் புகார் அளிக்க முடியுமா?",
    ],
  },
  emergency: {
    english: [
      "What are the emergency numbers for Tamil Nadu Police?",
      "How to contact the nearest police station?",
      "What is the women's helpline number in Tamil Nadu?",
      "How to use the TN Police mobile app in an emergency?",
      "What should I do in case of a road accident?",
    ],
    tamil: [
      "தமிழ்நாடு காவல்துறையின் அவசர எண்கள் என்ன?",
      "அருகிலுள்ள காவல் நிலையத்தை எவ்வாறு தொடர்பு கொள்வது?",
      "தமிழ்நாட்டில் பெண்கள் உதவி எண் என்ன?",
      "அவசர நிலையில் TN Police மொபைல் ஆப்பை எவ்வாறு பயன்படுத்துவது?",
      "சாலை விபத்து ஏற்பட்டால் நான் என்ன செய்ய வேண்டும்?",
    ],
  },
  safety: {
    english: [
      "What safety measures should I take when traveling alone?",
      "How can I secure my home against break-ins?",
      "What precautions should I take to protect against online fraud?",
      "How to stay safe during public gatherings?",
      "What safety apps are recommended by Tamil Nadu Police?",
    ],
    tamil: [
      "தனியாக பயணம் செய்யும்போது நான் எடுக்க வேண்டிய பாதுகாப்பு நடவடிக்கைகள் என்ன?",
      "உடைப்புகளுக்கு எதிராக எனது வீட்டை எவ்வாறு பாதுகாப்பது?",
      "ஆன்லைன் மோசடியிலிருந்து பாதுகாக்க நான் எடுக்க வேண்டிய முன்னெச்சரிக்கைகள் என்ன?",
      "பொது கூட்டங்களின் போது பாதுகாப்பாக இருப்பது எப்படி?",
      "தமிழ்நாடு காவல்துறையால் பரிந்துரைக்கப்படும் பாதுகாப்பு ஆப்ஸ் எவை?",
    ],
  },
  services: {
    english: [
      "What services are offered by Tamil Nadu Police?",
      "How to get a police verification certificate?",
      "What is the procedure for obtaining a No Objection Certificate?",
      "How to apply for a police clearance certificate in Tamil Nadu?",
      "What community outreach programs are run by Tamil Nadu Police?",
    ],
    tamil: [
      "தமிழ்நாடு காவல்துறை வழங்கும் சேவைகள் என்னென்ன?",
      "காவல்துறை சரிபார்ப்பு சான்றிதழை எப்படி பெறுவது?",
      "ஆட்சேபனை இல்லா சான்றிதழ் பெறுவதற்கான நடைமுறை என்ன?",
      "தமிழ்நாட்டில் காவல்துறை அனுமதி சான்றிதழுக்கு எப்படி விண்ணப்பிப்பது?",
      "தமிழ்நாடு காவல்துறையால் நடத்தப்படும் சமூக விழிப்புணர்வு திட்டங்கள் என்னென்ன?",
    ],
  },
}

interface DefaultSafetyQuestionsProps {
  onQuestionSelect: (question: string) => void
}

export function DefaultSafetyQuestions({ onQuestionSelect }: DefaultSafetyQuestionsProps) {
  const { language, t } = useLanguage()
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("reporting")

  // Filter questions based on search query
  const filterQuestions = (questions: string[]) => {
    if (!searchQuery.trim()) return questions
    return questions.filter((q) => q.toLowerCase().includes(searchQuery.toLowerCase()))
  }

  // Get questions for the current language and filter them
  const getQuestionsForCategory = (category: string) => {
    const categoryQuestions = safetyQuestions[category as keyof typeof safetyQuestions][language]
    return filterQuestions(categoryQuestions)
  }

  // Handle question click
  const handleQuestionClick = (question: string) => {
    onQuestionSelect(question)
  }

  // Get category label
  const getCategoryLabel = (category: string) => {
    const labels = {
      reporting: language === "english" ? "Reporting" : "புகார் அளித்தல்",
      emergency: language === "english" ? "Emergency" : "அவசரம்",
      safety: language === "english" ? "Safety Tips" : "பாதுகாப்பு குறிப்புகள்",
      services: language === "english" ? "Services" : "சேவைகள்",
    }
    return labels[category as keyof typeof labels]
  }

  return (
    <Card className="w-full shadow-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold flex items-center">
          {language === "english" ? "Safety Questions" : "பாதுகாப்பு கேள்விகள்"}
        </CardTitle>
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={language === "english" ? "Search questions..." : "கேள்விகளைத் தேடுங்கள்..."}
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <Tabs defaultValue="reporting" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-2">
            <TabsTrigger value="reporting">{getCategoryLabel("reporting")}</TabsTrigger>
            <TabsTrigger value="emergency">{getCategoryLabel("emergency")}</TabsTrigger>
            <TabsTrigger value="safety">{getCategoryLabel("safety")}</TabsTrigger>
            <TabsTrigger value="services">{getCategoryLabel("services")}</TabsTrigger>
          </TabsList>

          {Object.keys(safetyQuestions).map((category) => (
            <TabsContent key={category} value={category} className="mt-0">
              <div className="space-y-2">
                {getQuestionsForCategory(category).length > 0 ? (
                  getQuestionsForCategory(category).map((question, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: index * 0.05 }}
                    >
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left h-auto py-2 px-3 font-normal hover:bg-primary/10 transition-colors"
                        onClick={() => handleQuestionClick(question)}
                      >
                        {question}
                      </Button>
                    </motion.div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-4">
                    {language === "english"
                      ? "No questions found. Try a different search term."
                      : "கேள்விகள் எதுவும் கிடைக்கவில்லை. வேறு தேடல் சொல்லை முயற்சிக்கவும்."}
                  </p>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}

