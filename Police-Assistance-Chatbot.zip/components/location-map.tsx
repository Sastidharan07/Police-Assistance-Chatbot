"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, MapPin, Locate } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { useLocation } from "@/lib/location-context"
import dynamic from "next/dynamic"

// Dynamically import Leaflet components with no SSR
const MapContainer = dynamic(() => import("react-leaflet").then((mod) => mod.MapContainer), { ssr: false })

const TileLayer = dynamic(() => import("react-leaflet").then((mod) => mod.TileLayer), { ssr: false })

const Marker = dynamic(() => import("react-leaflet").then((mod) => mod.Marker), { ssr: false })

// Custom map events component
const MapEvents = dynamic(() => import("./map-events").then((mod) => mod.MapEvents), { ssr: false })

interface LocationMapProps {
  onLocationSelected: (location: { lat: number; lng: number; address: string }) => void
  initialLocation?: { lat: number; lng: number }
}

export function LocationMap({ onLocationSelected, initialLocation }: LocationMapProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [markerPosition, setMarkerPosition] = useState<[number, number] | null>(
    initialLocation ? [initialLocation.lat, initialLocation.lng] : null,
  )
  const [address, setAddress] = useState("")
  const [mapCenter, setMapCenter] = useState<[number, number]>([13.0827, 80.2707]) // Chennai, Tamil Nadu
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<Array<{ display_name: string; lat: number; lon: number }>>([])
  const [isMapReady, setIsMapReady] = useState(false)
  const { language } = useLanguage()
  const { requestLocation } = useLocation()
  const mapRef = useRef(null)

  // Load Leaflet CSS on client-side only
  useEffect(() => {
    import("leaflet/dist/leaflet.css")
    setIsMapReady(true)
  }, [])

  // Reverse geocode to get address from coordinates
  const getAddressFromCoordinates = useCallback(
    async (lat: number, lng: number) => {
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
        )
        const data = await response.json()
        if (data && data.display_name) {
          setAddress(data.display_name)
          onLocationSelected({ lat, lng, address: data.display_name })
        }
      } catch (error) {
        console.error("Error getting address:", error)
        setAddress(`${lat.toFixed(6)}, ${lng.toFixed(6)}`)
        onLocationSelected({ lat, lng, address: `${lat.toFixed(6)}, ${lng.toFixed(6)}` })
      }
    },
    [onLocationSelected],
  )

  // Update marker position and get address
  const updateLocation = useCallback(
    (lat: number, lng: number) => {
      setMarkerPosition([lat, lng])
      getAddressFromCoordinates(lat, lng)
    },
    [getAddressFromCoordinates],
  )

  // Search for locations
  const searchLocation = async () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          searchQuery + ", Tamil Nadu, India",
        )}&limit=5`,
      )
      const data = await response.json()
      setSearchResults(data)
    } catch (error) {
      console.error("Error searching for location:", error)
    } finally {
      setIsSearching(false)
    }
  }

  // Use current location
  const useCurrentLocation = async () => {
    const coords = await requestLocation()
    if (coords) {
      updateLocation(coords.latitude, coords.longitude)
      setMapCenter([coords.latitude, coords.longitude])
    }
  }

  // Select a search result
  const selectSearchResult = (result: { lat: number; lon: number }) => {
    const lat = Number.parseFloat(result.lat)
    const lng = Number.parseFloat(result.lon)
    updateLocation(lat, lng)
    setMapCenter([lat, lng])
    setSearchResults([])
  }

  // Initialize with initial location if provided
  useEffect(() => {
    if (initialLocation) {
      updateLocation(initialLocation.lat, initialLocation.lng)
      setMapCenter([initialLocation.lat, initialLocation.lng])
    }
  }, [initialLocation, updateLocation])

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === "english" ? "Search for a location..." : "ஒரு இடத்தைத் தேடுங்கள்..."}
            className="pr-10"
            onKeyDown={(e) => e.key === "Enter" && searchLocation()}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={searchLocation}
            className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-600"
            disabled={isSearching}
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
        <Button type="button" variant="outline" onClick={useCurrentLocation}>
          <Locate className="h-4 w-4 mr-2" />
          {language === "english" ? "Current" : "தற்போதைய"}
        </Button>
      </div>

      {searchResults.length > 0 && (
        <div className="bg-white border rounded-md shadow-sm max-h-60 overflow-y-auto">
          <ul className="divide-y">
            {searchResults.map((result, index) => (
              <li
                key={index}
                className="p-2 hover:bg-gray-100 cursor-pointer text-sm"
                onClick={() => selectSearchResult(result)}
              >
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-gray-500" />
                  <span>{result.display_name}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="h-[300px] rounded-md overflow-hidden border">
        {isMapReady ? (
          <MapContainer
            center={mapCenter}
            zoom={13}
            style={{ height: "100%", width: "100%" }}
            scrollWheelZoom={false}
            ref={mapRef}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {markerPosition && (
              <Marker
                position={markerPosition}
                // We'll handle the icon in the MapEvents component
              />
            )}
            <MapEvents onLocationUpdate={updateLocation} />
          </MapContainer>
        ) : (
          <div className="h-full w-full flex items-center justify-center bg-gray-100">
            <p className="text-gray-500">Loading map...</p>
          </div>
        )}
      </div>

      {address && (
        <div className="p-3 bg-gray-50 border rounded-md text-sm">
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-gray-500" />
            <span>{address}</span>
          </div>
        </div>
      )}
    </div>
  )
}

