"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-context"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function LegalRights() {
  const { t, language } = useLanguage()
  const [searchQuery, setSearchQuery] = useState("")

  // Update the legalRights array with more detailed content
  const legalRights = [
    {
      id: "right1",
      title: {
        english: "Right to Information",
        tamil: "தகவல் அறியும் உரிமை",
      },
      content: {
        english:
          "Every citizen has the right to know the status of their complaint, FIR, or any police case they are involved in. Police officers must provide this information upon request. Under the Right to Information Act, 2005, citizens can file an RTI application to obtain information about their case if it is not provided willingly. The police department must respond within 30 days of receiving the RTI application. This right ensures transparency in the criminal justice system and holds law enforcement accountable to the public.",
        tamil:
          "ஒவ்வொரு குடிமகனும் தங்களது புகார், FIR அல்லது தாங்கள் சம்பந்தப்பட்ட எந்த காவல்துறை வழக்கின் நிலையையும் அறியும் உரிமை உண்டு. காவல் அதிகாரிகள் கோரிக்கையின் பேரில் இந்த தகவலை வழங்க வேண்டும். தகவல் அறியும் உரிமைச் சட்டம், 2005 இன் கீழ், தகவல் விருப்பத்துடன் வழங்கப்படவில்லை என்றால், குடிமக்கள் தங்கள் வழக்கைப் பற்றிய தகவல்களைப் பெற RTI விண்ணப்பத்தைத் தாக்கல் செய்யலாம். RTI விண்ணப்பத்தைப் பெற்ற 30 நாட்களுக்குள் காவல்துறை பதிலளிக்க வேண்டும். இந்த உரிமை குற்றவியல் நீதி அமைப்பில் வெளிப்படைத்தன்மையை உறுதி செய்கிறது மற்றும் சட்ட அமலாக்கத்தை பொதுமக்களுக்கு பொறுப்பாக்குகிறது.",
      },
    },
    {
      id: "right2",
      title: {
        english: "Right to Legal Representation",
        tamil: "சட்ட பிரதிநிதித்துவத்திற்கான உரிமை",
      },
      content: {
        english:
          "Every person has the right to consult and be defended by a legal practitioner of their choice. This right is guaranteed under Article 22(1) of the Constitution of India. If you cannot afford a lawyer, you are entitled to free legal aid under the Legal Services Authorities Act, 1987. The police must inform you of this right upon arrest. You have the right to meet your lawyer in private, and the police cannot be present during your consultation. Your lawyer can be present during police interrogation, though they cannot answer questions on your behalf. This right ensures that individuals have access to legal expertise and protection against potential abuses of power.",
        tamil:
          "ஒவ்வொரு நபருக்கும் தங்கள் விருப்பப்படி ஒரு சட்ட வல்லுநரை ஆலோசிக்கவும், அவரால் பாதுகாக்கப்படவும் உரிமை உண்டு. இந்த உரிமை இந்திய அரசியலமைப்பின் சரத்து 22(1) இன் கீழ் உத்தரவாதம் அளிக்கப்பட்டுள்ளது. நீங்கள் ஒரு வழக்கறிஞரை அணுக முடியாவிட்டால், சட்ட சேவைகள் ஆணையங்கள் சட்டம், 1987 இன் கீழ் இலவச சட்ட உதவி பெறும் உரிமை உங்களுக்கு உண்டு. கைது செய்யப்பட்டவுடன் காவல்துறையினர் இந்த உரிமையைப் பற்றி உங்களுக்குத் தெரிவிக்க வேண்டும். உங்கள் வழக்கறிஞரை தனிப்பட்ட முறையில் சந்திக்க உங்களுக்கு உரிமை உண்டு, மேலும் உங்கள் ஆலோசனையின் போது காவல்துறையினர் இருக்க முடியாது. காவல்துறை விசாரணையின் போது உங்கள் வழக்கறிஞர் இருக்கலாம், ஆனால் அவர்கள் உங்கள் சார்பாக கேள்விகளுக்கு பதிலளிக்க முடியாது. இந்த உரிமை தனிநபர்கள் சட்ட நிபுணத்துவத்தையும் அதிகார துஷ்பிரயோகங்களுக்கு எதிரான பாதுகாப்பையும் அணுகுவதை உறுதி செய்கிறது.",
      },
    },
    {
      id: "right3",
      title: {
        english: "Right to Fair Treatment",
        tamil: "நியாயமான நடத்தைக்கான உரிமை",
      },
      content: {
        english:
          "Every person has the right to be treated with dignity and respect by the police. No one should be subjected to torture, cruel, inhuman, or degrading treatment. This right is protected under Article 21 of the Constitution of India and various Supreme Court judgments. The police must follow guidelines set by the Supreme Court in D.K. Basu vs. State of West Bengal (1997) during arrest and detention. These include wearing clear identification, preparing an arrest memo, informing a friend or relative about the arrest, and allowing the arrested person to meet their lawyer during interrogation. Any confession made to police under duress is inadmissible in court. If you experience mistreatment, you can file a complaint with the State Human Rights Commission or approach the courts for redress.",
        tamil:
          "ஒவ்வொரு நபரும் காவல்துறையால் கண்ணியத்துடனும் மரியாதையுடனும் நடத்தப்படும் உரிமை உண்டு. யாரும் சித்ரவதை, கொடூரமான, மனிதாபிமானமற்ற அல்லது இழிவான நடத்தைக்கு உட்படுத்தப்படக்கூடாது. இந்த உரிமை இந்திய அரசியலமைப்பின் சரத்து 21 மற்றும் பல்வேறு உச்ச நீதிமன்ற தீர்ப்புகளின் கீழ் பாதுகாக்கப்படுகிறது. கைது மற்றும் தடுப்புக்காவலின் போது டி.கே. பாசு எதிர் மேற்கு வங்க மாநிலம் (1997) வழக்கில் உச்ச நீதிமன்றம் நிர்ணயித்த வழிகாட்டுதல்களை காவல்துறையினர் பின்பற்ற வேண்டும். இதில் தெளிவான அடையாளத்தை அணிவது, கைது குறிப்பை தயாரிப்பது, கைது பற்றி நண்பர் அல்லது உறவினருக்குத் தெரிவிப்பது மற்றும் விசாரணையின் போது கைது செய்யப்பட்ட நபர் தங்கள் வழக்கறிஞரை சந்திக்க அனுமதிப்பது ஆகியவை அடங்கும். காவல்துறையினரால் நிர்பந்தத்தின் கீழ் செய்யப்பட்ட எந்த ஒப்புதல் வாக்குமூலமும் நீதிமன்றத்தில் ஏற்றுக்கொள்ளப்படாது. நீங்கள் தவறான நடத்தையை அனுபவித்தால், மாநில மனித உரிமைகள் ஆணையத்தில் புகார் அளிக்கலாம் அல்லது தீர்வுக்காக நீதிமன்றங்களை அணுகலாம்.",
      },
    },
    {
      id: "right4",
      title: {
        english: "Right to Medical Examination",
        tamil: "மருத்துவ பரிசோதனைக்கான உரிமை",
      },
      content: {
        english:
          "If you are arrested or detained, you have the right to be medically examined by a qualified doctor every 48 hours during your detention. This right is established to ensure that no physical harm is caused to the arrested person while in police custody. The medical examination must be conducted by a trained medical officer and a proper report must be maintained. If you have any injuries at the time of arrest, these must be recorded in the medical report. You can request a medical examination if you feel unwell or have been subjected to any form of physical abuse during detention. This right serves as a safeguard against custodial violence and ensures the health and well-being of detained individuals.",
        tamil:
          "நீங்கள் கைது செய்யப்பட்டாலோ அல்லது தடுத்து வைக்கப்பட்டாலோ, உங்கள் தடுப்புக்காவலின் போது ஒவ்வொரு 48 மணி நேரத்திற்கும் ஒரு தகுதிவாய்ந்த மருத்துவரால் மருத்துவ பரிசோதனை செய்யப்படும் உரிமை உங்களுக்கு உண்டு. காவல் காவலில் இருக்கும்போது கைது செய்யப்பட்ட நபருக்கு உடல் ரீதியான தீங்கு ஏற்படாமல் இருப்பதை உறுதி செய்வதற்காக இந்த உரிமை நிறுவப்பட்டுள்ளது. மருத்துவ பரிசோதனை பயிற்சி பெற்ற மருத்துவ அதிகாரியால் நடத்தப்பட வேண்டும் மற்றும் சரியான அறிக்கை பராமரிக்கப்பட வேண்டும். கைது செய்யப்படும் போது உங்களுக்கு ஏதேனும் காயங்கள் இருந்தால், அவை மருத்துவ அறிக்கையில் பதிவு செய்யப்பட வேண்டும். நீங்கள் உடல்நிலை சரியில்லாமல் இருந்தாலோ அல்லது தடுப்புக்காவலின் போது ஏதேனும் உடல் ரீதியான துஷ்பிரயோகத்திற்கு உட்படுத்தப்பட்டிருந்தாலோ, நீங்கள் மருத்துவ பரிசோதனையைக் கோரலாம். இந்த உரிமை காவல் வன்முறைக்கு எதிரான பாதுகாப்பாக செயல���படுகிறது மற்றும் தடுத்து வைக்கப்பட்ட தனிநபர்களின் ஆரோக்கியம் மற்றும் நல்வாழ்வை உறுதி செய்கிறது.",
      },
    },
    {
      id: "right5",
      title: {
        english: "Right to Speedy Trial",
        tamil: "விரைவான விசாரணைக்கான உரிமை",
      },
      content: {
        english:
          "Every person has the right to a speedy trial, which is an essential part of the 'right to life and personal liberty' under Article 21 of the Constitution. Unnecessary delay in trial proceedings violates this fundamental right. The Criminal Procedure Code provides time limits for various stages of investigation and trial. If your case is pending for an unreasonable period, you can file an application in court requesting expedited proceedings. In certain cases, prolonged delay can even be grounds for bail or acquittal. The Supreme Court has emphasized in numerous judgments that justice delayed is justice denied, and has directed courts to prioritize cases that have been pending for extended periods.",
        tamil:
          "ஒவ்வொரு நபருக்கும் விரைவான விசாரணைக்கான உரிமை உண்டு, இது அரசியலமைப்பின் சரத்து 21 இன் கீழ் 'வாழ்க்கை மற்றும் தனிப்பட்ட சுதந்திரத்திற்கான உரிமையின்' அத்தியாவசிய பகுதியாகும். விசாரணை நடவடிக்கைகளில் தேவையற்ற தாமதம் இந்த அடிப்படை உரிமையை மீறுகிறது. விசாரணை மற்றும் விசாரணையின் பல்வேறு கட்டங்களுக்கு குற்றவியல் நடைமுறை குறியீடு கால வரம்புகளை வழங்குகிறது. உங்கள் வழக்கு நியாயமற்ற காலத்திற்கு நிலுவையில் இருந்தால், துரிதப்படுத்தப்பட்ட நடவடிக்கைகளைக் கோரி நீதிமன்றத்தில் விண்ணப்பத்தைத் தாக்கல் செய்யலாம். சில வழக்குகளில், நீண்ட கால தாமதம் ஜாமீன் அல்லது விடுவிப்புக்கான காரணங்களாகவும் இருக்கலாம். தாமதமான நீதி என்பது நீதி மறுக்கப்படுவதாகும் என்பதை உச்ச நீதிமன்றம் பல தீர்ப்புகளில் வலியுறுத்தியுள்ளது, மேலும் நீண்ட காலமாக நிலுவையில் உள்ள வழக்குகளுக்கு முன்னுரிமை அளிக்க நீதிமன்றங்களுக்கு உத்தரவிட்டுள்ளது.",
      },
    },
    {
      id: "right6",
      title: {
        english: "Right to Compensation",
        tamil: "இழப்பீட்டுக்கான உரிமை",
      },
      content: {
        english:
          "Victims of police misconduct, wrongful detention, or human rights violations have the right to seek compensation. The Supreme Court has established this right through various judgments. If you have suffered physical, mental, or financial harm due to unlawful police action, you can file a writ petition in the High Court or Supreme Court under Article 32 or 226 of the Constitution. You can also file a civil suit for damages. In cases of custodial death or torture, the National Human Rights Commission can recommend compensation to the victim or their family. The courts have awarded substantial compensation in numerous cases of police excesses, establishing that the state is vicariously liable for the actions of its officers.",
        tamil:
          "காவல்துறை தவறான நடத்தை, தவறான தடுப்பு அல்லது மனித உரிமை மீறல்களால் பாதிக்கப்பட்டவர்களுக்கு இழப்பீடு கோரும் உரிமை உண்டு. பல்வேறு தீர்ப்புகள் மூலம் உச்ச நீதிமன்றம் இந்த உரிமையை நிறுவியுள்ளது. சட்டவிரோதமான காவல்துறை நடவடிக்கையால் நீங்கள் உடல், மன அல்லது நிதி ரீதியான தீங்கு அடைந்திருந்தால், அரசியலமைப்பின் சரத்து 32 அல்லது 226 இன் கீழ் உயர் நீதிமன்றம் அல்லது உச்ச நீதிமன்றத்தில் ரிட் மனுவைத் தாக்கல் செய்யலாம். நீங்கள் சேதங்களுக்கான சிவில் வழக்கையும் தாக்கல் செய்யலாம். காவல் மரணம் அல்லது சித்ரவதை வழக்குகளில், தேசிய மனித உரிமைகள் ஆணையம் பாதிக்கப்பட்டவருக்கு அல்லது அவரது குடும்பத்தினருக்கு இழப்பீடு பரிந்துரைக்கலாம். காவல்துறை அத்துமீறல்களின் பல வழக்குகளில் நீதிமன்றங்கள் கணிசமான இழப்பீடு வழங்கியுள்ளன, அரசு தனது அதிகாரிகளின் செயல்களுக்கு மாற்றாக பொறுப்பாகும் என்பதை நிறுவியுள்ளன.",
      },
    },
    {
      id: "right7",
      title: {
        english: "Right to Privacy",
        tamil: "தனியுரிமைக்கான உரிமை",
      },
      content: {
        english:
          "The right to privacy is a fundamental right recognized by the Supreme Court of India in Justice K.S. Puttaswamy vs. Union of India (2017). This right extends to interactions with law enforcement. Police cannot conduct surveillance, phone tapping, or monitoring of your communications without proper legal authorization. Your personal information collected during investigations must be handled confidentially and used only for legitimate law enforcement purposes. Women and minors have additional privacy protections during police procedures. If you believe your privacy has been violated by police actions, you can seek judicial remedies through the courts.",
        tamil:
          "தனியுரிமை உரிமை என்பது நீதிபதி கே.எஸ். புட்டசாமி எதிர் இந்திய யூனியன் (2017) வழக்கில் இந்திய உச்ச நீதிமன்றத்தால் அங்கீகரிக்கப்பட்ட ஒரு அடிப்படை உரிமையாகும். இந்த உரிமை சட்ட அமலாக்கத்துடனான தொடர்புகளுக்கும் நீட்டிக்கப்படுகிறது. சரியான சட்ட அங்கீகாரம் இல்லாமல் காவல்துறையினர் கண்காணிப்பு, தொலைபேசி தட்டுதல் அல்லது உங்கள் தகவல்தொடர்புகளைக் கண்காணிக்க முடியாது. விசாரணைகளின் போது சேகரிக்கப்பட்ட உங்கள் தனிப்பட்ட தகவல்கள் இரகசியமாக கையாளப்பட வேண்டும் மற்றும் சட்டபூர்வமான சட்ட அமலாக்க நோக்கங்களுக்கு மட்டுமே பயன்படுத்தப்பட வேண்டும். காவல்துறை நடைமுறைகளின் போது பெண்கள் மற்றும் சிறார்களுக்கு கூடுதல் தனியுரிமை பாதுகாப்புகள் உள்ளன. காவல்துறை நடவடிக்கைகளால் உங்கள் தனியுரிமை மீறப்பட்டதாக நீங்கள் நம்பினால், நீதிமன்றங்கள் மூலம் நீதித்துறை தீர்வுகளை நாடலாம்.",
      },
    },
  ]

  // Update the legalArticles array with more detailed content
  const legalArticles = [
    {
      id: "article1",
      title: {
        english: "Section 154 CrPC - Filing of FIR",
        tamil: "பிரிவு 154 CrPC - FIR தாக்கல்",
      },
      content: {
        english:
          "Every information relating to the commission of a cognizable offense, if given orally to an officer in charge of a police station, shall be reduced to writing by him or under his direction and be read over to the informant. Every such information shall be signed by the person giving it. The FIR is a crucial document that sets the criminal law in motion. The police are legally bound to register an FIR for a cognizable offense. If the police refuse to register an FIR, you can approach the Superintendent of Police or the Judicial Magistrate with your complaint under Section 156(3) CrPC. You can also file a complaint online through the CCTNS (Crime and Criminal Tracking Network & Systems) portal.",
        tamil:
          "ஒரு காவல் நிலையத்தின் பொறுப்பில் உள்ள அதிகாரிக்கு வாய்மொழியாக வழங்கப்பட்டால், ஒரு அறியக்கூடிய குற்றத்தின் புகாரை அவரால் அல்லது அவரது இயக்கத்தின் கீழ் எழுத்துப்பூர்வமாக குறைக்கப்பட்டு, தகவல் அளிப்பவருக்கு வாசிக்கப்படும். அத்தகைய ஒவ்வொரு தகவலும் அதை வழங்கும் நபரால் கையொப்பமிடப்பட வேண்டும். FIR என்பது குற்றவியல் சட்டத்தை இயக்கும் ஒரு முக்கியமான ஆவணமாகும். அறியக்கூடிய குற்றத்திற்கு FIR ஐ பதிவு செய்ய காவல்துறை சட்டப்பூர்வமாக கட்டுப்பட்டுள்ளது. காவல்துறையினர் FIR ஐப் பதிவு செய்ய மறுத்தால், நீங்கள் CrPC பிரிவு 156(3) இன் கீழ் உங்கள் புகாருடன் காவல் கண்காணிப்பாளர் அல்லது நீதித்துறை நடுவரை அணுகலாம். CCTNS (குற்றம் மற்றும் குற்றவியல் கண்காணிப்பு நெட்வொர்க் & சிஸ்டம்ஸ்) போர்டல் மூலம் ஆன்லைனில் புகார் அளிக்கலாம்.",
      },
    },
    {
      id: "article2",
      title: {
        english: "Section 41 CrPC - When Police May Arrest Without Warrant",
        tamil: "பிரிவு 41 CrPC - காவல்துறை வாரண்ட் இல்லாமல் கைது செய்யலாம்",
      },
      content: {
        english:
          "Any police officer may, without an order from a Magistrate and without a warrant, arrest any person who has been concerned in any cognizable offense or against whom a reasonable complaint has been made, or credible information has been received, or a reasonable suspicion exists of his having been so concerned. However, the police must have a reasonable satisfaction about the necessity of arrest based on proper investigation. As per the Supreme Court guidelines in Arnesh Kumar vs. State of Bihar (2014), the police should not automatically arrest in cases where the offense is punishable with imprisonment for a term of seven years or less. The police officer must record in writing the reasons for making or not making an arrest.",
        tamil:
          "எந்தவொரு காவல் அதிகாரியும், நீதிபதியின் உத்தரவு இல்லாமலும், வாரண்ட் இல்லாமலும், ஏதேனும் அறியக்கூடிய குற்றத்தில் சம்பந்தப்பட்ட எந்தவொரு நபரையும் அல்லது அவருக்கு எதிராக நியாயமான புகார் செய்யப்பட்டிருந்தால், அல்லது நம்பகமான தகவல் பெறப்பட்டிருந்தால், அல்லது அவர் அவ்வாறு சம்பந்தப்பட்டிருப்பதாக நியாயமான சந்தேகம் இருந்தால் கைது செய்யலாம். இருப்பினும், சரியான விசாரணையின் அடிப்படையில் கைது செய்வதன் அவசியத்தைப் பற்றி காவல்துறையினருக்கு நியாயமான திருப்தி இருக்க வேண்டும். அர்னேஷ் குமார் எதிர் பீகார் மாநிலம் (2014) வழக்கில் உச்ச நீதிமன்றம் வழிகாட்டுதல்களின்படி, ஏழு ஆண்டுகள் அல்லது அதற்கும் குறைவான காலத்திற்கு சிறைத்தண்டனை விதிக்கக்கூடிய குற்றங்களில் காவல்துறை தானாக முன்வந்து கைது செய்யக்கூடாது. கைது செய்வதற்கான காரணங்களை காவல் அதிகாரி எழுத்துப்பூர்வமாக பதிவு செய்ய வேண்டும்.",
      },
    },
    {
      id: "article3",
      title: {
        english: "Section 46 CrPC - How Arrests Are to Be Made",
        tamil: "பிரிவு 46 CrPC - கைதுகள் எவ்வாறு செய்யப்பட வேண்டும்",
      },
      content: {
        english:
          "In making an arrest, the police officer shall actually touch or confine the body of the person to be arrested, unless there is a submission to custody by word or action. If such person forcibly resists or attempts to evade arrest, the police officer may use all means necessary to effect the arrest. The police must inform the arrested person about the grounds for arrest and their right to bail. The arrested person should not be subjected to unnecessary force or restraint. As per Section 50 CrPC, the police officer making the arrest must inform the arrested person of their right to inform a relative or friend about their arrest. These provisions aim to ensure that arrests are made in a fair and transparent manner, and that the rights of the arrested person are protected.",
        tamil:
          "ஒரு கைது செய்வதில், வார்த்தை அல்லது செயலால் காவலில் ஒப்படைக்கப்படாவிட்டால், காவல் அதிகாரி கைது செய்யப்பட வேண்டிய நபரின் உடலை உண்மையில் தொட்டு அல்லது கட்டுப்படுத்த வேண்டும். அத்தகைய நபர் வலுக்கட்டாயமாக எதிர்த்தால் அல்லது கைது செய்வதைத் தவிர்க்க முயற்சித்தால், காவல் அதிகாரி கைது செய்வதற்கு அனைத்து வழிகளையும் பயன்படுத்தலாம். கைது செய்யப்பட்ட நபருக்கு கைதுக்கான காரணங்கள் மற்றும் ஜாமீன் பெறும் உரிமை குறித்து காவல்துறை தெரிவிக்க வேண்டும். கைது செய்யப்பட்ட நபர் தேவையற்ற சக்தி அல்லது கட்டுப்பாட்டுக்கு உட்படுத்தப்படக்கூடாது. CrPC பிரிவு 50 இன் படி, கைது செய்யும் காவல் அதிகாரி கைது செய்யப்பட்ட நபருக்கு அவர்களின் கைது பற்றி உறவினர் அல்லது நண்பருக்குத் தெரிவிக்க உரிமை உண்டு என்பதைத் தெரிவிக்க வேண்டும். கைதுகள் நியாயமான மற்றும் வெளிப்படையான முறையில் செய்யப்படுவதையும், கைது செய்யப்பட்ட நபரின் உரிமைகள் பாதுகாக்கப்படுவதையும் இந்த விதிகள் நோக்கமாகக் கொண்டுள்ளன.",
      },
    },
    {
      id: "article4",
      title: {
        english: "Section 160 CrPC - Police Officer's Power to Require Attendance of Witnesses",
        tamil: "பிரிவு 160 CrPC - சாட்சிகளின் வருகையைக் கோரும் காவல் அதிகாரியின் அதிகாரம்",
      },
      content: {
        english:
          "Any police officer making an investigation may, by order in writing, require the attendance before himself of any person who appears to be acquainted with the facts and circumstances of the case. However, the police cannot compel the attendance of a male person under the age of fifteen years or a woman at any place other than their residence. The witness is legally bound to answer all questions put to them by the police officer, except those which would expose them to a criminal charge, penalty, or forfeiture. The police officer must record the statements of the witnesses accurately and fairly. Witnesses have the right to be treated with respect and dignity during the investigation process.",
        tamil:
          "விசாரணை செய்யும் எந்தவொரு காவல் அதிகாரியும், எழுத்துப்பூர்வமான உத்தரவின் மூலம், வழக்கின் உண்மைகள் மற்றும் சூழ்நிலைகளை அறிந்திருப்பதாகத் தெரியும் எந்தவொரு நபரின் வருகையையும் தனக்கு முன்பாக கோரலாம். இருப்பினும், பதினைந்து வயதுக்குட்பட்ட ஆண் நபர் அல்லது ஒரு பெண்ணின் வருகையை அவர்களின் இல்லத்தைத் தவிர வேறு எந்த இடத்திலும் காவல்துறை கட்டாயப்படுத்த முடியாது. சாட்சி சட்டப்பூர்வமாக காவல் அதிகாரியால் கேட்கப்படும் அனைத்து கேள்விகளுக்கும் பதிலளிக்க கடமைப்பட்டிருக்கிறார், அவை அவர்களை குற்றவியல் குற்றச்சாட்டு, அபராதம் அல்லது பறிமுதல் செய்வதற்கு வெளிப்படுத்தும் கேள்விகளைத் தவிர. காவல் அதிகாரி சாட்சிகளின் வாக்குமூலங்களை துல்லியமாகவும் நியாயமாகவும் பதிவு செய்ய வேண்டும். விசாரணை நடவடிக்கையின் போது சாட்சிகளுக்கு மரியாதை மற்றும் கண்ணியத்துடன் நடத்தப்படும் உரிமை உண்டு.",
      },
    },
  ]

  // Filter based on search query
  const filteredRights = legalRights.filter(
    (right) =>
      right.title[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
      right.content[language].toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredArticles = legalArticles.filter(
    (article) =>
      article.title[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.content[language].toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t("legal.title")}</CardTitle>
        <div className="relative mt-2">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t("legal.search")}
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="rights" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="rights">{t("legal.rights")}</TabsTrigger>
            <TabsTrigger value="articles">{t("legal.articles")}</TabsTrigger>
          </TabsList>
          <TabsContent value="rights" className="mt-4">
            {filteredRights.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">{t("legal.noResults")}</div>
            ) : (
              <Accordion type="single" collapsible className="w-full">
                {filteredRights.map((right) => (
                  <AccordionItem key={right.id} value={right.id}>
                    <AccordionTrigger>{right.title[language]}</AccordionTrigger>
                    <AccordionContent>{right.content[language]}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </TabsContent>
          <TabsContent value="articles" className="mt-4">
            {filteredArticles.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">{t("legal.noResults")}</div>
            ) : (
              <Accordion type="single" collapsible className="w-full">
                {filteredArticles.map((article) => (
                  <AccordionItem key={article.id} value={article.id}>
                    <AccordionTrigger>{article.title[language]}</AccordionTrigger>
                    <AccordionContent>{article.content[language]}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

