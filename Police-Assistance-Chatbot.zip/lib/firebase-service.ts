import { initializeApp } from "firebase/app"
import { getAuth, signInWithPhoneNumber, RecaptchaVerifier } from "firebase/auth"

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDummyKeyForPoliceAssistanceChatbot",
  authDomain: "police-assistance-chatbot.firebaseapp.com",
  projectId: "police-assistance-chatbot",
  storageBucket: "police-assistance-chatbot.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890abcdef",
}

// Initialize Firebase
let app
let auth
let recaptchaVerifier

// Initialize Firebase only on client side
if (typeof window !== "undefined") {
  try {
    app = initializeApp(firebaseConfig)
    auth = getAuth(app)
  } catch (error) {
    console.error("Firebase initialization error:", error)
  }
}

// Function to initialize recaptcha verifier
export function initRecaptchaVerifier(containerId: string) {
  if (typeof window === "undefined" || !auth) return null

  try {
    recaptchaVerifier = new RecaptchaVerifier(auth, containerId, {
      size: "invisible",
      callback: () => {
        // reCAPTCHA solved, allow signInWithPhoneNumber.
      },
    })
    return recaptchaVerifier
  } catch (error) {
    console.error("Recaptcha initialization error:", error)
    return null
  }
}

// Function to send OTP to phone number
export async function sendOTP(phoneNumber: string) {
  if (typeof window === "undefined" || !auth || !recaptchaVerifier) {
    console.error("Auth or recaptchaVerifier not initialized")
    return { success: false, error: "Authentication not initialized" }
  }

  try {
    // Format phone number with country code
    const formattedPhoneNumber = `+91${phoneNumber}`

    // Send OTP
    const confirmationResult = await signInWithPhoneNumber(auth, formattedPhoneNumber, recaptchaVerifier)

    // Store the confirmation result for later verification
    window.confirmationResult = confirmationResult

    return { success: true }
  } catch (error) {
    console.error("Error sending OTP:", error)

    // Reset recaptcha
    if (recaptchaVerifier) {
      recaptchaVerifier.clear()
      recaptchaVerifier = null
    }

    return { success: false, error: error.message }
  }
}

// Function to verify OTP
export async function verifyOTP(otp: string) {
  if (typeof window === "undefined" || !window.confirmationResult) {
    return { success: false, error: "Confirmation result not found" }
  }

  try {
    const result = await window.confirmationResult.confirm(otp)
    // User signed in successfully
    return { success: true, user: result.user }
  } catch (error) {
    console.error("Error verifying OTP:", error)
    return { success: false, error: error.message }
  }
}

// Function to manually verify OTP (for testing/debugging)
export async function manualVerifyOTP(phoneNumber: string, otp: string) {
  // For testing purposes, we'll consider "123456" as a valid OTP for any number
  if (otp === "123456") {
    return { success: true, user: { phoneNumber: `+91${phoneNumber}` } }
  }

  return { success: false, error: "Invalid OTP" }
}

// Function to sign out
export async function signOut() {
  if (typeof window === "undefined" || !auth) return { success: false }

  try {
    await auth.signOut()
    return { success: true }
  } catch (error) {
    console.error("Error signing out:", error)
    return { success: false, error: error.message }
  }
}

