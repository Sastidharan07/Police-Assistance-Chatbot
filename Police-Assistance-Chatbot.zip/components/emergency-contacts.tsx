"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { AlertCircle, Plus, Trash2, Phone, MessageSquare, X } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useLanguage } from "@/lib/language-context"
import { useAuth } from "@/lib/auth-context"
import {
  type EmergencyContact,
  getEmergencyContacts,
  saveEmergencyContact,
  deleteEmergencyContact,
} from "@/lib/storage-service"
import { motion, AnimatePresence } from "framer-motion"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { validateMobile } from "@/lib/validation"

export function EmergencyContacts() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([])
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [error, setError] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [showCallingAnimation, setShowCallingAnimation] = useState<string | null>(null)
  const [shakeName, setShakeName] = useState(false)
  const [shakePhone, setShakePhone] = useState(false)
  const { t, language } = useLanguage()
  const { mobileNumber } = useAuth()

  // Tamil Nadu emergency services
  const emergencyServices = [
    { name: "Police Emergency", phone: "100" },
    { name: "Ambulance", phone: "108" },
    { name: "Fire Service", phone: "101" },
    { name: "Women Helpline", phone: "1091" },
    { name: "Child Helpline", phone: "1098" },
    { name: "Disaster Management", phone: "1077" },
    { name: "Anti-Corruption", phone: "1064" },
    { name: "Traffic Police", phone: "103" },
  ]

  useEffect(() => {
    if (mobileNumber) {
      setContacts(getEmergencyContacts(mobileNumber))
    }
  }, [mobileNumber])

  // Reset shake animations after they complete
  useEffect(() => {
    if (shakeName) {
      const timer = setTimeout(() => {
        setShakeName(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [shakeName])

  useEffect(() => {
    if (shakePhone) {
      const timer = setTimeout(() => {
        setShakePhone(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [shakePhone])

  const handleAddContact = () => {
    if (!mobileNumber) return

    if (!name.trim()) {
      setError(language === "english" ? "Please enter a name" : "தயவுசெய்து ஒரு பெயரை உள்ளிடவும்")
      setShakeName(true)
      return
    }

    if (!phone.trim()) {
      setError(language === "english" ? "Please enter a phone number" : "தயவுசெய்து ஒரு தொலைபேசி எண்ணை உள்ளிடவும்")
      setShakePhone(true)
      return
    }

    if (!validateMobile(phone)) {
      setError(
        language === "english"
          ? "Please enter a valid 10-digit Indian mobile number"
          : "தயவுசெய்து சரியான 10-இலக்க இந்திய மொபைல் எண்ணை உள்ளிடவும்",
      )
      setShakePhone(true)
      return
    }

    const result = saveEmergencyContact(mobileNumber, { name, phone })

    if (!result) {
      setError(
        language === "english"
          ? "Could not add contact. You may have reached the limit of 5 contacts or this number is already saved."
          : "தொடர்பைச் சேர்க்க முடியவில்லை. நீங்கள் 5 தொடர்புகளின் வரம்பை அடைந்திருக்கலாம் அல்லது இந்த எண் ஏற்கனவே சேமிக்கப்பட்டிருக்கலாம்.",
      )
      return
    }

    setContacts(getEmergencyContacts(mobileNumber))
    setName("")
    setPhone("")
    setError("")
    setShowForm(false)
  }

  const handleDeleteContact = (id: string) => {
    if (!mobileNumber) return

    deleteEmergencyContact(mobileNumber, id)
    setContacts(getEmergencyContacts(mobileNumber))
  }

  const handleCall = (phoneNumber: string, contactName: string) => {
    // Show calling animation
    setShowCallingAnimation(contactName)

    // After 3 seconds, hide the animation and redirect to phone
    setTimeout(() => {
      setShowCallingAnimation(null)
      window.location.href = `tel:${phoneNumber}`
    }, 3000)
  }

  const handleMessage = (phoneNumber: string) => {
    window.location.href = `sms:${phoneNumber}`
  }

  return (
    <div className="space-y-6">
      <Card className="w-full shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className={language === "tamil" ? "font-tamil" : ""}>{t("emergency.title")}</CardTitle>
          {contacts.length < 5 && !showForm && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowForm(true)}
              className="flex items-center gap-1 btn-hover-effect"
            >
              <Plus className="h-4 w-4" />
              <span className={language === "tamil" ? "font-tamil" : ""}>{t("emergency.add")}</span>
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <AnimatePresence>
            {showForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-4 p-4 border rounded-md shadow-md"
              >
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name" className={language === "tamil" ? "font-tamil" : ""}>
                      {t("emergency.name")}
                    </Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value)
                        setError("")
                      }}
                      className={`${shakeName ? "animate-shake border-red-300" : ""} transition-all focus:border-primary focus:ring-2 focus:ring-primary/20`}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone" className={language === "tamil" ? "font-tamil" : ""}>
                      {t("emergency.phone")}
                    </Label>
                    <Input
                      id="phone"
                      value={phone}
                      onChange={(e) => {
                        // Only allow digits and limit to 10 characters
                        const value = e.target.value.replace(/\D/g, "").slice(0, 10)
                        setPhone(value)
                        setError("")
                      }}
                      placeholder={
                        language === "english" ? "Enter 10-digit phone number" : "10-இலக்க தொலைபேசி எண்ணை உள்ளிடவும்"
                      }
                      className={`${shakePhone ? "animate-shake border-red-300" : ""} transition-all focus:border-primary focus:ring-2 focus:ring-primary/20`}
                    />
                  </div>
                  <AnimatePresence>
                    {error && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        <Alert variant="destructive" className="py-2 animate-fade-in">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription className={language === "tamil" ? "font-tamil" : ""}>
                            {error}
                          </AlertDescription>
                        </Alert>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setShowForm(false)
                        setError("")
                        setName("")
                        setPhone("")
                      }}
                      className={`${language === "tamil" ? "font-tamil" : ""} btn-hover-effect hover:bg-red-50 hover:text-red-500`}
                    >
                      {language === "english" ? "Cancel" : "ரத்து செய்"}
                    </Button>
                    <Button
                      onClick={handleAddContact}
                      className={`${language === "tamil" ? "font-tamil" : ""} btn-hover-effect`}
                    >
                      {t("emergency.save")}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {contacts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground animate-fade-in">
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Phone className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
                <p className="text-lg">
                  {language === "english"
                    ? "No emergency contacts saved yet."
                    : "இதுவரை அவசர தொடர்புகள் எதுவும் சேமிக்கப்படவில்லை."}
                </p>
                <p className="text-sm mt-2">
                  {language === "english"
                    ? "Add important contacts for quick access during emergencies."
                    : "அவசரகாலங்களில் விரைவான அணுகலுக்கு முக்கியமான தொடர்புகளைச் சேர்க்கவும்."}
                </p>
              </motion.div>
            </div>
          ) : (
            <div className="space-y-2">
              {contacts.map((contact, index) => (
                <motion.div
                  key={contact.id}
                  className="flex items-center justify-between p-3 border rounded-md relative hover:shadow-md transition-all duration-300"
                  whileHover={{ scale: 1.01 }}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {/* Calling Animation Overlay */}
                  <AnimatePresence>
                    {showCallingAnimation === contact.name && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-green-50 flex flex-col items-center justify-center rounded-md z-10 shadow-lg"
                      >
                        <div className="relative">
                          <motion.div
                            className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center shadow-lg"
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
                          >
                            <Phone className="h-8 w-8 text-white" />
                          </motion.div>
                          <motion.div
                            className="absolute -inset-3 border-4 border-green-300 rounded-full"
                            animate={{ scale: [1, 1.5, 2], opacity: [1, 0.5, 0] }}
                            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
                          />
                        </div>
                        <p className="mt-4 font-medium text-green-700">
                          {t("emergency.calling")} {contact.name}...
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="mt-2 text-red-500 btn-hover-effect"
                          onClick={() => setShowCallingAnimation(null)}
                        >
                          <X className="h-4 w-4 mr-1" /> {t("emergency.cancel")}
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div>
                    <div className="font-medium">{contact.name}</div>
                    <div className="text-sm text-muted-foreground">{contact.phone}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleCall(contact.phone, contact.name)}
                            className="text-green-600 border-green-200 hover:bg-green-50 btn-hover-effect"
                          >
                            <Phone className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="animate-fade-in">
                          <p>{t("emergency.call")}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleMessage(contact.phone)}
                            className="text-blue-600 border-blue-200 hover:bg-blue-50 btn-hover-effect"
                          >
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="animate-fade-in">
                          <p>{t("emergency.message")}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteContact(contact.id)}
                            className="text-destructive hover:bg-red-50 btn-hover-effect"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="animate-fade-in">
                          <p>{t("emergency.delete")}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tamil Nadu Emergency Services */}
      <Card className="w-full shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className={language === "tamil" ? "font-tamil" : ""}>{t("emergency.tnServices")}</CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {emergencyServices.map((service, index) => (
              <motion.div
                key={index}
                className="flex items-center justify-between p-3 border rounded-md hover:shadow-md transition-all duration-300"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <div>
                  <div className="font-medium">{service.name}</div>
                  <div className="text-sm text-muted-foreground">{service.phone}</div>
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleCall(service.phone, service.name)}
                  className="text-green-600 border-green-200 hover:bg-green-50 btn-hover-effect"
                >
                  <Phone className="h-4 w-4" />
                </Button>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

