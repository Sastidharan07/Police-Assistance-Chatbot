"use client"

import { useLanguage } from "@/lib/language-context"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileText, Shield } from "lucide-react"

export function TermsOfService() {
  const { language } = useLanguage()

  return (
    <ScrollArea className="h-[60vh] w-full rounded-md border p-4">
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          <h2 className="text-2xl font-bold">{language === "english" ? "Terms of Service" : "சேவை விதிமுறைகள்"}</h2>
        </div>

        <p className="text-sm text-muted-foreground">
          {language === "english" ? "Last Updated: April 2, 2023" : "கடைசியாக புதுப்பிக்கப்பட்டது: ஏப்ரல் 2, 2023"}
        </p>

        <div className="space-y-4">
          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "1. Acceptance of Terms" : "1. விதிமுறைகளை ஏற்றுக்கொள்ளுதல்"}
            </h3>
            <p>
              {language === "english"
                ? 'By accessing or using the Tamil Nadu Police Assistance Chatbot application ("the Application"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use the Application.'
                : 'தமிழ்நாடு காவல்துறை உதவி சாட்போட் பயன்பாட்டை ("பயன்பாடு") அணுகுவதன் மூலம் அல்லது பயன்படுத்துவதன் மூலம், இந்த சேவை விதிமுறைகளால் ("விதிமுறைகள்") கட்டுப்பட நீங்கள் ஒப்புக்கொள்கிறீர்கள். இந்த விதிமுறைகளுக்கு நீங்கள் ஒப்புக்கொள்ளவில்லை என்றால், தயவுசெய்து பயன்பாட்டைப் பயன்படுத்த வேண்டாம்.'}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "2. Description of Service" : "2. சேவை விளக்கம்"}
            </h3>
            <p>
              {language === "english"
                ? "The Application provides a chatbot interface for users to seek assistance related to police services, report incidents, access legal information, and connect with emergency services in Tamil Nadu, India."
                : "இந்த பயன்பாடு பயனர்கள் காவல்துறை சேவைகள் தொடர்பான உதவியைப் பெற, சம்பவங்களைப் புகாரளிக்க, சட்டத் தகவல்களை அணுக மற்றும் இந்தியாவின் தமிழ்நாட்டில் அவசர சேவைகளுடன் இணைய ஒரு சாட்போட் இடைமுகத்தை வழங்குகிறது."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "3. User Accounts" : "3. பயனர் கணக்குகள்"}</h3>
            <p>
              {language === "english"
                ? "To use certain features of the Application, you may need to create an account. You are responsible for maintaining the confidentiality of your account information and for all activities that occur under your account. You agree to provide accurate and complete information when creating your account and to update your information to keep it accurate and current."
                : "பயன்பாட்டின் சில அம்சங்களைப் பயன்படுத்த, நீங்கள் ஒரு கணக்கை உருவாக்க வேண்டியிருக்கலாம். உங்கள் கணக்குத் தகவலின் இரகசியத்தன்மையைப் பராமரிப்பதற்கும், உங்கள் கணக்கின் கீழ் நடக்கும் அனைத்து செயல்பாடுகளுக்கும் நீங்கள் பொறுப்பாவீர்கள். உங்கள் கணக்கை உருவாக்கும்போது துல்லியமான மற்றும் முழுமையான தகவலை வழங்குவதற்கும், அதைத் துல்லியமாகவும் நடப்புக்கும் வைத்திருக்க உங்கள் தகவலைப் புதுப்பிக்கவும் நீங்கள் ஒப்புக்கொள்கிறீர்கள்."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "4. User Conduct" : "4. பயனர் நடத்தை"}</h3>
            <p>
              {language === "english"
                ? "You agree not to use the Application to:"
                : "பயன்பாட்டைப் பயன்படுத்தி பின்வருவனவற்றைச் செய்ய நீங்கள் ஒப்புக்கொள்ளவில்லை:"}
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                {language === "english"
                  ? "Submit false or misleading information"
                  : "தவறான அல்லது தவறாக வழிநடத்தும் தகவலை சமர்ப்பிக்க"}
              </li>
              <li>
                {language === "english"
                  ? "Engage in any unlawful or fraudulent activity"
                  : "எந்தவொரு சட்டவிரோத அல்லது மோசடி செயல்பாட்டிலும் ஈடுபட"}
              </li>
              <li>
                {language === "english"
                  ? "Harass, abuse, or harm another person"
                  : "மற்றொரு நபரைத் துன்புறுத்த, துஷ்பிரயோகம் செய்ய அல்லது தீங்கு விளைவிக்க"}
              </li>
              <li>
                {language === "english"
                  ? "Interfere with or disrupt the Application or servers"
                  : "பயன்பாடு அல்லது சேவையகங்களில் தலையிட அல்லது குறுக்கிட"}
              </li>
              <li>
                {language === "english"
                  ? "Attempt to gain unauthorized access to any part of the Application"
                  : "பயன்பாட்டின் எந்தப் பகுதிக்கும் அங்கீகரிக்கப்படாத அணுகலைப் பெற முயற்சிக்க"}
              </li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "5. Intellectual Property" : "5. அறிவுசார் சொத்து"}
            </h3>
            <p>
              {language === "english"
                ? "The Application and its original content, features, and functionality are owned by the Tamil Nadu Police Department and are protected by international copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws."
                : "பயன்பாடு மற்றும் அதன் அசல் உள்ளடக்கம், அம்சங்கள் மற்றும் செயல்பாடு ஆகியவை தமிழ்நாடு காவல்துறைக்கு சொந்தமானவை மற்றும் சர்வதேச பதிப்புரிமை, வர்த்தக முத்திரை, காப்புரிமை, வர்த்தக ரகசியம் மற்றும் பிற அறிவுசார் சொத்து அல்லது உரிமையியல் உரிமைகள் சட்டங்களால் பாதுகாக்கப்படுகின்றன."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "6. Limitation of Liability" : "6. பொறுப்பின் வரம்பு"}
            </h3>
            <p>
              {language === "english"
                ? "In no event shall the Tamil Nadu Police Department, its officers, employees, or agents be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Application."
                : "எந்தவொரு சூழ்நிலையிலும், தமிழ்நாடு காவல்துறை, அதன் அதிகாரிகள், ஊழியர்கள் அல்லது முகவர்கள் எந்தவொரு மறைமுக, தற்செயலான, சிறப்பு, விளைவான அல்லது தண்டனை சேதங்களுக்கும், இலாபங்கள், தரவு, பயன்பாடு, நற்பெயர் அல்லது பிற அருவமான இழப்புகள் உட்பட, உங்கள் அணுகல் அல்லது பயன்பாடு அல்லது பயன்பாட்டை அணுக அல்லது பயன்படுத்த முடியாததால் ஏற்படும் இழப்புகளுக்கு பொறுப்பாக மாட்டார்கள்."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "7. Disclaimer" : "7. மறுப்பு"}</h3>
            <p>
              {language === "english"
                ? 'The Application is provided on an "AS IS" and "AS AVAILABLE" basis. The Tamil Nadu Police Department expressly disclaims all warranties of any kind, whether express or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.'
                : 'பயன்பாடு "உள்ளது உள்ளபடியே" மற்றும் "கிடைக்கும் போது" என்ற அடிப்படையில் வழங்கப்படுகிறது. வெளிப்படையான அல்லது மறைமுகமான அனைத்து வகையான உத்தரவாதங்களையும், வணிகத்தன்மை, குறிப்பிட்ட நோக்கத்திற்கான பொருத்தம் மற்றும் மீறல் இல்லாதது போன்ற மறைமுக உத்தரவாதங்கள் உட்பட, ஆனால் அவற்றுக்கு மட்டுப்படுத்தப்படாமல், தமிழ்நாடு காவல்துறை வெளிப்படையாக மறுக்கிறது.'}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "8. Indemnification" : "8. இழப்பீடு"}</h3>
            <p>
              {language === "english"
                ? "You agree to defend, indemnify, and hold harmless the Tamil Nadu Police Department, its officers, employees, and agents from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these Terms or your use of the Application."
                : "இந்த விதிமுறைகளை நீங்கள் மீறுவது அல்லது பயன்பாட்டைப் பயன்படுத்துவது தொடர்பாக அல்லது அதனால் எழும் எந்தவொரு உரிமைகோரல்கள், பொறுப்புகள், சேதங்கள், தீர்ப்புகள், விருதுகள், இழப்புகள், செலவுகள், செலவுகள் அல்லது கட்டணங்களிலிருந்தும் (நியாயமான வழக்கறிஞர் கட்டணங்கள் உட்பட) தமிழ்நாடு காவல்துறை, அதன் அதிகாரிகள், ஊழியர்கள் மற்றும் முகவர்களை பாதுகாக்க, இழப்பீடு செய்ய மற்றும் தீங்கற்றதாக வைத்திருக்க நீங்கள் ஒப்புக்கொள்கிறீர்கள்."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">{language === "english" ? "9. Governing Law" : "9. ஆளும் சட்டம்"}</h3>
            <p>
              {language === "english"
                ? "These Terms shall be governed by and construed in accordance with the laws of India, without regard to its conflict of law provisions. Any dispute arising under these Terms shall be subject to the exclusive jurisdiction of the courts in Tamil Nadu, India."
                : "இந்த விதிமுறைகள் இந்தியாவின் சட்டங்களின்படி நிர்வகிக்கப்படும் மற்றும் கட்டமைக்கப்படும், அதன் சட்ட முரண்பாட்டு விதிகளைப் பொருட்படுத்தாமல். இந்த விதிமுறைகளின் கீழ் எழும் எந்தவொரு சர்ச்சையும் இந்தியாவின் தமிழ்நாட்டில் உள்ள நீதிமன்றங்களின் பிரத்யேக அதிகார வரம்பிற்கு உட்பட்டது."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "10. Changes to Terms" : "10. விதிமுறைகளில் மாற்றங்கள்"}
            </h3>
            <p>
              {language === "english"
                ? "We reserve the right to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion."
                : "எந்த நேரத்திலும் இந்த விதிமுறைகளை மாற்றியமைக்கவோ அல்லது மாற்றவோ நாங்கள் உரிமை கொண்டுள்ளோம். ஒரு திருத்தம் முக்கியமானதாக இருந்தால், புதிய விதிமுறைகள் நடைமுறைக்கு வருவதற்கு முன்பு குறைந்தபட்சம் 30 நாட்கள் அறிவிப்பை நாங்கள் வழங்குவோம். எது ஒரு பொருள் மாற்றத்தை உருவாக்குகிறது என்பது எங்கள் முழு விருப்பத்தின் பேரில் தீர்மானிக்கப்படும்."}
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="text-lg font-medium">
              {language === "english" ? "11. Contact Us" : "11. எங்களை தொடர்பு கொள்ளுங்கள்"}
            </h3>
            <p>
              {language === "english"
                ? "If you have any questions about these Terms, please contact us at terms@tnpolice.gov.in"
                : "இந்த விதிமுறைகள் பற்றி உங்களுக்கு ஏதேனும் கேள்விகள் இருந்தால், தயவுசெய்து terms@tnpolice.gov.in இல் எங்களைத் தொடர்பு கொள்ளவும்"}
            </p>
          </section>
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <p className="text-sm text-muted-foreground">
              {language === "english"
                ? "© 2023 Tamil Nadu Police. All rights reserved."
                : "© 2023 தமிழ்நாடு காவல்துறை. அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை."}
            </p>
          </div>
        </div>
      </div>
    </ScrollArea>
  )
}

