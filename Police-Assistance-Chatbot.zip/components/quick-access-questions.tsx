"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-context"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface QuickAccessQuestion {
  id: string
  category: string
  question: {
    english: string
    tamil: string
  }
  answer: {
    english: string
    tamil: string
  }
}

export function QuickAccessQuestions() {
  const { t, language } = useLanguage()
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("all")

  // Quick access questions data
  const quickAccessQuestions: QuickAccessQuestion[] = [
    {
      id: "q1",
      category: "complaints",
      question: {
        english: "How do I file a police complaint?",
        tamil: "நான் காவல்துறை புகார் எப்படி தாக்கல் செய்வது?",
      },
      answer: {
        english:
          "You can file a police complaint by visiting your nearest police station. Provide your personal details and describe the incident in detail. The officer will record your statement and give you a copy of the complaint with a reference number. Alternatively, you can file a complaint online through the official police website or use this app's Complaint section.",
        tamil:
          "உங்களுக்கு அருகிலுள்ள காவல் நிலையத்திற்குச் சென்று நீங்கள் காவல்துறை புகார் அளிக்கலாம். உங்கள் தனிப்பட்ட விவரங்களை வழங்கி சம்பவத்தை விரிவாக விவரிக்கவும். அதிகாரி உங்கள் அறிக்கையைப் பதிவு செய்து, குறிப்பு எண்ணுடன் புகாரின் நகலை உங்களுக்கு வழங்குவார். மாற்றாக, அதிகாரப்பூர்வ காவல்துறை இணையதளம் மூலம் ஆன்லைனில் புகார் அளிக்கலாம் அல்லது இந்த பயன்பாட்டின் புகார் பிரிவைப் பயன்படுத்தலாம்.",
      },
    },
    {
      id: "q2",
      category: "complaints",
      question: {
        english: "What happens after I file a complaint?",
        tamil: "நான் புகார் அளித்த பிறகு என்ன நடக்கும்?",
      },
      answer: {
        english:
          "After filing a complaint, the police will register it and assign a reference number. They will then investigate the matter, which may include recording statements, collecting evidence, and interviewing witnesses. You can check the status of your complaint using the reference number. If the complaint involves a cognizable offense, the police will register an FIR (First Information Report) and proceed with a formal investigation.",
        tamil:
          "புகார் அளித்த பிறகு, காவல்துறையினர் அதைப் பதிவு செய்து ஒரு குறிப்பு எண்ணை ஒதுக்குவார்கள். பின்னர் அவர்கள் அறிக்கைகளைப் பதிவு செய்தல், ஆதாரங்களைச் சேகரித்தல் மற்றும் சாட்சிகளை நேர்காணல் செய்தல் போன்றவற்றை உள்ளடக்கிய விஷயத்தை விசாரிப்பார்கள். குறிப்பு எண்ணைப் பயன்படுத்தி உங்கள் புகாரின் நிலையை நீங்கள் சரிபார்க்கலாம். புகார் ஒரு அறியக்கூடிய குற்றத்தை உள்ளடக்கியிருந்தால், காவல்துறையினர் FIR (முதல் தகவல் அறிக்கை) பதிவு செய்து முறையான விசாரணையை மேற்கொள்வார்கள்.",
      },
    },
    {
      id: "q3",
      category: "legal",
      question: {
        english: "What should I do if I'm wrongfully detained?",
        tamil: "நான் தவறாக தடுத்து வைக்கப்பட்டால் என்ன செய்ய வேண்டும்?",
      },
      answer: {
        english:
          "If you believe you've been wrongfully detained, remain calm and cooperate with the officers. Ask for the reason for your detention. You have the right to remain silent and the right to legal representation. Request to contact a family member or lawyer immediately. Remember that you should be produced before a magistrate within 24 hours of arrest. If your detention exceeds this period without court appearance, it becomes illegal. You can later file for wrongful detention compensation.",
        tamil:
          "நீங்கள் தவறாக தடுத்து வைக்கப்பட்டிருப்பதாக நம்பினால், அமைதியாக இருந்து அதிகாரிகளுடன் ஒத்துழைக்கவும். உங்களைத் தடுத்து வைத்ததற்கான காரணத்தைக் கேளுங்கள். நீங்கள் அமைதியாக இருக்கவும், சட்ட பிரதிநிதித்துவத்திற்கும் உரிமை உண்டு. உடனடியாக ஒரு குடும்ப உறுப்பினர் அல்லது வழக்கறிஞரைத் தொடர்பு கொள்ள கோருங்கள். கைது செய்யப்பட்ட 24 மணி நேரத்திற்குள் நீங்கள் நீதிபதி முன் ஆஜர்படுத்தப்பட வேண்டும் என்பதை நினைவில் கொள்ளுங்கள். நீதிமன்றத்தில் ஆஜராகாமல் உங்கள் தடுப்புக்காவல் இந்த காலத்தை மீறினால், அது சட்டவிரோதமானது. பின்னர் நீங்கள் தவறான தடுப்புக்காவல் இழப்பீட்டிற்காக தாக்கல் செய்யலாம்.",
      },
    },
    {
      id: "q4",
      category: "legal",
      question: {
        english: "What are my rights during police questioning?",
        tamil: "காவல்துறை விசாரணையின் போது எனது உரிமைகள் என்ன?",
      },
      answer: {
        english:
          "During police questioning, you have the right to know why you're being questioned. You have the right to remain silent to avoid self-incrimination. You have the right to consult with a lawyer before and during questioning. You cannot be forced to make a confession or statement. Any confession made to police under duress is inadmissible in court. You have the right to an interpreter if you don't understand the language. If you're a minor, a woman, or elderly, you have additional protections.",
        tamil:
          "காவல்துறை விசாரணையின் போது, நீங்கள் ஏன் விசாரிக்கப்படுகிறீர்கள் என்பதை அறியும் உரிமை உங்களுக்கு உண்டு. சுய குற்றச்சாட்டைத் தவிர்க்க அமைதியாக இருக்கும் உரிமை உங்களுக்கு உண்டு. விசாரணைக்கு முன்பும் விசாரணையின் போதும் ஒரு வழக்கறிஞரை ஆலோசிக்கும் உரிமை உங்களுக்கு உண்டு. ஒப்புதல் வாக்குமூலம் அல்லது அறிக்கை அளிக்க உங்களை கட்டாயப்படுத்த முடியாது. காவல்துறையினரால் நிர்பந்தத்தின் கீழ் செய்யப்பட்ட எந்த ஒப்புதல் வாக்குமூலமும் நீதிமன்றத்தில் ஏற்றுக்கொள்ளப்படாது. நீங்கள் மொழியைப் புரிந்து கொள்ளவில்லை என்றால், உங்களுக்கு மொழிபெயர்ப்பாளர் உரிமை உண்டு. நீங்கள் சிறுவராகவோ, பெண்ணாகவோ அல்லது வயதானவராகவோ இருந்தால், உங்களுக்கு கூடுதல் பாதுகாப்புகள் உண்டு.",
      },
    },
    {
      id: "q5",
      category: "emergency",
      question: {
        english: "What are the emergency police numbers I should know?",
        tamil: "நான் அறிந்திருக்க வேண்டிய அவசர காவல்துறை எண்கள் என்ன?",
      },
      answer: {
        english:
          "Important emergency numbers in India: Police Emergency: 100, Women's Helpline: 1091, Traffic Police: 103, Anti-Corruption: 1064, Child Helpline: 1098, Senior Citizen Helpline: 14567, National Emergency Number: 112. Save these numbers in your phone and also add your personal emergency contacts in the Emergency Contacts section of this app for quick access during emergencies.",
        tamil:
          "இந்தியாவில் முக்கியமான அவசர எண்கள்: காவல்துறை அவசரம்: 100, பெண்கள் உதவி எண்: 1091, போக்குவரத்து காவல்துறை: 103, ஊழல் எதிர்ப்பு: 1064, குழந்தைகள் உதவி எண்: 1098, மூத்த குடிமக்கள் உதவி எண்: 14567, தேசிய அவசர எண்: 112. இந்த எண்களை உங்கள் தொலைபேசியில் சேமித்து, அவசரகாலங்களில் விரைவான அணுகலுக்காக இந்த பயன்பாட்டின் அவசர தொடர்புகள் பிரிவில் உங்கள் தனிப்பட்ட அவசர தொடர்புகளையும் சேர்க்கவும்.",
      },
    },
    {
      id: "q6",
      category: "emergency",
      question: {
        english: "How do I report a crime in progress?",
        tamil: "நடந்து கொண்டிருக்கும் குற்றத்தை எப்படி புகார் செய்வது?",
      },
      answer: {
        english:
          "If you witness a crime in progress, immediately call the emergency police number 100 or the national emergency number 112. Stay calm and provide clear information about your location, the nature of the crime, and any descriptions of individuals involved. If possible, move to a safe location while maintaining visual contact with the scene. Do not attempt to intervene personally as this could put you at risk. Wait for the police to arrive and be prepared to provide a statement.",
        tamil:
          "நீங்கள் நடந்து கொண்டிருக்கும் குற்றத்தைக் கண்டால், உடனடியாக அவசர காவல்துறை எண் 100 அல்லது தேசிய அவசர எண் 112 ஐ அழைக்கவும். அமைதியாக இருந்து உங்கள் இருப்பிடம், குற்றத்தின் தன்மை மற்றும் சம்பந்தப்பட்ட நபர்களின் விவரங்கள் பற்றிய தெளிவான தகவல்களை வழங்கவும். முடிந்தால், காட்சியுடன் தொடர்பைப் பராமரித்து பாதுகாப்பான இடத்திற்கு செல்லவும். இது உங்களை ஆபத்தில் சிக்க வைக்கக்கூடும் என்பதால் தனிப்பட்ட முறையில் தலையிட முயற்சிக்க வேண்டாம். காவல்துறையினர் வரும் வரை காத்திருந்து அறிக்கை அளிக்க தயாராக இருங்கள்.",
      },
    },
    {
      id: "q7",
      category: "complaints",
      question: {
        english: "What is the difference between a complaint and an FIR?",
        tamil: "புகார் மற்றும் FIR இடையே உள்ள வேறுபாடு என்ன?",
      },
      answer: {
        english:
          "A complaint is a written or verbal allegation made to the police about any offense, which may or may not be cognizable. The police record it in the station diary but are not obligated to investigate unless directed by a court. An FIR (First Information Report), on the other hand, is a formal document prepared by police when they receive information about a cognizable offense. The police are legally bound to register an FIR for cognizable offenses and must investigate. An FIR sets the criminal law in motion and is the first step in the criminal justice process.",
        tamil:
          "புகார் என்பது அறியக்கூடிய அல்லது அறியமுடியாத எந்த குற்றம் பற்றியும் காவல்துறைக்கு எழுத்து மூலமாகவோ அல்லது வாய்மொழியாகவோ செய்யப்படும் குற்றச்சாட்டாகும். காவல்துறையினர் அதை நிலைய நாட்குறிப்பில் பதிவு செய்கின்றனர், ஆனால் நீதிமன்றத்தால் உத்தரவிடப்படாவிட்டால் விசாரிக்க கடமைப்பட்டவர்கள் அல்ல. மறுபுறம், FIR (முதல் தகவல் அறிக்கை) என்பது அறியக்கூடிய குற்றம் பற்றிய தகவலைப் பெறும்போது காவல்துறையினரால் தயாரிக்கப்படும் ஒரு முறையான ஆவணமாகும். அறியக்கூடிய குற்றங்களுக்கு FIR ஐப் பதிவு செய்ய காவல்துறையினர் சட்டப்பூர்வமாகக் கட்டுப்பட்டுள்ளனர் மற்றும் கட்டாயம் விசாரிக்க வேண்டும். FIR குற்றவியல் சட்டத்தை இயக்குகிறது மற்றும் குற்றவியல் நீதி செயல்முறையில் முதல் படியாகும்.",
      },
    },
    {
      id: "q8",
      category: "legal",
      question: {
        english: "Can police search my house without a warrant?",
        tamil: "வாரண்ட் இல்லாமல் காவல்துறையினர் என் வீட்டை சோதனை செய்ய முடியுமா?",
      },
      answer: {
        english:
          "Generally, police cannot search your house without a warrant. However, there are exceptions: 1) If they are in 'hot pursuit' of a suspect who enters your premises, 2) If they have reasonable belief that evidence might be destroyed if they wait for a warrant, 3) If they have received reliable information about the commission of a cognizable offense in your premises, or 4) If you give voluntary consent for the search. During a search, you have the right to see the warrant, verify the officers' identities, and have witnesses present. The police must prepare a list of items seized and provide you with a copy.",
        tamil:
          "பொதுவாக, வாரண்ட் இல்லாமல் காவல்துறையினர் உங்கள் வீட்டை சோதனை செய்ய முடியாது. இருப்பினும், விதிவிலக்குகள் உள்ளன: 1) அவர்கள் உங்கள் வளாகத்திற்குள் நுழையும் சந்தேக நபரை 'சூடான துரத்துதலில்' இருந்தால், 2) வாரண்டுக்காக காத்திருந்தால் ஆதாரங்கள் அழிக்கப்படலாம் என்ற நியாயமான நம்பிக்கை இருந்தால், 3) உங்கள் வளாகத்தில் அறியக்கூடிய குற்றம் நடந்ததைப் பற்றி நம்பகமான தகவல் பெற்றிருந்தால், அல்லது 4) நீங்கள் தன்னார்வ ஒப்புதல் அளித்தால். சோதனையின் போது, நீங்கள் வாரண்டைப் பார்க்கவும், அதிகாரிகளின் அடையாளங்களை சரிபார்க்கவும், சாட்சிகளை வைத்திருக்கவும் உரிமை உண்டு. காவல்துறையினர் பறிமுதல் செய்யப்பட்ட பொருட்களின் பட்டியலைத் தயாரித்து உங்களுக்கு ஒரு நகலை வழங்க வேண்டும்.",
      },
    },
  ]

  // Filter based on search query and category
  const filteredQuestions = quickAccessQuestions.filter((question) => {
    const matchesSearch =
      question.question[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
      question.answer[language].toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = activeCategory === "all" || question.category === activeCategory

    return matchesSearch && matchesCategory
  })

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Quick Access Questions</CardTitle>
        <div className="relative mt-2">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search questions..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="complaints">Complaints</TabsTrigger>
            <TabsTrigger value="legal">Legal</TabsTrigger>
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
          </TabsList>
          <div className="mt-4">
            {filteredQuestions.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">
                No questions found. Try a different search term.
              </div>
            ) : (
              <Accordion type="single" collapsible className="w-full">
                {filteredQuestions.map((question) => (
                  <AccordionItem key={question.id} value={question.id}>
                    <AccordionTrigger className="text-left">{question.question[language]}</AccordionTrigger>
                    <AccordionContent>{question.answer[language]}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  )
}

