"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { getUserData, saveUserData, type UserProfile } from "@/lib/storage-service"

interface AuthContextType {
  isAuthenticated: boolean
  mobileNumber: string | null
  lastVisitedTab: string
  userProfile: UserProfile | null
  login: (mobile: string, initialProfile?: Partial<UserProfile>) => void
  logout: () => void
  setLastVisitedTab: (tab: string) => void
  updateUserProfile: (profile: Partial<UserProfile>) => void
}

// Create a default context value to avoid the "must be used within a provider" error
const defaultContextValue: AuthContextType = {
  isAuthenticated: false,
  mobileNumber: null,
  lastVisitedTab: "chat",
  userProfile: null,
  login: () => {},
  logout: () => {},
  setLastVisitedTab: () => {},
  updateUserProfile: () => {},
}

const AuthContext = createContext<AuthContextType>(defaultContextValue)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [mobileNumber, setMobileNumber] = useState<string | null>(null)
  const [lastVisitedTab, setLastVisitedTab] = useState("chat")
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)
  const router = useRouter()

  // Check for existing session on mount
  useEffect(() => {
    // Use try-catch to handle any potential errors during initialization
    try {
      const storedIsAuthenticated = sessionStorage.getItem("isAuthenticated") === "true"
      const storedMobileNumber = sessionStorage.getItem("mobileNumber")
      const storedLastVisitedTab = localStorage.getItem("lastVisitedTab") || "chat"

      if (storedIsAuthenticated && storedMobileNumber) {
        setIsAuthenticated(true)
        setMobileNumber(storedMobileNumber)
        setLastVisitedTab(storedLastVisitedTab)

        // Get user data including profile
        const userData = getUserData(storedMobileNumber)
        if (userData.profile) {
          setUserProfile(userData.profile)
        }
      }
    } catch (error) {
      console.error("Error initializing auth context:", error)
    } finally {
      setIsInitialized(true)
    }
  }, [])

  const login = (mobile: string, initialProfile?: Partial<UserProfile>) => {
    setIsAuthenticated(true)
    setMobileNumber(mobile)

    // Store in sessionStorage for persistence across page refreshes
    sessionStorage.setItem("isAuthenticated", "true")
    sessionStorage.setItem("mobileNumber", mobile)

    // Check if there's a previously stored last visited tab for this user
    const storedLastVisitedTab = localStorage.getItem(`lastVisitedTab_${mobile}`)
    if (storedLastVisitedTab) {
      setLastVisitedTab(storedLastVisitedTab)
    }

    // Get existing user data
    const userData = getUserData(mobile)

    // Initialize or update profile
    if (initialProfile || !userData.profile) {
      const updatedProfile = {
        ...userData.profile,
        ...initialProfile,
        phoneNumber: mobile, // Always ensure phone number is set
      }

      userData.profile = updatedProfile
      saveUserData(mobile, userData)
      setUserProfile(updatedProfile)
    } else if (userData.profile) {
      setUserProfile(userData.profile)
    }

    router.push("/chat")
  }

  const updateUserProfile = (profile: Partial<UserProfile>) => {
    if (!mobileNumber) return

    const userData = getUserData(mobileNumber)
    const updatedProfile = {
      ...userData.profile,
      ...profile,
    }

    userData.profile = updatedProfile
    saveUserData(mobileNumber, userData)
    setUserProfile(updatedProfile)
  }

  const updateLastVisitedTab = (tab: string) => {
    setLastVisitedTab(tab)
    localStorage.setItem("lastVisitedTab", tab)

    // Also store tab per user
    if (mobileNumber) {
      localStorage.setItem(`lastVisitedTab_${mobileNumber}`, tab)
    }
  }

  const logout = () => {
    setIsAuthenticated(false)
    setMobileNumber(null)
    setUserProfile(null)

    // Clear session storage
    sessionStorage.removeItem("isAuthenticated")
    sessionStorage.removeItem("mobileNumber")

    router.push("/")
  }

  // Only render children once the auth context is initialized
  if (!isInitialized) {
    return null
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        mobileNumber,
        lastVisitedTab,
        userProfile,
        login,
        logout,
        setLastVisitedTab: updateLastVisitedTab,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  return context
}

